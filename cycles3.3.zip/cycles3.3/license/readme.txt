The default license for Cycles source code is Apache 2.0.

There is also code adapted from other sources with different but compatible
licenses. This is marked with appropriate SPDX license identifiers and
copyright notices in source files.

See SPDX-license-identifiers.txt for a list of licenses used in the code.
