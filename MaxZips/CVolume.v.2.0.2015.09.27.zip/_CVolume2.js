// CVolume v.2.0 - Dinos, Max Smirnov. 2015
function CVolume()
{
	moi.ui.commandUI.progressinfo.innerHTML="Select objects";
	var objectpicker = moi.ui.createObjectPicker();
	while ( true )
	{
		if (!objectpicker.waitForEvent()) return; 
		if (objectpicker.done()) break;
	}
	var mode = moi.ui.commandUI.loadObjects(objectpicker.objects);
	if ( mode < 0 ) return;
	moi.ui.commandUI.hidObjects(true);
	var param = moi.command.getCommandLineParams(),
		angle = (param !=='')?param*1:3;
	moi.ui.commandUI.preinit();	
	moi.ui.commandUI.progressinfo.innerHTML="Calculating ...";
	var data = moi.ui.commandUI.processObjects(mode, angle);
				
	moi.ui.commandUI.postinit();
	moi.ui.beginUIUpdate();
	moi.ui.showUI( 'styleSwitch' );
	if ( mode === 1 ) { moi.ui.showUI( 'InputAll' ); } else { moi.ui.showUI( 'InputSurface' ); }
	moi.ui.endUIUpdate();
	moi.ui.commandUI.progressinfo.innerHTML="&nbsp;";
	
	moi.command.registerCommandSpecificShortcutKey("RightArrow");
	moi.command.registerCommandSpecificShortcutKey("LeftArrow");
	while ( true )
	{
		moi.ui.commandDialog.waitForEvent();
		var e  = moi.ui.commandDialog.event;
		if ( e == 'cancel' ) { moi.ui.commandUI.commitScales(false); if ( mode === 1) moi.ui.commandUI.updateCom('cancel'); break; }
		if ( e == 'done' ) { moi.ui.commandUI.commitScales(true); if ( mode === 1) moi.ui.commandUI.updateCom('done'); break; }
		if ( e == 'densityBox' ) { moi.ui.commandUI.updateDensity(); }
		if ( e == 'massBox' ) { moi.ui.commandUI.scaleObjects('mass'); }
		if ( e == 'volumeBox' ) { moi.ui.commandUI.scaleObjects('volume'); }
		if ( e == 'surfaceBox' || e == 'surfaceBoxSolo') { moi.ui.commandUI.scaleObjects('surface'); }
		if ( e == 'comCheckbox' ) { moi.ui.commandUI.updateCom(); }
		if ( e == 'finished' ) { moi.ui.commandUI.switchGroupByStyle(objectpicker.objects.item(0).styleIndex); }
		if ( e == 'RightArrow' ) { moi.ui.commandUI.switchGroup(moi.ui.commandUI.currentGroup+1); }
		if ( e == 'LeftArrow' ) { moi.ui.commandUI.switchGroup(moi.ui.commandUI.currentGroup-1); }
	}
	moi.ui.commandUI.hidObjects(false);
}
CVolume();
