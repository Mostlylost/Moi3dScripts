// RandomStyles 0.9 - Max Smirnov. 2014
#include "WaitForDialogDone.js"
if ( moi.geometryDatabase.getSelectedObjects().length > 0 ) 
if (WaitForDialogDone()) moi.ui.commandUI.doRandomStyles();