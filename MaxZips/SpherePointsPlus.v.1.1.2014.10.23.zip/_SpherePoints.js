/* 
 *	SpherePoints+  v.1.1.  Brian McMillin, Max Smirnov. 2014.
 *	The original Python implementation is here: http://www.softimageblog.com/archives/115
 *	This is an unofficial script, modified from the Fibonacci script, which modified
 *	Michaels ToroidalHelix, and LineWeb scripts.
 */
 
function DoSpherePoints()
{
	var dialog = moi.ui.commandDialog;
	moi.ui.commandUI.init();	
	while ( true )
	{
		dialog.waitForEvent();
		if ( dialog.event === 'done' ) return;
		if ( dialog.event === 'cancel' ) break;
	}
	moi.ui.commandUI.cancel();
}
DoSpherePoints();