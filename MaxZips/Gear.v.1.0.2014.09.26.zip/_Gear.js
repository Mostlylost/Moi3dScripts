// config: norepeat
#include "GetPoint.js"

function DoGear()
{
	var pointpicker = moi.ui.createPointPicker();
	if ( !GetPoint( pointpicker ) ) return;
	moi.ui.commandUI.cplane = pointpicker.ptframe;
	var ui = moi.ui.commandUI;

	moi.ui.beginUIUpdate();
	moi.ui.hideUI( 'PickPrompt' );
	moi.ui.hideUI( 'CancelContainer' );
	moi.ui.showUI( 'OptionsPrompt' );
	moi.ui.showUI( 'GearOptions' );
	moi.ui.showUI( 'DoneCancelContainer' );
	moi.ui.endUIUpdate();

	// Show the initial result.
	moi.ui.commandUI.init();
	// Wait for any changes to the UI or cancel or done.
	var dialog = moi.ui.commandDialog;

	while ( 1 )
	{
		if ( !dialog.waitForEvent() )
		{
			if ( moi.ui.commandUI.profile.length !== 0 ) moi.geometryDatabase.removeObjects( moi.ui.commandUI.profile );
			return; // Canceled.
		}
		if ( dialog.event == 'done' ) break; // "Done" pushed.
		moi.ui.commandUI.lastN=-1;
	}
	moi.ui.commandUI.profile.setProperty( 'displayMode',0);
}

DoGear();
