// fxGraph3D v.1.1 - Max Smirnov. 2016
function fxGraph3D()
{
	var e, values = ['inputX', 'inputY', 'inputZ', 'minUi', 'maxUi', 'minVi', 'maxVi', 'ptsUi', 'ptsVi', 'avi', 'bvi', 'cvi', 'drawMode'];
	var params = moi.command.getCommandLineParams().replace(' ','');
	if ( params !=='')
	{
		for ( var i = 0; i<params.split(';').length; i++) { if (params.split(';')[i] !== '' ) moi.ui.commandUI[values[i]].value = params.split(';')[i];} 
	}
	moi.ui.commandUI.init();
	while ( 1 )
	{
		moi.ui.commandDialog.waitForEvent();
		e  = moi.ui.commandDialog.event;
		if ( e == 'cancel' ) { moi.ui.commandUI.updatePoints(0); return; }
		if ( e == 'done' ) break;
		if ( e == 'ptsUi' || e == 'ptsUslider' ) { moi.ui.commandUI.recalcParams(1); }
		if ( e == 'ptsVi' || e == 'ptsVslider' ) { moi.ui.commandUI.recalcParams(1); }
		if ( e == 'maxUi' || e == 'minUi' || e == 'maxVi' || e == 'minVi' ) { moi.ui.commandUI.recalcParams(0);} 
		if ( e == 'avi' || e == 'bvi' || e == 'cvi' || e == 'dvi' ) { moi.ui.commandUI.recalcParams(0); }
		if ( e == 'drawMode' ) { moi.ui.commandUI.updatePoints(1); }
		if ( e == 'loft' ) 
		{
			moi.ui.commandUI.stopUpdate();
			moi.ui.commandUI.statusline.innerHTML = 'Lofting';
			var loftF = moi.command.createFactory( 'loft' );
			loftF.setInput( 0, moi.ui.commandUI.objects );
			loftF.setInput( 2, 'Loose' );
			loftF.setInput( 3, false );
			loftF.setInput( 4, false );
			moi.ui.commandUI.objects = loftF.calculate();
			moi.geometryDatabase.addObjects(moi.ui.commandUI.objects);
			moi.ui.commandUI.statusline.innerHTML = 'Yes!!';
			moi.ui.commandUI.startUpdate();
		}
		
	}
}
fxGraph3D();