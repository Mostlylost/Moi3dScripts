// config: norepeat noautolaunch
// Starmap v0.45 - Max Smirnov. 2015
moi.ui.commandUI.Starmap(50);