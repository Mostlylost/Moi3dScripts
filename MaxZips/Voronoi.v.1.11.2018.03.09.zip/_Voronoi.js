// Voronoi v1.11 - Max Smirnov 2018
// Voronoi Javascript library v.0.96 by Raymond Hill (rhill@raymondhill.net)
// https://github.com/gorhill/Javascript-Voronoi
// Licensed under The MIT License. http://en.wikipedia.org/wiki/MIT_License

function VoronoiMX()
{
	if ( moi.ui.commandUI.init() < 1 ) { moi.ui.beginUIUpdate();  moi.ui.showUI( 'SizeOptions' );   moi.ui.endUIUpdate(); }
	var pointpicker = moi.ui.createPointPicker();
	pointpicker.restrictToPlane( pointpicker.ptframe, true );
	pointpicker.bindFunc(moi.ui.commandUI.updatePoint);
	
	while ( true )
	{
		if (!pointpicker.waitForEvent() ) break;
		var p  = pointpicker.event;
		if ( p === 'finished' ) { moi.ui.commandUI.addNewPoint(pointpicker.pt.x, pointpicker.pt.y) }
		if ( p === 'done' ) { moi.ui.commandUI.done(); return; }
		if ( p === 'cancel' ) break;
		if ( p === 'xSize' || p === 'ySize' || p === 'xSlider' || p === 'ySlider') moi.ui.commandUI.setRectangle();
		if ( p === 'corner' || p === 'space' || p === 'filter' || p === 'spaceSlider' || p === 'cornerSlider' || p === 'showPoints' || p === 'filterSlider' ) moi.ui.commandUI.updateObjects();
		moi.ui.clearPickedPoints();
	}
	moi.ui.commandUI.cancel();
}
VoronoiMX();