// Random curves generator v.1.0 - Max Smirnov (RUS) 2014
#include "WaitForDialogDone.js"
function DoRandomCurves() { if ( WaitForDialogDone() ) moi.ui.commandUI.generateRandomCurves() }
DoRandomCurves();