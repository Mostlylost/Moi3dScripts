// fxGraph v.1.2e - Max Smirnov. 2016
function fxGraph()
{
	var e, values = ['inputFx', 'minXi', 'maxXi', 'ptsXi', 'avi', 'bvi', 'cvi', 'dvi'];
	var params = moi.command.getCommandLineParams();
	if ( params !=='')
	{
		for ( var i = 0; i<params.split(';').length; i++) { if (params.split(';')[i] !== '' ) moi.ui.commandUI[values[i]].value = params.split(';')[i];} 
	}
	moi.ui.commandUI.init();
	while ( 1 )
	{
		moi.ui.commandDialog.waitForEvent();
		e  = moi.ui.commandDialog.event;
		if ( e == 'cancel' ) return;
		if ( e == 'done' ) break;
		if ( e == 'ptsXi' || e == 'ptsXslider' ) { moi.ui.commandUI.resetFactory(false); }
		if ( e == 'maxXi' || e == 'minXi' ) { moi.ui.commandUI.getParams();} 
		if ( e == 'avi' || e == 'bvi' || e == 'cvi' || e == 'dvi' ) { moi.ui.commandUI.getParams(); }
	}
	moi.ui.commandUI.commit();
}
fxGraph();