// Wire v.1.0 - Max Smirnov. 2017
function Wire()
{
	var picker = moi.ui.createOrientationPicker();
	picker.noDefaultFrame = true;
	
	while ( true )
	{
		if ( !picker.waitForEvent() ) return;
		if ( picker.event === 'finished' || picker.event === 'done' )
		{
			moi.ui.commandUI.frame1 = moi.VectorMath.createFrame(picker.frame.origin, picker.frame.xaxis, picker.frame.yaxis );
			break;
		}
	}

	picker.reset();
	moi.ui.beginUIUpdate();
	moi.ui.hideUI( 'SelectPrompt1' );
	moi.ui.showUI( 'SelectPrompt2' );
	moi.ui.endUIUpdate();
	
	while ( true )
	{
		if ( !picker.waitForEvent() ) return;
		if ( picker.event === 'finished' || picker.event === 'done' ) break;
	}
	
	moi.ui.commandUI.frame2 = moi.VectorMath.createFrame(picker.frame.origin, picker.frame.xaxis, picker.frame.yaxis );
	picker.reset();
	moi.ui.beginUIUpdate();
	moi.ui.hideUI( 'SelectPrompt2' );
	moi.ui.showUI( 'OptionsPrompt' );
	moi.ui.showUI( 'Options' );
	moi.ui.endUIUpdate();
	
	moi.ui.commandUI.init();
	while ( true )
	{
		moi.ui.commandDialog.waitForEvent();
		var e  = moi.ui.commandDialog.event;
		if ( e === 'cancel' ) { moi.ui.commandUI.cancel(); break; }
		if ( e === 'done' ) { moi.ui.commandUI.done(); break; }
		if ( e === 'keepCurves' ) { moi.ui.commandUI.ld += 1 }
	}
}

Wire();