// config: norepeat
// DelCorners v.0.5 Max Smirnov 2015
function dc()
{
	moi.ui.commandUI.delCorners();
}
dc();