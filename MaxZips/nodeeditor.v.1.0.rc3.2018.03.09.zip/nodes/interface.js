// MoI Nodeedit
// Widgets v.1.0 - Max Smirnov, 2018
// litegraph.js library (c) Javi Agenjo http://tamats.com

(function(){
		
// Widget Knob

function WidgetKnob()
{
	this.size = [55,58];
	this.minsize = [55,58];
	this.addOutput("",'numarray');
	this.local = { csize:50, wheelTime:0 }
	this.properties = { min:0, max:100, digits:0, value:"20" };
	this.internal = { position:0.2 };
}

WidgetKnob.title = "Knob";
WidgetKnob.desc = "Circular controller";

WidgetKnob.prototype.onAdded = function()
{
	this.internal.position = (this.properties.value - this.properties.min) / (this.properties.max - this.properties.min);
}

WidgetKnob.prototype.onPropertyChange = function()
{
	this.properties.value = parseFloat(this.properties.value.replace(',', '.'));
	if ( isNaN(this.properties.value) ) this.properties.value = this.properties.min;
	if ( this.properties.min >= this.properties.max ) this.properties.max = this.properties.min+1;
	if ( this.properties.value < this.properties.min ) this.properties.value = this.properties.min*1;
	if ( this.properties.value > this.properties.max ) this.properties.value =this.properties.max*1;
	this.properties.digits = Math.floor(this.properties.digits);
	if (this.properties.digits>12) this.properties.digits = 12;
	if (this.properties.digits<0) this.properties.digits = 0;
	this.internal.position = (this.properties.value-this.properties.min)/(this.properties.max-this.properties.min);
	this.properties.value = this.properties.value.toFixed(this.properties.digits);
}

WidgetKnob.prototype.onDrawForeground = function(ctx)
{
	var cx = this.size[0]/2;
	var cy = this.size[1]/2;
	var ro = this.local.csize*0.45;
	var ri = this.local.csize*0.37;

	var bgr = this.bgcolor || LiteGraph.NODE_DEFAULT_BGCOLOR;
	ctx.fillStyle= bgr;
	ctx.beginPath();
		ctx.arc(cx, cy, this.local.csize*0.54, 0, Math.PI*2, false);
	ctx.fill();
	if ( this.flags.collapsed )
	{
		ctx.lineWidth = 0.5;
		ctx.strokeStyle = LiteGraph.EDITOR_BACKGROUND;
		ctx.stroke();
	}
	ctx.lineWidth = 1;

	ctx.beginPath();
		ctx.strokeStyle= this.mouseOver ? "#FFF" : "#AAA";
		ctx.arc(this.size[0]/2, this.size[1]/2, this.local.csize*0.50, 0, 2*Math.PI, true);
	ctx.stroke();

	if(this.internal.position > 0)
	{
		ctx.beginPath();
			ctx.fillStyle="#9CA";
			ctx.moveTo(cx,cy-ro)
			ctx.arc(cx, cy, ro, 3/4*Math.PI*2, 3/4*Math.PI*2-Math.PI*2*this.internal.position, true);
			ctx.lineTo(cx,cy);
		ctx.fill();
		ctx.beginPath();
			ctx.fillStyle= bgr;
			ctx.arc(cx, cy, ri, 0, Math.PI*2, false);
		ctx.fill();

	}
	ctx.font = "12px Arial";
	ctx.fillStyle="#AAA";
	ctx.textAlign = "center";
	var dgt = parseInt(this.properties.digits);
	if ( dgt > 2 ) dgt = 2;
	if ( this.properties.max >= 100 && dgt > 1) dgt = 1;
	if ( this.properties.max >= 1000 ) dgt = 0;
	ctx.fillText(parseFloat(this.properties.value).toFixed(dgt), this.size[0]/2, this.size[1]/2+4 );
	ctx.textAlign = "left";
}

WidgetKnob.prototype.onExecute = function()
{
	this.setOutputData(0, [parseFloat(this.properties.value)] );
}

WidgetKnob.prototype.onMouseDown = function(e, skipcapture)
{
	this.center = [this.size[0]/2, this.size[1]/2];
	this.radius = this.size[0]/2;
	if(e.canvasY - this.pos[1] < 0 || distance([e.canvasX,e.canvasY],[this.pos[0] + this.center[0],this.pos[1] + this.center[1]]) > this.radius) return false;
	if ( skipcapture ) return true;
	this.oldmouse = [ e.canvasX - this.pos[0], e.canvasY - this.pos[1] ];
	this.captureInput(true);
	return true;
}

WidgetKnob.prototype.onMouseMove = function(e)
{
	if (!this.oldmouse) return;

	var m = [ e.canvasX - this.pos[0], e.canvasY - this.pos[1] ];

	var v = this.internal.position;
	var delta = (m[1] - this.oldmouse[1]);

	v -= delta/201;
	if (v > 1.0) { v = 1.0 } else if (v < 0.0) { v = 0.0 }

	this.internal.position = v;
	this.properties.value = this.properties.min + (this.properties.max - this.properties.min) * this.internal.position;
	this.properties.value = this.properties.value.toFixed(this.properties.digits);
	this.oldmouse = m;
	this.updateThisNodeGraph();
	this.graph.setisChangedFlag(this.id);
}

WidgetKnob.prototype.onMouseUp = function()
{
	if(this.oldmouse)
	{
		this.oldmouse = null;
		this.captureInput(false);
	}
}

WidgetKnob.prototype.onMouseWheel = function(e)
{
	var v = this.internal.position;
	var delta = e.wheelDeltaY || e.wheelDeltaX; delta = delta/12000;
	if (delta>0.01) delta = 0.01;
	if (delta<-0.01) delta = -0.01;
	var time = LiteGraph.getTime();
	if ( time - this.local.wheelTime < 50 ) { delta *=5 }
	else if ( time - this.local.wheelTime < 100 ) { delta *=2; }
	this.local.wheelTime = time;
	v += delta;
	if (v > 1.0) { v = 1.0 } else if (v < 0.0) { v = 0.0 }

	this.internal.position = v;
	this.properties.value = this.properties.min + (this.properties.max - this.properties.min) * this.internal.position;
	this.properties.value = this.properties.value.toFixed(this.properties.digits);
	this.updateThisNodeGraph();
	this.graph.setisChangedFlag(this.id);
}
LiteGraph.registerNodeType("Widget/Knob", WidgetKnob);


// Widget Slider

function WidgetHSlider()
{
	this.size = [150,20];
	this.minsize = [150,20];
	this.addOutput("",'numarray');
	this.local = { shiftLeft:14, shiftRight:40, fontsize:12, wheelTime:0 };
	this.properties = { min:0, max:10, digits:1, value:"5.0" };
	this.internal = { position:0.5 };
}

WidgetHSlider.title = "Slider";
WidgetHSlider.desc = "Linear slider controller";

WidgetHSlider.prototype.onAdded = function()
{
	this.internal.position = (this.properties.value - this.properties.min) / (this.properties.max - this.properties.min);
}

WidgetHSlider.prototype.onPropertyChange = function()
{
	this.properties.value = parseFloat(this.properties.value.replace(',', '.'));
	if ( isNaN(this.properties.value) ) this.properties.value = this.properties.min;
	if ( this.properties.min >= this.properties.max ) this.properties.max = this.properties.min+1;
	if ( this.properties.value < this.properties.min ) this.properties.value = this.properties.min;
	if ( this.properties.value > this.properties.max ) this.properties.value = this.properties.max;
	this.properties.digits = Math.floor(this.properties.digits);
	if (this.properties.digits>12) this.properties.digits = 12;
	if (this.properties.digits<0) this.properties.digits = 0;
	this.internal.position = (this.properties.value-this.properties.min)/(this.properties.max-this.properties.min);
	this.properties.value = this.properties.value.toFixed(this.properties.digits);
}

WidgetHSlider.prototype.onDrawForeground = function(ctx)
{
	var sr = this.local.shiftRight, sl = this.local.shiftLeft;
	var dgt = parseInt(this.properties.digits);
	if ( dgt > 2 ) dgt = 2;
	if ( this.properties.max >= 100 && dgt > 1) dgt = 1;
	if ( this.properties.max >= 1000 ) dgt = 0;

	ctx.fillStyle=this.bgcolor || LiteGraph.NODE_DEFAULT_BGCOLOR;
	ctx.beginPath();
		ctx.roundRect( 3, 2, this.size[0]-6.5, 16, 3);
	ctx.fill();
	if ( this.flags.collapsed )
	{
		ctx.lineWidth = 0.2;
		ctx.strokeStyle = LiteGraph.EDITOR_BACKGROUND;
		ctx.stroke();
	}
	ctx.lineWidth = 1;

	ctx.fillStyle="#222";
	ctx.fillRect( sl, 8, this.size[0]-sr-sl, 4);
	ctx.beginPath();
		ctx.arc(this.size[0]-sr, 10, 2, 0, 2 * Math.PI, false);
	ctx.fill();

	ctx.fillStyle="#888";
	ctx.fillRect( sl, 8, (this.size[0]-sr-sl)*this.internal.position, 4);
	ctx.beginPath();
		ctx.arc(sl, 10, 2, 0, 2 * Math.PI, false);
	ctx.fill();

	ctx.fillStyle="#AAA";
	ctx.beginPath();
		ctx.arc(sl+(this.size[0]-sr-sl)*this.internal.position, 10, 6, 0, 2 * Math.PI, false);
	ctx.fill();

	ctx.fillStyle="#AAA";
	ctx.font = (this.local.fontsize) + "px Arial";
	ctx.textAlign = "center";
	ctx.fillText(parseFloat(this.properties.value).toFixed(dgt), this.size[0]-sr+20, (10+this.local.fontsize/3));

}

WidgetHSlider.prototype.onExecute = function()
{
	this.setOutputData(0, [parseFloat(this.properties.value)] );
}

WidgetHSlider.prototype.onMouseDown = function(e)
{
	if ( e.canvasX < this.pos[0]+this.local.shiftLeft-5 || e.canvasX > this.pos[0]+this.size[0]-this.local.shiftRight+5 ) return false;
	if (e.canvasY - this.pos[1] < 0) return false;
	this.capture = true;
	this.captureInput(true);
	this.onMouseMove(e);
	return true;
}

WidgetHSlider.prototype.onMouseMove = function(e)
{
	if (!this.capture) return;
	var v = (e.canvasX - this.pos[0] - this.local.shiftLeft)/(this.size[0]-this.local.shiftRight-this.local.shiftLeft);
	if ( v < 0 ) { v = 0 } else if ( v > 1 ) { v = 1 }
	this.internal.position = v;
	this.properties.value = this.properties.min + (this.properties.max - this.properties.min) * this.internal.position;
	this.properties.value = this.properties.value.toFixed(this.properties.digits);
	this.updateThisNodeGraph();
	this.graph.setisChangedFlag(this.id);
}

WidgetHSlider.prototype.onMouseUp = function()
{
	this.capture = false;
	this.captureInput(false);
}

WidgetHSlider.prototype.onMouseWheel = function(e)
{
	var v = this.internal.position;
	var delta = e.wheelDeltaY || e.wheelDeltaX; delta = delta/12000;
	if (delta>0.01) delta = 0.01;
	if (delta<-0.01) delta = -0.01;

	var time = LiteGraph.getTime();
	if ( time - this.local.wheelTime < 50 ) { delta *=5 }
	else if ( time - this.local.wheelTime < 100 ) { delta *=2; }
	this.local.wheelTime = time;
	v += delta;
	if (v > 1.0) { v = 1.0 } else if (v < 0.0) { v = 0.0 }

	this.internal.position = v;
	this.properties.value = this.properties.min + (this.properties.max - this.properties.min) * this.internal.position;
	this.properties.value = this.properties.value.toFixed(this.properties.digits);
	this.updateThisNodeGraph();
	this.graph.setisChangedFlag(this.id);
}

LiteGraph.registerNodeType("Widget/Slider", WidgetHSlider );


// Widget Slider 2D

function WidgetSlider2D()
{
	this.size = [150,120];
	this.minsize = [150,120];
	this.addOutput("",'numarray');
	this.addOutput("",'numarray');
	this.local = { shiftLeft:10, shiftRight:40, fontsize:12 };
	this.properties = { min_X:0, max_X:10, min_Y:0, max_Y:10, digits_X:1, digits_Y:1, value_X:"5.0", value_Y:"5.0" };
	this.internal = { positionX:0.5, positionY:0.5 };
}

WidgetSlider2D.title = "Slider2D";
WidgetSlider2D.desc = "Linear 2D slider controller";

WidgetSlider2D.prototype.onAdded = function()
{
	this.internal.positionX = (this.properties.value_X - this.properties.min_X) / (this.properties.max_X - this.properties.min_X);
	this.internal.positionY = (this.properties.value_Y - this.properties.min_Y) / (this.properties.max_Y - this.properties.min_Y);
}

WidgetSlider2D.prototype.onPropertyChange = function()
{
	this.properties.value_X = parseFloat(this.properties.value_X.replace(',', '.'));
	this.properties.value_Y = parseFloat(this.properties.value_Y.replace(',', '.'));
	if ( isNaN(this.properties.value_X) ) this.properties.value_X = this.properties.min_X;
	if ( isNaN(this.properties.value_Y) ) this.properties.value_Y = this.properties.min_Y;
	if ( this.properties.min_X >= this.properties.max_X ) this.properties.max_X = this.properties.min_X+1;
	if ( this.properties.min_Y >= this.properties.max_Y ) this.properties.max_Y = this.properties.min_Y+1;
	if ( this.properties.value_X < this.properties.min_X ) this.properties.value_X = this.properties.min_X;
	if ( this.properties.value_Y < this.properties.min_Y ) this.properties.value_Y = this.properties.min_Y;
	if ( this.properties.value_X > this.properties.max_X ) this.properties.value_X = this.properties.max_X;
	if ( this.properties.value_Y > this.properties.max_Y ) this.properties.value_Y = this.properties.max_Y;
	this.properties.digits_X = Math.floor(this.properties.digits_X);
	this.properties.digits_Y = Math.floor(this.properties.digits_Y);
	if (this.properties.digits_X>12) this.properties.digits_X = 12;
	if (this.properties.digits_Y>12) this.properties.digits_Y = 12;
	if (this.properties.digits_X<0) this.properties.digits_X = 0;
	if (this.properties.digits_Y<0) this.properties.digits_Y = 0;
	this.internal.positionX = (this.properties.value_X-this.properties.min_X)/(this.properties.max_X-this.properties.min_X);
	this.internal.positionY = (this.properties.value_Y-this.properties.min_Y)/(this.properties.max_Y-this.properties.min_Y);
	this.properties.value_X = this.properties.value_X.toFixed(this.properties.digits_X);
	this.properties.value_Y = this.properties.value_Y.toFixed(this.properties.digits_Y);
	this.size[1] = this.size[0]-this.local.shiftRight+this.local.shiftLeft;
}

WidgetSlider2D.prototype.onDrawForeground = function(ctx)
{
	var sr = this.local.shiftRight, sl = this.local.shiftLeft;
	var dgtX = parseInt(this.properties.digits_X);
	var dgtY = parseInt(this.properties.digits_Y);
	if ( dgtX > 2 ) dgtX = 2;
	if ( dgtY > 2 ) dgtY = 2;
	if ( this.properties.max_X >= 100 && dgtX > 1) dgtX = 1;
	if ( this.properties.max_Y >= 100 && dgtY > 1) dgtY = 1;
	if ( this.properties.max_X >= 1000 ) dgtX = 0;
	if ( this.properties.max_Y >= 1000 ) dgtY = 0;

//	ctx.lineWidth = 1;
	ctx.fillStyle=this.bgcolor || LiteGraph.NODE_DEFAULT_BGCOLOR;
	ctx.fillRect( 3, 3, this.size[0]-6.5, this.size[1]-6.5);
	
	ctx.fillStyle="#222";
	ctx.beginPath();
	ctx.roundRect( sl-4, sl-4, this.size[0]-sr-sl+8, this.size[1]-sl-sl+8,4);
	ctx.fill();

	ctx.fillStyle="#AAA";
	ctx.beginPath();
		ctx.arc(sl+(this.size[0]-sr-sl)*this.internal.positionX, sl+(this.size[1]-sl-sl)*(1-this.internal.positionY), 6, 0, 2 * Math.PI, false);
	ctx.fill();

	ctx.fillStyle="#AAA";
	ctx.font = (this.local.fontsize) + "px Arial";
	ctx.textAlign = "center";
	ctx.fillText(parseFloat(this.properties.value_X).toFixed(dgtX), this.size[0]-sr+20, (10+this.local.fontsize/3));
	ctx.fillText(parseFloat(this.properties.value_Y).toFixed(dgtY), this.size[0]-sr+20, (26+this.local.fontsize/3));
}

WidgetSlider2D.prototype.onExecute = function()
{
	this.setOutputData(0, [parseFloat(this.properties.value_X)] );
	this.setOutputData(1, [parseFloat(this.properties.value_Y)] );
}

WidgetSlider2D.prototype.onMouseDown = function(e)
{
	if ( e.canvasX < this.pos[0]+this.local.shiftLeft-5 || e.canvasX > this.pos[0]+this.size[0]-this.local.shiftRight+5 ) return false;
	if ( e.canvasY < this.pos[1]+this.local.shiftLeft-5 || e.canvasY > this.pos[1]+this.size[1]-this.local.shiftLeft+5 ) return false;
	if (e.canvasY - this.pos[1] < 0) return false;
	this.capture = true;
	this.captureInput(true);
	this.onMouseMove(e);
	return true;
}

WidgetSlider2D.prototype.onMouseMove = function(e)
{
	if (!this.capture) return;
	var vX = (e.canvasX - this.pos[0] - this.local.shiftLeft)/(this.size[0]-this.local.shiftRight-this.local.shiftLeft);
	var vY = 1-(e.canvasY - this.pos[1] - this.local.shiftLeft)/(this.size[1]-this.local.shiftLeft-this.local.shiftLeft);
	if ( vX < 0 ) { vX = 0 } else if ( vX > 1 ) { vX = 1 }
	if ( vY < 0 ) { vY = 0 } else if ( vY > 1 ) { vY = 1 }
	this.internal.positionX = vX;
	this.internal.positionY = vY;
	this.properties.value_X = this.properties.min_X + (this.properties.max_X - this.properties.min_X) * this.internal.positionX;
	this.properties.value_Y = this.properties.min_Y + (this.properties.max_Y - this.properties.min_Y) * this.internal.positionY;
	this.properties.value_X = this.properties.value_X.toFixed(this.properties.digits_X);
	this.properties.value_Y = this.properties.value_Y.toFixed(this.properties.digits_Y);
	this.updateThisNodeGraph();
	this.graph.setisChangedFlag(this.id);
}

WidgetSlider2D.prototype.onMouseUp = function()
{
	this.capture = false;
	this.captureInput(false);
}

LiteGraph.registerNodeType("Widget/Slider2D", WidgetSlider2D );


// Widget RngSlider

function WidgetRngSlider()
{
	this.size = [200,20];
	this.minsize = [200,20];
	this.addOutput("",'numarray');
	this.local = { shiftLeft:14, shiftRight:80, fontsize:12 };
	this.properties = { min:0, max:10, digits:1, from:"0.0", to:"10.0" };
	this.internal = { positionF:0.0, positionT:1.0 };
}

WidgetRngSlider.title = "Range";
WidgetRngSlider.desc = "Linear range controller";

WidgetRngSlider.prototype.onAdded = function()
{
	this.internal.positionF = (this.properties.from - this.properties.min) / (this.properties.max - this.properties.min);
	this.internal.positionT = (this.properties.to - this.properties.min) / (this.properties.max - this.properties.min);
}

WidgetRngSlider.prototype.onPropertyChange = function(prop)
{
	this.properties.from = parseFloat(this.properties.from.replace(',', '.'));
	this.properties.to = parseFloat(this.properties.to.replace(',', '.'));
	if ( isNaN(this.properties.from) ) this.properties.from = this.properties.min;
	if ( isNaN(this.properties.to) ) this.properties.to = this.properties.max;

	this.properties.digits = Math.floor(this.properties.digits);
	if (this.properties.digits>15) this.properties.digits = 15;
	if (this.properties.digits<0) this.properties.digits = 0;
	var s = 1/Math.pow(10,this.properties.digits);

	this.properties.from = this.properties.from.toFixed(this.properties.digits)*1.0;
	this.properties.to = this.properties.to.toFixed(this.properties.digits)*1.0;
	this.properties.max = this.properties.max.toFixed(this.properties.digits)*1.0;
	this.properties.min = this.properties.min.toFixed(this.properties.digits)*1.0;
	
	if (prop === "max" || prop === "digits")
	{
		if ( this.properties.max <= this.properties.min ) this.properties.max = this.properties.min+s;
	}

	if (prop === "min" || prop === "digits")
	{
		if ( this.properties.min >= this.properties.max ) this.properties.min = this.properties.max-s;
	}

	if (prop === "to" || prop === "max" || prop === "digits")
	{
		if ( this.properties.to <= this.properties.from ) this.properties.to = this.properties.from+s;
		if ( this.properties.to > this.properties.max ) this.properties.to = this.properties.max;
		if ( this.properties.from >= this.properties.to ) this.properties.from = this.properties.to-s;
	}

	if (prop === "from" || prop === "min" || prop === "digits")
	{
		if ( this.properties.from >= this.properties.to ) this.properties.from = this.properties.to-s;
		if ( this.properties.from < this.properties.min ) this.properties.from = this.properties.min;
		if ( this.properties.to <= this.properties.from ) this.properties.to = this.properties.from+s;
	}

	this.internal.positionF = (this.properties.from-this.properties.min)/(this.properties.max-this.properties.min);
	this.internal.positionT = (this.properties.to-this.properties.min)/(this.properties.max-this.properties.min);

	this.properties.from = this.properties.from.toFixed(this.properties.digits);
	this.properties.to = this.properties.to.toFixed(this.properties.digits);
}

WidgetRngSlider.prototype.onDrawForeground = function(ctx)
{
	var sr = this.local.shiftRight, sl = this.local.shiftLeft, sf = sl+(this.size[0]-sr-sl)*this.internal.positionF, st = sl+(this.size[0]-sr-sl)*this.internal.positionT;
	var dgt = parseInt(this.properties.digits);
	if ( dgt > 2 ) dgt = 2;
	if ( this.properties.max >= 100 && dgt > 1) dgt = 1;
	if ( this.properties.max >= 1000 ) dgt = 0;

//	ctx.lineWidth = 1;
	ctx.fillStyle=this.bgcolor || LiteGraph.NODE_DEFAULT_BGCOLOR;
	ctx.fillRect( 3, 2, this.size[0]-6.5, 16);
	
	ctx.fillStyle="#222";
	ctx.fillRect( sl, 8, this.size[0]-sr-sl, 4);
	ctx.beginPath();
		ctx.arc(this.size[0]-sr, 10, 2, 0, 2 * Math.PI, false);
	ctx.fill();
	ctx.beginPath();
		ctx.arc(sl, 10, 2, 0, 2 * Math.PI, false);
	ctx.fill();

	ctx.fillStyle="#888";
	ctx.fillRect( sl+(this.size[0]-sr-sl)*this.internal.positionF, 8, (this.size[0]-sr-sl)*this.internal.positionT-(this.size[0]-sr-sl)*this.internal.positionF, 4);

	ctx.fillStyle="#AAA";
	ctx.beginPath();
		ctx.moveTo(sf,18);
		ctx.lineTo(sf,2);
		ctx.lineTo(sf-6,6);
		ctx.lineTo(sf-6,14);
	ctx.fill();
	ctx.beginPath();
		ctx.moveTo(st,18);
		ctx.lineTo(st,2);
		ctx.lineTo(st+6,6);
		ctx.lineTo(st+6,14);
	ctx.fill();

	ctx.fillStyle="#AAA";
	ctx.font = (this.local.fontsize) + "px Arial";
	ctx.textAlign = "center";
	ctx.fillText(parseFloat(this.properties.from).toFixed(dgt)+".."+parseFloat(this.properties.to).toFixed(dgt), this.size[0]-sr+40, (10+this.local.fontsize/3));

}

WidgetRngSlider.prototype.onExecute = function()
{
	this.setOutputData(0, [parseFloat(this.properties.from),parseFloat(this.properties.to)] );
}

WidgetRngSlider.prototype.onMouseDown = function(e)
{
	if ( e.canvasX < this.pos[0]+this.local.shiftLeft-5 || e.canvasX > this.pos[0]+this.size[0]-this.local.shiftRight+5 ) return false;
	if (e.canvasY - this.pos[1] < 0) return false;
	var v = (e.canvasX-this.pos[0]-this.local.shiftLeft)/(this.size[0]-this.local.shiftLeft-this.local.shiftRight);
	this.movefrom = ( Math.abs(v-this.internal.positionF) < Math.abs(v-this.internal.positionT) )?true:false;
	this.moveto = !this.movefrom;
	this.capture = true;
	this.captureInput(true);
	this.onMouseMove(e);
	return true;
}

WidgetRngSlider.prototype.onMouseMove = function(e)
{
	if (!this.capture) return;
	var v = (e.canvasX - this.pos[0] - this.local.shiftLeft)/(this.size[0]-this.local.shiftRight-this.local.shiftLeft);
	var s = Math.pow(0.1,this.properties.digits)/(this.properties.max - this.properties.min);
	if (this.movefrom)
	{
		if ( v < 0 ) { v = 0 } else if ( v > this.internal.positionT-s ) { v = this.internal.positionT-s }
		this.internal.positionF = v;
		this.properties.from = this.properties.min + (this.properties.max - this.properties.min) * this.internal.positionF;
		this.properties.from = this.properties.from.toFixed(this.properties.digits);
	}
	if (this.moveto)
	{
		if ( v > 1 ) { v = 1 } else if ( v < this.internal.positionF+s ) { v = this.internal.positionF+s }
		this.internal.positionT = v;
		this.properties.to = this.properties.min + (this.properties.max - this.properties.min) * this.internal.positionT;
		this.properties.to = this.properties.to.toFixed(this.properties.digits);
	}
	this.updateThisNodeGraph();
	this.graph.setisChangedFlag(this.id);
}

WidgetRngSlider.prototype.onMouseUp = function()
{
	this.capture = false;
	this.movefrom = false;
	this.moveto = false;
	this.captureInput(false);
}

LiteGraph.registerNodeType("Widget/RngSlider", WidgetRngSlider );


// Widget Switch

function Switch()
{
	this.size = [40,40];
	this.minsize = [40,40];
	this.dynamicInputs = ["*"];
	this.dynamicOutputs = [0];
	this.addInput("",'numarray');
	this.addInput("",'numarray');
	this.addOutput("",'numarray');
	this.properties = { mode:["Switch","Switch","Button"] }
	this.local = {csize:30};
	this.internal = { on:0 };
}

Switch.title = "Switch";
Switch.desc = "Switch";

Switch.prototype.onPropertyChange = function()
{
	this.internal.on = 0;
}

Switch.prototype.getExtraMenuOptions = function()
{
	var that = this;
	return [
	{content:lang.getTranslation("Numbers"), callback: function() { if (that.inputs[0].type !== "numarray" ) { that.changeOutputType(0,"numarray", ""); that.changeInputType(0,"numarray", ""); that.changeInputType(1,"numarray", ""); }}},
	{content:lang.getTranslation("Points"), callback: function() { if (that.inputs[0].type !== "pointarray" ) { that.changeOutputType(0,"pointarray", ""); that.changeInputType(0,"pointarray", ""); that.changeInputType(1,"pointarray", ""); }}},
	{content:lang.getTranslation("Objects"), callback: function() { if (that.inputs[0].type !== "objectlist" ) { that.changeOutputType(0,"objectlist", ""); that.changeInputType(0,"objectlist", ""); that.changeInputType(1,"objectlist", ""); }}}
	];
}

Switch.prototype.onDrawVectorSwitch = function(ctx)
{
	var lineWidth = 3;
	var xmin = lineWidth*2;
	var xmax = this.size[0] - lineWidth*2;
	var y = (this.internal.on)?10+LiteGraph.NODE_SLOT_HEIGHT:10;
	var xshift = (xmax-xmin)/3;
	if (xshift>LiteGraph.NODE_SLOT_HEIGHT) xshift = (xmax-xmin-LiteGraph.NODE_SLOT_HEIGHT)/2;
	ctx.beginPath();
		ctx.lineWidth = lineWidth+2;
		ctx.strokeStyle = LiteGraph.link_type_colors.border;
		ctx.moveTo(xmin-1, y);
		ctx.bezierCurveTo(xmin+0.5+(xmax-xmin)/2, y, xmax-0.5-(xmax-xmin)/2, 10, xmax+1, 10);
	ctx.stroke();
	ctx.beginPath();
		ctx.lineWidth = lineWidth;
		if (this.isInputConnected(this.internal.on*1)) { ctx.strokeStyle = LGraphCanvas.link_type_colors[this.inputs[0].type];}
		else ctx.strokeStyle = LiteGraph.NODE_DEFAULT_COLOR;
		ctx.moveTo(xmin, y);
		ctx.bezierCurveTo(xmin+(xmax-xmin)/2, y, xmax-(xmax-xmin)/2, 10, xmax, 10);
	ctx.stroke();
}

Switch.prototype.onDrawForeground = function(ctx)
{
	this.onDrawVectorSwitch(ctx);
}

Switch.prototype.onExecute = function()
{
	var inp = (this.internal.on)?this.getInputData(1):this.getInputData(0);
	this.setOutputData(0, inp );
}

Switch.prototype.onMouseDown = function(e, skipcapture)
{
	if ( skipcapture ) return true;
	if (e.canvasY - this.pos[1] < 0) return false;
	this.internal.on = 1 - this.internal.on;
	this.graph.setisChangedFlag(this.id);
	this.setDirtyCanvas(true, true);
	this.captureInput(true);
	return true;
}

Switch.prototype.onMouseUp = function(e)
{
	if ( this.properties.mode[0] === this.properties.mode[2] )
	{
		this.internal.on = 0;
		this.graph.setisChangedFlag(this.id);
		this.setDirtyCanvas(true, true);
	}
	this.captureInput(false);
}

Switch.prototype.onMouseLeave = function()
{
	this.onMouseUp();
}

LiteGraph.registerNodeType("Widget/Switch", Switch );

})();