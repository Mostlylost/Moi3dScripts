// MoI Nodeedit
// Basic nodes v.1.0 - Max Smirnov, 2018
// litegraph.js library (c) Javi Agenjo http://tamats.com

(function(){


// Constant
function Constant()
{
	this.minsize = [20, 0];
	this.addOutput("value","numarray",{label:"1"});
	this.properties = { value:[1] };
}

Constant.title = "Const";
Constant.desc = "Constant value";

Constant.prototype.onAdded = function()
{
	this.onPropertyChange();
}

Constant.prototype.onPropertyChange = function()
{
	var s = this.properties.value.toString();
	this.outputs[0].label = (s.length > 16)?lang.getTranslation("Array")+"("+this.properties.value.length+")":s;
	this.computeSize();
};

Constant.prototype.onExecute = function()
{
	this.setOutputData(0, this.properties.value );
}

LiteGraph.registerNodeType("Basic/Constant", Constant);

// Point
function Point()
{
//	this.minsize = [100, 0];
	this.addInput("X","numarray");
	this.addInput("Y","numarray");
	this.addInput("Z","numarray");
	this.addOutput("Point","pointarray");
	this.addOutput("Object","objectlist");
	this.properties = {mode:["Long","Long","Short"], x:[0], y:[0], z:[0]};
}

Point.title = "Point";
Point.desc = "Point";

Point.prototype.onExecute = function()
{
	var data = this.processInOut(this.properties.mode[0], this.multiProcess, this.properties.x, this.properties.y, this.properties.z );
	this.properties.x = data.inputs[0];
	this.properties.y = data.inputs[1];
	this.properties.z = data.inputs[2];
	this.setOutputData(0, data.outputs[0]);
	this.setOutputData(1, data.outputs[1]);
}

Point.prototype.multiProcess = function(x,y,z)
{
	var out = [];
	out[0] = new pointArray(true, x, y, z);
	out[1] = factory('point', out[0].getPoint(0));
	return out;
}

LiteGraph.registerNodeType("Basic/Point", Point);

// MathFunc
function MathFunc()
{
	this.internal = {}
	this.dynamicProperties = ["a","b","c","d"];
	this.properties = { mode:["Long","Long","Short"], f:"a+b", preset:["a+b", "a+b", "a-b", "a*b", "a/b", "sin[a]", "cos[a]", "pow(a,b)"], a:[1], b:[1]};
}

MathFunc.title = "Math";
MathFunc.desc = "MathFunction";

MathFunc.prototype.onAdded = function()
{
	if ( this.properties.hasOwnProperty("a") && this.inputs.length < 1) this.addInput("a","numarray");
	if ( this.properties.hasOwnProperty("b") && this.inputs.length < 2) this.addInput("b","numarray");
	if ( this.properties.hasOwnProperty("c") && this.inputs.length < 3) this.addInput("c","numarray");
	if ( this.properties.hasOwnProperty("d") && this.inputs.length < 4) this.addInput("d","numarray");
	if (this.outputs.length < 1 ) this.addOutput(this.properties.f, "numarray");
	this.checkFunction();
}

MathFunc.prototype.checkFunction = function()
{
	var valid = true;
	var fnc = this.properties.f;
	fnc = fnc.replace(/rnd/g, "random()");
	fnc = fnc.replace(/\[/g, "(pi/180*(");
	fnc = fnc.replace(/\]/g, "))");
	fnc = fnc.replace(/(?:[a-z$_][a-z0-9$_]*)|(?:[;={}"'!&<>^\\?:])/ig,
		function ($0)
		{
			if (Math.hasOwnProperty($0)) return "Math."+$0;
			else if (Math.hasOwnProperty($0.toUpperCase())) return "Math."+$0.toUpperCase();
			else if ( $0.toLowerCase() === 'a' || $0.toLowerCase() === 'b' || $0.toLowerCase() === 'c' || $0.toLowerCase() === 'd' ) return $0.toLowerCase();
			else	valid = false;
		});
	this.internal.valid = valid;
	this.internal.fnc = fnc;
}

MathFunc.prototype.onPropertyChange = function( property, value )
{
	if ( property === 'preset' ) this.properties['f'] = value;
	this.outputs[0].label = this.properties['f'];
	this.checkFunction();
	this.computeSize();
};

MathFunc.prototype.onGetInputs = function()
{
	var str = "abcd", list = [];
	for ( var i = 0; i<str.length; i++ )
	{
		var inp = str.charAt(i);
		if ( !(inp in this.properties)) { list.push([inp,"numarray", {locked:true}]); break; }
	}
	return list;
}

MathFunc.prototype.onInputAdded = function(inp)
{
	if ( !(inp.name in this.properties)) this.properties[inp.name] = [1];
	for ( var i in this.inputs ) this.inputs[i].locked = true;
	this.inputs[i].locked = false;
	this.setDirtyCanvas(true);
}

MathFunc.prototype.onInputRemoved = function(slot, name)
{
	if ( this.properties[name] ) delete this.properties[name];
	for ( var i in this.inputs ) this.inputs[i].locked = true;
	if ( this.inputs.length > 0 )this.inputs[i].locked = false;
}

MathFunc.prototype.getExtraMenuOptions = function() { var that = this, thatgraph = this.graph; return [{content:lang.getTranslation("Update"), callback: function() { thatgraph.setisChangedFlag(that.id) }}]; }

MathFunc.prototype.onExecute = function()
{
	var i = this.inputs.length;
	var data = this.processInOut(this.properties.mode[0], this.multiProcess, this.properties.a, this.properties.b, this.properties.c, this.properties.d );

	if ( i>0 ) { this.properties.a = data.inputs[0] }
	if ( i>1 ) { this.properties.b = data.inputs[1] }
	if ( i>2 ) { this.properties.c = data.inputs[2] }
	if ( i>3 ) { this.properties.d = data.inputs[3] }
	this.setOutputData(0, data.outputs[0]);
}

MathFunc.prototype.multiProcess = function(a,b,c,d)
{
	var output;
	if (this.internal.valid)
	{
		try { output = eval(this.internal.fnc) }
		catch (e) { output = 0 }
		if ( output === 'Infinity' ) { output = 99999999 }
		if ( output === '-Infinity' ) { output = -99999999 }
		if ( typeof ( output ) !=='number' ) { output = 0 }
		if ( isNaN( output ) ) { output = 0  }
	}
	else { output = 0 }
	return [output];
}

LiteGraph.registerNodeType("Basic/MathFunc", MathFunc);

// Interp
function Interp()
{
	this.addInput("In","numarray");
	this.addInput("C","numarray");
	this.addOutput("Out","numarray");
	this.properties = { mode:["Cosine","Linear","Cosine","Cubic","CatmullRom","Hermite","FritschCarlson"], array:[0,10], count:[10] };
}

Interp.title = "Interp";
Interp.desc = "Interp";

Interp.prototype.onExecute = function()
{
	this.properties.array = this.getInputData(0, this.properties.array);
	this.properties.count = this.getInputData(1, this.properties.count);
	var out = new InterpArray(this.properties.array, this.properties.mode[0]);
	this.setOutputData(0, out.generateArray(this.properties.count));
}

LiteGraph.registerNodeType("Basic/Interp", Interp);

// Random
function Random()
{
	this.minsize = [20, 0];
	this.addInput("C","numarray");
	this.addOutput("Out","numarray");
	this.properties = { count:[1] };
}

Random.title = "Random";
Random.desc = "Random value";

Random.prototype.onPropertyChange = function()
{
	if (this.properties.count[0] < 1) { this.properties.count = [1] } else { this.properties.count = [Math.floor(this.properties.count[0])] }
};

Random.prototype.getExtraMenuOptions = function() { var that = this, thatgraph = this.graph; return [{content:lang.getTranslation("Update"), callback: function() { thatgraph.setisChangedFlag(that.id) }}]; }

Random.prototype.onExecute = function()
{
	this.properties.count = this.getInputData(0, this.properties.count);
	var out = [];
	for (var i = this.properties.count[0]; i>0; i--) out.push(Math.random());
	this.setOutputData(0, out );
}

LiteGraph.registerNodeType("Basic/Random", Random);

// Quartz
function Quartz()
{
	this.addInput("Hz","numarray");
	this.addOutput("Out","numarray");
	this.internal = { hz:[0] };
	this.properties = { value:[0], start:[0], end:[360], step:[1], mode:["Cycled", "Cycled", "Tic-tac"]};
	this.local = { starttime:0 };
	this.isImmortal = true;
}

Quartz.title = "Quartz";
Quartz.desc = "Quartz clock";

Quartz.prototype.onAdded = function()
{
	this.onStart();
}

Quartz.prototype.onStart = function()
{
	this.local.starttime = LiteGraph.getTime();
	this.local.startvalue = this.properties.value[0];
	this.local.startstep = this.properties.step[0];
}

Quartz.prototype.onPropertyChange = function( property )
{
	if ( this.properties.mode[0] === "Cycled" && (this.properties.end[0]-this.properties.start[0])*this.properties.step[0] < 0) { this.properties.step[0] *= -1 }
	if ( this.properties.start[0] === this.properties.end[0] ) this.properties.end[0] = this.properties.start[0] + this.properties.step[0];
	if ( property === 'mode' ) this.onStart();
}

Quartz.prototype.onExecute = function()
{
	var hz = this.getInputData(0, [0]);
	var stepsPerCycle;
	var vl = this.properties.value[0];
	var start = this.properties.start[0];
	var end = this.properties.end[0];
	var step = this.local.startstep;

	if ( hz[0] !== this.internal.hz[0] ) { this.onStart(); this.internal.hz[0] = hz[0]; }
	if ( hz[0] > 0 )
	{
		if (this.graph.status === LGraph.STATUS_RUNNING)
		{
		 	var time = LiteGraph.getTime() - this.local.starttime;

		 	if (this.properties.mode[0] === "Cycled" )
		 	{
		 		stepsPerCycle = Math.abs((end - start)/step);
		 		vl = this.local.startvalue + Math.floor( (time % (1000/hz[0])) / (1000/hz[0]) * stepsPerCycle ) * step;
		 		if ( end > start ) if ( vl >= end ) { vl = start + (vl - start) % (end - start) }
				if ( end < start ) if ( vl <= start ) { vl = start - (start - vl) % (start - end) }
				this.properties.value[0] = vl;
		 	}
		 	else
		 	{
		 		stepsPerCycle = Math.abs((end - start)/step*2);
		 		var cstep = Math.floor( (time % (1000/hz[0])) / (1000/hz[0]) * stepsPerCycle );
		 		vl = this.local.startvalue;
		 		if ( cstep >= stepsPerCycle/2 )
		 		{
		 			cstep -= stepsPerCycle/2;
		 			step *= -1;
		 			vl = start + end - vl;
		 		}
		 		vl = vl + cstep * step;
		 		if ( end > start )
				{
					if ( vl > end ) { vl = end - (vl - start) % (end - start); step *= -1; }
					if ( vl < start ) { vl = start + (start - vl) % (end - start); step *= -1; }
				}
				else
				{
					if ( vl > start ) { vl = start - (vl - end) % (start - end); step *= -1; }
					if ( vl < end ) { vl = end + (end - vl) % (start - end); step *= -1; }
				}
		 		this.properties.value[0] = vl;
		 		this.properties.step[0] = step;
		 	}
		}
		if (this.graph.status === LGraph.STATUS_STOPPED)
		{
			this.properties.value[0] += step;
			vl = this.properties.value[0];
			if (this.properties.mode[0] === "Cycled" )
			{
				if ( end > start ) if ( vl >= end ) { this.properties.value[0] = start + (vl - start) % (end - start) }
				if ( end < start ) if ( vl <= start ) { this.properties.value[0] = start - (start - vl) % (start - end) }
			}
			else
			{
				if ( end > start )
				{
					if ( vl > end ) { this.properties.value[0] = end - (vl - start) % (end - start); this.properties.step[0] *= -1; }
					if ( vl < start ) { this.properties.value[0] = start + (start - vl) % (end - start); this.properties.step[0] *= -1; }
				}
				else
				{
					if ( vl > start ) { this.properties.value[0] = start - (vl - end) % (start - end); this.properties.step[0] *= -1; }
					if ( vl < end ) { this.properties.value[0] = end + (end - vl) % (start - end); this.properties.step[0] *= -1; }
				}
			}
		}
	}
	this.setOutputData(0, [this.properties.value[0]]);
}

LiteGraph.registerNodeType("Basic/Quartz", Quartz);

// Length
function Length()
{
	this.dynamicInputs = [0];
	this.addInput("Num","numarray");
	this.addOutput("L","numarray");
}

Length.title = "Length";
Length.desc = "Length";

Length.prototype.getExtraMenuOptions = function()
{
	var that = this;
	return [
	{content:lang.getTranslation("Numbers"), callback: function() { if (that.inputs[0].type !== "numarray" ) { that.changeInputType(0,"numarray","Num") }}},
	{content:lang.getTranslation("Points"), callback: function() { if (that.inputs[0].type !== "pointarray" ) { that.changeInputType(0,"pointarray","Pts") }}},
	{content:lang.getTranslation("Objects"), callback: function() { if (that.inputs[0].type !== "objectlist" ) { that.changeInputType(0,"objectlist","Obj") }}}
	];
}

Length.prototype.onExecute = function()
{
	var l, inp = this.getInputData(0, null, true);
	try { l = inp.length } catch(e) { l = 0 }
	this.setOutputData(0, [l] );
}

LiteGraph.registerNodeType("Basic/Length", Length);

// Concat
function Concat()
{
	this.labels = "abcdef";
	this.dynamicInputs = ["*"];
	this.dynamicOutputs = [0];
	this.dynamicInternal = ["a","b","c","d","e","f"];
	this.internal = {a:1, b:1};
	this.addOutput("Obj","objectlist");
}

Concat.title = "Concat";
Concat.desc = "Concat";

Concat.prototype.onGetInputs = function()
{
	var list = [];
	for ( var i = 0; i<this.labels.length; i++ )
	{
		var inp = this.labels.charAt(i);
		if ( !(inp in this.internal)) { list.push([this.labels.charAt(i), this.outputs[0].type, {locked:true}]); break; }
	}
	return list;
}

Concat.prototype.onInputAdded = function(inp)
{
	this.internal[inp.name] = 1;
	for ( var i in this.inputs ) this.inputs[i].locked = true;
	if (i>1) this.inputs[i].locked = false;
}

Concat.prototype.onInputRemoved = function(slot, name)
{
	if ( this.internal[name] ) delete this.internal[name];
	for ( var i in this.inputs ) this.inputs[i].locked = true;
	if ( this.inputs.length > 2 )this.inputs[i].locked = false;
}

Concat.prototype.onAdded = function()
{
	for ( var i = 0; i<this.labels.length; i++ ) if ( this.internal[this.labels.charAt(i)] && this.inputs.length === i ) this.addInput(this.labels.charAt(i), this.outputs[0].type);
	this.setDirtyCanvas(true);
}

Concat.prototype.getExtraMenuOptions = function()
{
	var that = this;
	return [
	{content:lang.getTranslation("Numbers"), callback: function() { if (that.inputs[0].type !== "numarray" ) { that.changeOutputType(0,"numarray", "Num"); for (var i=0; i<that.inputs.length; i++) that.changeInputType(i,"numarray") }}},
	{content:lang.getTranslation("Points"), callback: function() { if (that.inputs[0].type !== "pointarray" ) { that.changeOutputType(0,"pointarray", "Pts"); for (var i=0; i<that.inputs.length; i++) that.changeInputType(i,"pointarray") }}},
	{content:lang.getTranslation("Objects"), callback: function() { if (that.inputs[0].type !== "objectlist" ) { that.changeOutputType(0,"objectlist", "Obj"); for (var i=0; i<that.inputs.length; i++) that.changeInputType(i,"objectlist") }}}
	];
}

Concat.prototype.onExecute = function()
{
	var out, i, j;
	if ( this.outputs[0].type === "numarray")
	{
		out = [];
		for ( i = 0; i<this.inputs.length; i++) out = out.concat(this.getInputData(i, []));
		if (out.length === 0) out = [0];
	}
	else if ( this.outputs[0].type === "pointarray")
	{
		out = new pointArray();
		for ( i = 0; i<this.inputs.length; i++) out.concat(this.getInputData(i, new pointArray()));
	}
	else if ( this.outputs[0].type === "objectlist")
	{
		var inObj;
		out = moi.geometryDatabase.createObjectList();
		for ( i = 0; i<this.inputs.length; i++)
		{
			inObj = this.getInputData(i, moi.geometryDatabase.createObjectList());
			for ( j = 0; j < inObj.length; j++ ) out.addObject( inObj.item(j) );
		}
	}
	this.setOutputData(0, out);
}

LiteGraph.registerNodeType("Basic/Concat", Concat);

// Progression
function Progression()
{
	this.addInput("Base","numarray");
	this.addInput("Factor","numarray");
	this.addInput("Count","numarray");
	this.addOutput("Out","numarray");
	this.properties = { type:["Arithmetic","Arithmetic","Geometric"], base:[1], factor:[2], count:[10] };
}

Progression.title = "Progression";
Progression.desc = "Progression";

Progression.prototype.onExecute = function()
{
	this.properties.base   = this.getInputData(0, this.properties.base);
	this.properties.factor = this.getInputData(1, this.properties.factor);
	this.properties.count  = this.getInputData(2, this.properties.count);
	var out = [], v = this.properties.base[0], f = this.properties.factor[0], c = this.properties.count[0], i;
	if (this.properties.type[0] === "Arithmetic") for ( i=c; i>0; i-- ) { out.push(v); v += f }
	if (this.properties.type[0] === "Geometric")  for ( i=c; i>0; i-- ) { out.push(v); v *= f }
	this.setOutputData(0, out );
}

LiteGraph.registerNodeType("Basic/Progression", Progression);

// Extract
function Extract()
{
	this.dynamicInputs = [0];
	this.dynamicOutputs = [0];
	this.dynamicProperties = ["element"];
	this.addInput("Pts","pointarray");
	this.addOutput("X","numarray");
	this.local = {pointarray:["X", "X", "Y", "Z", "rX", "rY", "rZ", "Scale"], numarray:["Min", "Min", "Max", "Average"]};
	this.properties = {element:this.local.pointarray};
}

Extract.title = "Extract";
Extract.desc = "Extract";

Extract.prototype.getExtraMenuOptions = function()
{
	var that = this;
	var thatgraph = this.graph;
	return [
	{content:lang.getTranslation("Numbers"), callback: function() { if (that.inputs[0].type !== "numarray" ) { that.changeInputType(0,"numarray","Num"); that.properties.element = that.local.numarray; thatgraph.refreshNodeInfo(that.id); that.onPropertyChange();}}},
	{content:lang.getTranslation("Points"), callback: function() { if (that.inputs[0].type !== "pointarray" ) { that.changeInputType(0,"pointarray","Pts"); that.properties.element = that.local.pointarray; thatgraph.refreshNodeInfo(that.id); that.onPropertyChange();}}}
	];
}

Extract.prototype.onAdded = function()
{
	this.onPropertyChange();
}

Extract.prototype.onPropertyChange = function()
{
	this.outputs[0].label = this.properties.element[0];
	this.computeSize();
}

Extract.prototype.onExecute = function()
{
	var element = this.properties.element.lastIndexOf(this.properties.element[0]);
	var type = this.inputs[0].type, inp, out, i, o;

	if ( type === "pointarray")
	{
		inp = this.getInputData(0, new pointArray(true));
		out = [];
		var step = inp.recordLength;
		var base = element-1;
		for ( i = 0; i<inp.length; i++) { out.push(inp.data[base]); base +=step; }
	}
	else if ( type === "numarray")
	{
		inp = this.getInputData(0, [0]);
		switch (element)
		{
			case 1:	o = 1e99; for ( i = 0; i<inp.length; i++) if ( inp[i] < o ) o = inp[i];	break;
			case 2:	o = -1e99; for ( i = 0; i<inp.length; i++) if ( inp[i] > o ) o = inp[i]; break;
			case 3:	o = 0; for ( i = 0; i<inp.length; i++) o += inp[i];	o /= inp.length; break;
		}
		out = [o];
	}

	this.setOutputData(0, out);
}

LiteGraph.registerNodeType("Basic/Extract", Extract);

// MoI Output
function MoIOutput()
{
	this.minsize = [70, 0];
	this.boxcolor = "#F05";
	this.addInput("","objectlist");
	this.flags = { isOutput: true };
	this.properties = {style:["--", "--"], edges:["On", "Off", "On"]};
	this.sIndex = -1;
	this.tempobjects = moi.geometryDatabase.createObjectList();
}

MoIOutput.title = "Output";
MoIOutput.desc = "Output";

MoIOutput.prototype.onClear = function()
{
	moi.geometryDatabase.removeObjects(this.tempobjects);
	this.tempobjects = moi.geometryDatabase.createObjectList();
}

MoIOutput.prototype.onAdded = function()
{
	if ( !this.properties ) { this.properties = {style:["--", "--"]} } else { if (!this.properties.style) this.properties.style = ["--", "--"]}
	this.properties.style = this.properties.style.slice(0,2);
	var styles = moi.geometryDatabase.getObjectStyles();
	for ( var n=0; n<styles.length; n++ ) this.properties.style.push(styles.item(n).name);
	this.updateStyles();
}

MoIOutput.prototype.onRemoved = function()
{
	this.onClear();
}

MoIOutput.prototype.updateStyles = function()
{
	var styles = moi.geometryDatabase.getObjectStyles();
	this.sIndex = -1;
	for ( var x=0; x<styles.length; x++ ) if ( this.properties.style[0] === styles.item(x).name ) { this.sIndex = x; break; }
}

MoIOutput.prototype.updateObjects = function()
{
	this.onClear();
	var changeStyle = (this.properties.style[0] !== this.properties.style[1] && this.sIndex !== -1);
	var inObj = this.getInputData(0, moi.geometryDatabase.createObjectList());
	for ( var i = 0; i<inObj.length; i++) this.tempobjects.addObject(changeStyle?inObj.item(i).clone():inObj.item(i));
	for ( var i = this.tempobjects.length; i > 0; ) this.tempobjects.item(--i).setHitTest(0);
	if (changeStyle) this.tempobjects.setProperty( 'styleIndex', this.sIndex);
	if (this.properties.edges[0] === "Off") for ( var breps = this.tempobjects.getBReps(), i = breps.length; i > 0; ) { breps.item(--i).getEdges().setProperty( 'hidden', true ); }
	moi.geometryDatabase.addObjects(this.tempobjects);
}

MoIOutput.prototype.onPropertyChange = function(property)
{
	this.updateStyles();
	this.updateObjects();
	if ( property === "edges" ) if (this.properties.edges[0] === "On") for ( var breps = this.tempobjects.getBReps(), i = breps.length; i > 0; ) { breps.item(--i).getEdges().setProperty( 'hidden', false ); }
}

MoIOutput.prototype.onApply = function()
{
	var newobjects = moi.geometryDatabase.createObjectList();
	for ( var i=0; i<this.tempobjects.length; i++) { newobjects.addObject(this.tempobjects.item(i).clone()); newobjects.item(i).styleIndex = this.tempobjects.item(i).styleIndex; }
	moi.geometryDatabase.addObjects(newobjects);
	moi.geometryDatabase.removeObjects(this.tempobjects);
	this.tempobjects = moi.geometryDatabase.createObjectList();
}

MoIOutput.prototype.onExecute = function()
{
	this.updateObjects();
	if(this.inputs[0].link !== null) { if (this.tempobjects.length === 0) {this.boxcolor = "#F80"} else {this.boxcolor = "#0F5"}} else {this.boxcolor = "#F05"}
	this.updateThisNodeGraph();
}

MoIOutput.prototype.onGetCreatedObjects = function()
{
	var list = [];
	for ( var i=0; i<this.tempobjects.length; i++) list.push(this.tempobjects.item(i).id);
	return list;
}

MoIOutput.prototype.getExtraMenuOptions = function(graphcanvas) { var that = this, thatgraph = this.graph; return [{content:lang.getTranslation("Clear"), callback: function() { that.onAdded(); that.onClear(); that.graph.setisChangedFlag(that.id); }}]; }

MoIOutput.prototype.onDrawForeground = function(ctx)
{
	var title_height = LiteGraph.NODE_TITLE_HEIGHT;
	var old_alpha = ctx.globalAlpha;
	
	ctx.fillStyle = this.bgcolor || LiteGraph.NODE_DEFAULT_BGCOLOR;
	ctx.fillRect(2,-title_height + 2,title_height - 4,title_height - 4);
	if (!this.flags.collapsed) ctx.fillRect( 5, 2, this.size[0]-10, this.size[1]-4);
	
	ctx.fillStyle = this.color || LiteGraph.NODE_DEFAULT_COLOR;
	ctx.globalAlpha = 0.5 * old_alpha;
	ctx.fillRect(2,-title_height + 2,title_height - 4,title_height - 4);
	ctx.globalAlpha = old_alpha;

	ctx.fillStyle=this.color || LiteGraph.NODE_DEFAULT_COLOR;
	ctx.fillStyle = this.boxcolor || LiteGraph.NODE_DEFAULT_BOXCOLOR;
	ctx.roundRect(3,-title_height + 3,title_height - 6,title_height - 6, 3);
	ctx.fill();

	if (!this.flags.collapsed)
	{
		var text = (this.tempobjects.length > 0)?this.tempobjects.length.toFixed(0):"--";
		ctx.font = "12px Arial";
		ctx.fillStyle="#AAA";
		ctx.textAlign = "center";
		ctx.fillText(text, this.size[0]/2, this.size[1]/2+4);
		ctx.textAlign = "left";
	}
}

LiteGraph.registerNodeType("Basic/Output", MoIOutput);

})();