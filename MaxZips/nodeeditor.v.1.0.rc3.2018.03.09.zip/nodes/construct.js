// MoI Nodeedit
// Construct v.1.0 - Karsten, Max Smirnov, 2018
// litegraph.js library (c) Javi Agenjo http://tamats.com

(function(){

// Loft
function Loft()
{
	this.addInput("In","objectlist");
	this.addOutput("Out","objectlist");
	this.properties = { style:["Loose","Normal","Loose","Straight"], cap_ends:["On","On","Off"], closed:["Off","On","Off"]};
}

Loft.title = "Loft";
Loft.desc = "Loft";

Loft.prototype.onExecute = function()
{
	var inObj = this.getInputData(0, moi.geometryDatabase.createObjectList());
	var output = moi.geometryDatabase.createObjectList();
	if ( inObj.length > 1 ) output = factory ('loft', inObj, null, this.properties.style[0], this.properties.cap_ends[0] === "On", this.properties.closed[0] === "On", "Exact" );
	this.setOutputData(0, output);
}

LiteGraph.registerNodeType("Construct/Loft", Loft);

//Sweep
function Sweep()
{
	this.addInput("Profiles", "objectlist");
	this.addInput("Rails", "objectlist");
	this.addOutput("Out", "objectlist");
	this.properties = { mode:["Union","Union","Long","Short"], ends:['Regular', 'Regular', 'Pointy end', 'Pointy start', 'Both pointy'], cap_ends: ["On", "On", "Off"]};
	this.local = {};
}
Sweep.title = "Sweep";
Sweep.desc = "Sweep";


Sweep.prototype.onExecute = function ()
{
	var ends = ["none", "pointyend", "pointystart", "pointystartandend"];
	var mode = (this.properties.mode[0]==="Union")?"Long+":this.properties.mode[0];
	this.local.ends = ends[this.properties.ends.lastIndexOf(this.properties.ends[0])-1];
	var data = this.processInOut(mode, this.multiProcess);
	this.setOutputData(0, data.outputs[0]);
}

Sweep.prototype.multiProcess = function (profiles, rails)
{
	return [factory( 'sweep', profiles, rails, null, null, this.local.ends, 'freeform', null, this.properties.cap_ends[0] === "On", null, null, 'Auto' )];
}

LiteGraph.registerNodeType("Construct/Sweep", Sweep);

// Extrude
function Extrude()
{
	this.addInput("Profile","objectlist");
	this.addInput("Distance","numarray");
	this.addOutput("Out","objectlist");
	this.properties = { mode:["Union","Union","Long","Short"], distance:[1], style:["Normal","Normal","Both sides"], cap_ends:["On","On","Off"]};
}

Extrude.title = "Extrude";
Extrude.desc = "Extrude";

Extrude.prototype.onExecute = function()
{
	if (this.properties.mode[0] === "Union")
	{
		var objects = this.getInputData(0, moi.geometryDatabase.createObjectList());
		this.properties.distance = this.getInputData(1, this.properties.distance);
		var output = factory ('extrude', objects, null, this.properties.distance[0], null, null, this.properties.cap_ends[0] === "On", this.properties.style[0] === "Both sides")
		this.setOutputData(0, output);
	}
	else
	{
		var data = this.processInOut(this.properties.mode[0], this.multiProcess, null, this.properties.distance );
		this.properties.distance = data.inputs[1];
		this.setOutputData(0, data.outputs[0]);
	}
}

Extrude.prototype.multiProcess = function(o, d)
{
	return [factory ('extrude', o, null, d, null, null, this.properties.cap_ends[0] === "On", this.properties.style[0] === "Both sides")];
}

LiteGraph.registerNodeType("Construct/Extrude", Extrude);


// Revolve
function Revolve()
{
	this.addInput("Profile","objectlist");
	this.addInput("Frame","pointarray");
	this.addInput("Angle","numarray");
	this.addOutput("Out","objectlist");
	this.properties = { mode:["Union","Union","Long","Short"], angle:[360], cap_ends:["On","On","Off"]};
}

Revolve.title = "Revolve";
Revolve.desc = "Revolve";

Revolve.prototype.onExecute = function()
{
	if (this.properties.mode[0] === "Union")
	{
		var inObj = this.getInputData(0, moi.geometryDatabase.createObjectList());
		var center = this.getInputData(1, new pointArray(true));
		this.properties.angle = this.getInputData(2, this.properties.angle);
		var frame = center.getFrame(0);
		var output = factory ('revolve', inObj, frame.origin, frame.evaluate( 0, 0, 1 ), this.properties.angle[0], this.properties.cap_ends[0] === "On");
		this.setOutputData(0, output);
	}
	else
	{
		var data = this.processInOut(this.properties.mode[0], this.multiProcess, null, null, 360 );
		this.properties.angle = data.inputs[2];
		this.setOutputData(0, data.outputs[0]);
	}
}

Revolve.prototype.multiProcess = function(p, f, a)
{
	var frame = f.getFrame();
	return [factory ('revolve', p, frame.origin, frame.evaluate( 0, 0, 1 ), a, this.properties.cap_ends[0] === "On")];
}

LiteGraph.registerNodeType("Construct/Revolve", Revolve);


// Difference
function objDiff()
{
	this.addInput("Base objects","objectlist");
	this.addInput("Subtracters","objectlist");
	this.addOutput("Out","objectlist");
}

objDiff.title = "Difference";
objDiff.desc = "Boolean Difference";

objDiff.prototype.onExecute = function()
{
	var baseObj = this.getInputData(0, moi.geometryDatabase.createObjectList());
	var substObj = this.getInputData(1, moi.geometryDatabase.createObjectList());
	var output = moi.geometryDatabase.createObjectList();
	if ( baseObj.length > 0 ) if ( substObj.length > 0 ) { output = factory( 'booleandifference', baseObj, substObj, false);} else { output = baseObj; }
	this.setOutputData(0, output);
}

LiteGraph.registerNodeType("Construct/objDiff", objDiff);


// Intersection
function objIntersect()
{
	this.addInput("Base objects","objectlist");
        this.addInput("Intersecters","objectlist");
	this.addOutput("Out","objectlist");
}

objIntersect.title = "Intersection";
objIntersect.desc = "Boolean Intersection";

objIntersect.prototype.onExecute = function()
{
	var baseObj = this.getInputData(0, moi.geometryDatabase.createObjectList());
	var intersecObj = this.getInputData(1, moi.geometryDatabase.createObjectList());
	var output = moi.geometryDatabase.createObjectList();
	if ( baseObj.length > 0 && intersecObj.length > 0 ) output = factory( 'booleanintersection', baseObj, intersecObj );
	this.setOutputData(0, output);
}

LiteGraph.registerNodeType("Construct/objIntersect", objIntersect);

// Union
function objUnion()
{
	this.addInput("Objects","objectlist");
	this.addOutput("Out","objectlist");
}

objUnion.title = "Union";
objUnion.desc = "Boolean Union";

objUnion.prototype.onAdded = function() { if ( this.inputs.length === 0 ) this.addInput("Object", "objectlist"); }
objUnion.prototype.onInputAdded = function() { for ( var i in this.inputs ) this.inputs[i].locked = true; if (i>0) this.inputs[i].locked = false; }
objUnion.prototype.onInputRemoved = function() { for ( var i in this.inputs ) this.inputs[i].locked = true; if (i>0) this.inputs[i].locked = false; }
objUnion.prototype.onGetInputs = function() { var list = []; list.push(["Objects","objectlist", {locked:false}]); return list; }
objUnion.prototype.onExecute = function()
{
	var output = moi.geometryDatabase.createObjectList();
	for ( var i = 0; i<this.inputs.length; i++)
	{
		var inObj = this.getInputData(i, moi.geometryDatabase.createObjectList());
		for ( var j = 0; j < inObj.length; j++ ) output.addObject( inObj.item(j) ); 
	}
	if ( output.length > 1 ) output = factory('booleanunion', output);
	this.setOutputData(0, output);
}

LiteGraph.registerNodeType("Construct/objUnion", objUnion);



})();