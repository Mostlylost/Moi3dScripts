// MoI Nodeedit
// Solids v.1.0 - Max Smirnov, 2018
// litegraph.js library (c) Javi Agenjo http://tamats.com

(function(){

// Cone
function Cone()
{
	this.addInput("Center","pointarray");
	this.addInput("Radius","numarray");
	this.addInput("Height","numarray");
	this.addOutput("Out","objectlist");
	this.properties = { mode:["Long","Long","Short"], radius:[1], height:[1] };
}

Cone.title = "Cone";
Cone.desc = "Cone";

Cone.prototype.onExecute = function()
{
	var data = this.processInOut(this.properties.mode[0], this.multiProcess, null, this.properties.radius, this.properties.height);
	this.properties.radius = data.inputs[1];
	this.properties.height = data.inputs[2];
	this.setOutputData(0, data.outputs[0]);
}
Cone.prototype.multiProcess = function(c, r, h)
{
	var frame = c.getFrame(0);
	return [factory('cone', true, frame, null, r, frame.evaluate(0,0,h))];
}

LiteGraph.registerNodeType("Solids/Cone", Cone);

// Cylinder
function Cylinder()
{
	this.addInput("Center","pointarray");
	this.addInput("Radius","numarray");
	this.addInput("Height","numarray");
	this.addOutput("Out","objectlist");
	this.properties = { mode:["Long","Long","Short"], radius:[1], height:[1] };
}

Cylinder.title = "Cylinder";
Cylinder.desc = "Cylinder";

Cylinder.prototype.onExecute = function()
{
	var data = this.processInOut(this.properties.mode[0], this.multiProcess, null, this.properties.radius, this.properties.height);
	this.properties.radius = data.inputs[1];
	this.properties.height = data.inputs[2];
	this.setOutputData(0, data.outputs[0]);
}

Cylinder.prototype.multiProcess = function(c, r, h)
{
	var frame = c.getFrame(0);
	return [factory('cylinder', true, frame, null, r, frame.evaluate(0,0,h))];
}

LiteGraph.registerNodeType("Solids/Cylinder", Cylinder);

// Sphere
function Sphere()
{
	this.addInput("Center","pointarray");
	this.addInput("Radius","numarray");
	this.addOutput("Out","objectlist");
	this.properties = { mode:["Long","Long","Short"], radius:[1] };
}

Sphere.title = "Sphere";
Sphere.desc = "Sphere";

Sphere.prototype.onExecute = function()
{
	var data = this.processInOut(this.properties.mode[0], this.multiProcess, null, this.properties.radius);
	this.properties.radius = data.inputs[1];
	this.setOutputData(0, data.outputs[0]);
}

Sphere.prototype.multiProcess = function(c, r)
{
	return [factory('sphere', true, c.getFrame(0), null, r)];
}

LiteGraph.registerNodeType("Solids/Sphere", Sphere);

// Polyhedron
function Polyhedron()
{
	this.addInput("Center","pointarray");
	this.addInput("Radius","numarray");
	this.addOutput("Out","objectlist");
	this.properties = { mode:["Long","Long","Short"], radius:[1], type:["Tetrahedron","Tetrahedron","Octahedron", "Hexahedron", "Icosahedron","Dodecahedron"] };
}

Polyhedron.title = "Polyhedron";
Polyhedron.desc = "Polyhedron";

Polyhedron.prototype.onExecute = function()
{
	var data = this.processInOut(this.properties.mode[0], this.multiProcess, null, this.properties.radius);
	this.properties.radius = data.inputs[1];
	this.setOutputData(0, data.outputs[0]);
}

Polyhedron.prototype.multiProcess = function(c, r)
{
	var f = [], v = [], a, b, c, phi = (1+Math.sqrt(5))/2, fr = c.getFrame(0), out = moi.geometryDatabase.createObjectList();

	if (this.properties.type[0] === "Tetrahedron")
	{
		a = r;
		f[0] = [0, 1, 2];	f[1] = [1, 3, 2];	f[2] = [0, 2, 3];	f[3] = [0, 3, 1];
		v[0] = fr.evaluate(a, a, a);	v[1] = fr.evaluate(-a, a,-a);	v[2] = fr.evaluate(a,-a,-a);	v[3] = fr.evaluate(-a,-a, a);
		out = Objects.createFaces(f, v, true);
	}

	else if (this.properties.type[0] === "Octahedron")
	{
		a = r*Math.sqrt(2);
		b = r;
		f[0] = [0, 1, 2];	f[1] = [1, 3, 2];	f[2] = [3, 4, 2];	f[3] = [4, 0, 2];
		f[4] = [3, 1, 5];	f[5] = [1, 0, 5];	f[6] = [4, 3, 5];	f[7] = [0, 4, 5];
		v[0] = fr.evaluate(-b, 0, b);	v[1] = fr.evaluate(-b, 0,-b);	v[2] = fr.evaluate(0, a, 0);
		v[3] = fr.evaluate( b, 0,-b);	v[4] = fr.evaluate( b, 0, b);	v[5] = fr.evaluate(0,-a, 0);
		out = Objects.createFaces(f, v, true);
	}

	else if (this.properties.type[0] === "Hexahedron")
	{
		a = r*Math.sqrt(2) / 2;
		f[0] = [0, 1, 2, 3];	f[1] = [0, 3, 4, 5];	f[2] = [3, 2, 6, 4];
		f[3] = [5, 4, 6, 7];	f[4] = [1, 7, 6, 2];	f[5] = [0, 5, 7, 1];
		v[0] = fr.evaluate(-a,-a,-a);	v[1] = fr.evaluate( a,-a,-a);	v[2] = fr.evaluate( a,-a, a);	v[3] = fr.evaluate(-a,-a, a);
		v[4] = fr.evaluate(-a, a, a);	v[5] = fr.evaluate(-a, a,-a);	v[6] = fr.evaluate( a, a, a);	v[7] = fr.evaluate( a, a,-a);
		out = Objects.createFaces(f, v, true);
	}

	else if (this.properties.type[0] === "Icosahedron")
	{
		a = r;
		b = r/phi;
		f[0]  = [0, 1, 2];	f[1]  = [3, 2, 1];	f[2]  = [3, 4, 5];	f[3]  = [3, 6, 4];
		f[4]  = [0, 7, 8];	f[5]  = [0, 9, 7];	f[6] = [4, 10, 11]; f[7]  = [7, 11, 10];
		f[8]  = [2, 5, 9];	f[9]  = [11, 9, 5];	f[10] = [1, 8, 6];	f[11] = [10, 6, 8];
		f[12] = [3, 5, 2];	f[13] = [3, 1, 6];	f[14] = [0, 2, 9];	f[15] = [0, 8, 1];
		f[16] = [7, 9, 11];	f[17] = [7, 10, 8];	f[18] = [4, 11, 5];	f[19] = [4, 6, 10];
		
		v[0] = fr.evaluate( 0, b,-a);	v[1] = fr.evaluate( b, a, 0);	v[2]  = fr.evaluate(-b, a, 0);	v[3]  = fr.evaluate( 0, b, a);
		v[4] = fr.evaluate( 0,-b, a);	v[5] = fr.evaluate(-a, 0, b);	v[6]  = fr.evaluate( a, 0, b);	v[7]  = fr.evaluate( 0,-b,-a);
		v[8] = fr.evaluate( a, 0,-b);	v[9] = fr.evaluate(-a, 0,-b);	v[10] = fr.evaluate( b,-a, 0);	v[11] = fr.evaluate(-b,-a, 0);
		out = Objects.createFaces(f, v, true);
	}

	else if (this.properties.type[0] === "Dodecahedron")
	{
		a = r;
		b = r/phi;
		c = 2*r-phi*r;
		f[0] = [0, 1, 2, 3, 4];		f[1] = [1, 0, 5, 6, 7];		f[2] = [8, 9, 10, 11, 12];		f[3] = [9, 8, 13, 14, 15];
		f[4] = [14, 3, 4, 16, 13];	f[5] = [3, 14, 15, 17, 2];	f[6] = [11, 6, 7, 18, 10];		f[7] = [6, 11, 12, 19, 5];
		f[8] = [16, 19, 5, 0, 4];	f[9] = [19, 16, 13, 8, 12];	f[10] = [17, 18, 10, 9, 15];	f[11] = [18, 17, 2, 1, 7];
		v[0 ] = fr.evaluate( c, 0, a);	v[1 ] = fr.evaluate(-c, 0, a);	v[2 ] = fr.evaluate(-b, b, b);	v[3 ] = fr.evaluate( 0, a, c);
		v[4 ] = fr.evaluate( b, b, b);	v[5 ] = fr.evaluate( b,-b, b);	v[6 ] = fr.evaluate( 0,-a, c);	v[7 ] = fr.evaluate(-b,-b, b);
		v[8 ] = fr.evaluate( c, 0,-a);	v[9 ] = fr.evaluate(-c, 0,-a);	v[10] = fr.evaluate(-b,-b,-b);	v[11] = fr.evaluate( 0,-a,-c);
		v[12] = fr.evaluate( b,-b,-b);	v[13] = fr.evaluate( b, b,-b);	v[14] = fr.evaluate( 0, a,-c);	v[15] = fr.evaluate(-b, b,-b);
		v[16] = fr.evaluate( a, c, 0);	v[17] = fr.evaluate(-a, c, 0);	v[18] = fr.evaluate(-a,-c, 0);	v[19] = fr.evaluate( a,-c, 0);
		out = Objects.createFaces(f, v, true);
	}

	return [out];
}

LiteGraph.registerNodeType("Solids/Polyhedron", Polyhedron);

})();