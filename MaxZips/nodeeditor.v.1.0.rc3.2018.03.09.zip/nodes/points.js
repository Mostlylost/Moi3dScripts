// MoI Nodeedit
// Points v.1.0 - Max Smirnov, 2018
// litegraph.js library (c) Javi Agenjo http://tamats.com

(function(){

// Points
function Points()
{
	this.properties = { U_range:[0,10], V_range:[0,10], W_range:[0,10], U_num:[11], V_num:[11], W_num:[11]};
	this.addInput("U range", "numarray");
	this.addInput("V range", "numarray");
	this.addInput("W range", "numarray");
	this.addInput("U num", "numarray");
	this.addInput("V num", "numarray");
	this.addInput("W num", "numarray");
	this.addOutput("Out", "pointarray");
}

Points.title = "Points";
Points.desc = "Points";

Points.prototype.onPropertyChange = function()
{
	this.checkValues();
};

Points.prototype.checkValues = function()
{
	if (this.properties.U_range.length > 2) this.properties.U_range	= this.properties.U_range.slice(0, 2);
	if (this.properties.V_range.length > 2) this.properties.V_range	= this.properties.V_range.slice(0, 2);
	if (this.properties.W_range.length > 2) this.properties.W_range	= this.properties.W_range.slice(0, 2);

	if (this.properties.U_range.length === 1) this.properties.U_range.push(this.properties.U_range[0]+1);
	if (this.properties.V_range.length === 1) this.properties.V_range.push(this.properties.V_range[0]+1);
	if (this.properties.W_range.length === 1) this.properties.W_range.push(this.properties.W_range[0]+1);

	if (this.properties.U_range[0] === this.properties.U_range[1]) this.properties.U_range[1] = this.properties.U_range[0]+1;
	if (this.properties.V_range[0] === this.properties.V_range[1]) this.properties.V_range[1] = this.properties.V_range[0]+1;
	if (this.properties.W_range[0] === this.properties.W_range[1]) this.properties.W_range[1] = this.properties.W_range[0]+1;

	if (this.properties.U_num.length > 1) this.properties.U_num = this.properties.U_num.slice(0,1);
	if (this.properties.V_num.length > 1) this.properties.V_num = this.properties.V_num.slice(0,1);
	if (this.properties.W_num.length > 1) this.properties.W_num = this.properties.W_num.slice(0,1);

	if (this.properties.U_num[0] < 1) this.properties.U_num[0] = 1;
	if (this.properties.V_num[0] < 1) this.properties.V_num[0] = 1;
	if (this.properties.W_num[0] < 1) this.properties.W_num[0] = 1;
};

Points.prototype.onExecute = function()
{
	var u, v, w = 0;
	var output = new pointArray();
	
	this.properties.U_range = this.getInputData(0, this.properties.U_range);
	this.properties.V_range = this.getInputData(1, this.properties.V_range);
	this.properties.W_range = this.getInputData(2, this.properties.W_range);
	this.properties.U_num = this.getInputData(3, this.properties.U_num);
	this.properties.V_num = this.getInputData(4, this.properties.V_num);
	this.properties.W_num = this.getInputData(5, this.properties.W_num);

	this.checkValues();
	
	var un = this.properties.U_num[0]-1;	if ( un === 0 ) un = 0.5;
	var vn = this.properties.V_num[0]-1;	if ( vn === 0 ) vn = 0.5;
	var wn = this.properties.W_num[0]-1;	if ( wn === 0 ) wn = 0.5;
	
	var ucnt =  0,  vcnt = 0, wcnt = 0;
	var ustep = (this.properties.U_range[1]-this.properties.U_range[0])/un;
	var vstep = (this.properties.V_range[1]-this.properties.V_range[0])/vn;
	var wstep = (this.properties.W_range[1]-this.properties.W_range[0])/wn;
	
	var umin = this.properties.U_range[0];
	var vmin = this.properties.V_range[0];
	
	w = this.properties.W_range[0];
	while ( wcnt <= wn )
	{
		v = vmin;
		vcnt = 0;
		while ( vcnt <= vn )
		{
			u = umin;
			ucnt = 0;
			while ( ucnt <= un )
			{
				output.push(u, v, w);
				u += ustep;
				ucnt++;
			}
			v += vstep;
			vcnt++;
		}
		w += wstep;
		wcnt++;
	}
	output.xlength = this.properties.U_num[0];
	output.ylength = this.properties.V_num[0];
	output.zlength = this.properties.W_num[0];
	this.setOutputData(0, output);
}

LiteGraph.registerNodeType("Points/Points", Points);

// InterpPts
function InterpPts()
{
	this.addInput("In","pointarray");
	this.addInput("C","numarray");
	this.addOutput("Out","pointarray");
	this.properties = { mode:["CatmullRom","Linear","Cosine","Cubic","CatmullRom","Hermite","FritschCarlson"], count:[10] };
}

InterpPts.title = "InterpPts";
InterpPts.desc = "InterpPts";

InterpPts.prototype.onExecute = function()
{
	var ar = this.getInputData(0, new pointArray(false));
	this.properties.count = this.getInputData(1, this.properties.count);
	ar.interpolate(this.properties.count[0], this.properties.mode[0]);
	this.setOutputData(0, ar);
}

LiteGraph.registerNodeType("Points/InterpPts", InterpPts);
	
// MathPts
function MathPts()
{
	this.internal = {}
	this.dynamicProperties = ["a","b","c","d"];
	this.properties = { x:"u", y:"v", z:"0", U_range:[0,10], V_range:[0,10], U_num:[11], V_num:[11]};
	this.addInput("U range", "numarray");
	this.addInput("V range", "numarray");
	this.addInput("U num", "numarray");
	this.addInput("V num", "numarray");
	this.addOutput("f(u,v)", "pointarray");
}

MathPts.title = "MathPts";
MathPts.desc = "MathPts";

MathPts.prototype.onAdded = function()
{
	if ( this.properties.hasOwnProperty("a") && this.inputs.length < 5) this.addInput("a","numarray");
	if ( this.properties.hasOwnProperty("b") && this.inputs.length < 6) this.addInput("b","numarray");
	if ( this.properties.hasOwnProperty("c") && this.inputs.length < 7) this.addInput("c","numarray");
	if ( this.properties.hasOwnProperty("d") && this.inputs.length < 8) this.addInput("d","numarray");
	this.checkFunction("x");
	this.checkFunction("y");
	this.checkFunction("z");
}

MathPts.prototype.checkFunction = function(prop)
{
	var valid = true;
	var fnc = this.properties[prop];
	fnc = fnc.replace(/rnd/g, "random()");
	fnc = fnc.replace(/\[/g, "(pi/180*(");
	fnc = fnc.replace(/\]/g, "))");
	fnc = fnc.replace(/(?:[a-z$_][a-z0-9$_]*)|(?:[;={}"'!&<>^\\?:])/ig,
		function ($0)
		{
			if (Math.hasOwnProperty($0)) return "Math."+$0;
			else if (Math.hasOwnProperty($0.toUpperCase())) return "Math."+$0.toUpperCase();
			else if ( $0.toLowerCase() === 'a' || $0.toLowerCase() === 'b' || $0.toLowerCase() === 'c' || $0.toLowerCase() === 'd' || $0.toLowerCase() === 'u' || $0.toLowerCase() === 'v' ) return $0.toLowerCase();
			else	valid=false;
		});
	this.internal["valid"+prop] = valid;
	this.internal["fnc"+prop] = fnc;
}

MathPts.prototype.onPropertyChange = function()
{
	this.checkValues();
}

MathPts.prototype.checkValues = function()
{
	var i = this.inputs.length;
	if (this.properties.U_range.length > 2) this.properties.U_range	= this.properties.U_range.slice(0, 2);
	if (this.properties.V_range.length > 2) this.properties.V_range	= this.properties.V_range.slice(0, 2);

	if (this.properties.U_range.length === 1) this.properties.U_range.push(this.properties.U_range[0]+1);
	if (this.properties.V_range.length === 1) this.properties.V_range.push(this.properties.V_range[0]+1);

	if (this.properties.U_range[0] === this.properties.U_range[1]) this.properties.U_range[1] = this.properties.U_range[0]+1;
	if (this.properties.V_range[0] === this.properties.V_range[1]) this.properties.V_range[1] = this.properties.V_range[0]+1;

	if (this.properties.U_num.length > 1) this.properties.U_num = this.properties.U_num[0];
	if (this.properties.V_num.length > 1) this.properties.V_num = this.properties.V_num[0];

	if (this.properties.U_num[0] < 1) this.properties.U_num[0] = 1;
	if (this.properties.V_num[0] < 1) this.properties.V_num[0] = 1;

	if ( i>4 ) if ( this.properties.a.length > 1 ) this.properties.a = this.properties.a.slice(0,1);
	if ( i>5 ) if ( this.properties.b.length > 1 ) this.properties.b = this.properties.b.slice(0,1);
	if ( i>6 ) if ( this.properties.c.length > 1 ) this.properties.c = this.properties.c.slice(0,1);
	if ( i>7 ) if ( this.properties.d.length > 1 ) this.properties.d = this.properties.d.slice(0,1);

	this.checkFunction("x");
	this.checkFunction("y");
	this.checkFunction("z");
};

MathPts.prototype.onGetInputs = function()
{
	var str = "abcd", list = [];
	for ( var i = 0; i<str.length; i++ )
	{
		var inpname = str.charAt(i);
		if ( !(this.properties.hasOwnProperty(inpname)) ) { list.push([inpname,"numarray", {locked:true}]); break; }
	}
	return list;
}

MathPts.prototype.onInputAdded = function(inp)
{
	if ( inp.name.length > 1 ) return;
	if (!(this.properties.hasOwnProperty(inp.name))) this.properties[inp.name] = 0;
	for ( var i in this.inputs ) this.inputs[i].locked = true;
	if ( this.inputs.length > 4 ) this.inputs[i].locked = false;
	this.setDirtyCanvas(true);
}

MathPts.prototype.onInputRemoved = function(slot, name)
{
	if ( this.properties.hasOwnProperty(name) ) delete this.properties[name];
	for ( var i in this.inputs ) this.inputs[i].locked = true;
	if ( this.inputs.length > 4 )this.inputs[i].locked = false;
}

MathPts.prototype.getExtraMenuOptions = function() { var that = this, thatgraph = this.graph; return [{content:lang.getTranslation("Update"), callback: function() { thatgraph.setisChangedFlag(that.id) }}]; }

MathPts.prototype.onExecute = function()
{
	var a=0, b=0, c=0, d=0, u=0, v=0, x=0, y=0, z=0, i = this.inputs.length;
	var output = new pointArray();
	this.properties.U_range = this.getInputData(0, this.properties.U_range);
	this.properties.V_range = this.getInputData(1, this.properties.V_range);
	this.properties.U_num = this.getInputData(2, this.properties.U_num);
	this.properties.V_num = this.getInputData(3, this.properties.V_num);
	
	if ( i>4 ) { this.properties.a = this.getInputData(4, this.properties.a); a = this.properties.a[0]; }
	if ( i>5 ) { this.properties.b = this.getInputData(5, this.properties.b); b = this.properties.b[0]; }
	if ( i>6 ) { this.properties.c = this.getInputData(6, this.properties.c); c = this.properties.c[0]; }
	if ( i>7 ) { this.properties.d = this.getInputData(7, this.properties.d); d = this.properties.d[0]; }

	this.checkValues();

	var un = this.properties.U_num[0]-1;	if ( un === 0 ) un = 0.5;
	var vn = this.properties.V_num[0]-1;	if ( vn === 0 ) vn = 0.5;
	var ucnt = 0, vcnt = 0;
	var umin = this.properties.U_range[0], umax = this.properties.U_range[1];
	var vmin = this.properties.V_range[0], vmax = this.properties.V_range[1];
	var ustep = (umax-umin)/un, vstep = (vmax-vmin)/vn;
	v = vmin;
	while ( vcnt <= vn )
	{
		u = umin;
		ucnt = 0;
		while ( ucnt <= un )
		{
			if (this.internal.validx)
			{
				try { x = eval(this.internal.fncx) }
				catch (e) { x = 0 }
				if ( x === 'Infinity' ) { x = 99999999 }
				if ( x === '-Infinity' ) { x = -99999999 }
				if ( typeof ( x ) !=='number' ) { x = 0 }
				if ( isNaN( x ) ) { x = 0  }
			}
			else { x = 0 }
			
			if (this.internal.validy)
			{
				try { y = eval(this.internal.fncy) }
				catch (e) { y = 0 }
				if ( y === 'Infinity' ) { y = 99999999 }
				if ( y === '-Infinity' ) { y = -99999999 }
				if ( typeof ( y ) !=='number' ) { y = 0 }
				if ( isNaN( y ) ) { y = 0  }
			}
			else { y = 0 }
			
			if (this.internal.validz)
			{
				try { z = eval(this.internal.fncz) }
				catch (e) { z = 0 }
				if ( z === 'Infinity' ) { z = 99999999 }
				if ( z === '-Infinity' ) { z = -99999999 }
				if ( typeof ( z ) !=='number' ) { z = 0 }
				if ( isNaN( z ) ) { z = 0  }
			}
			else { z = 0 }
			
			output.push(x, y, z)
			u += ustep;
			ucnt++;
			if (ucnt === un) u = umax;
		}
		v += vstep;
		vcnt++;
		if (vcnt === vn) v = vmax;
	}
	output.xlength = this.properties.U_num[0];
	output.ylength = this.properties.V_num[0];
	this.setOutputData(0, output);
}

LiteGraph.registerNodeType("Points/MathPts", MathPts);
	
	
// TextPts
function TextPts()
{
	this.internal = {}
	this.properties = { _points:"0 0 0" };
	this.addOutput("Out", "pointarray");
}

TextPts.title = "TextPts";
TextPts.desc = "TextPts";

TextPts.prototype.onAdded = function()
{
	this.onPropertyChange();
}

TextPts.prototype.onPropertyChange = function()
{
	this.properties._points = this.properties._points.replace(/^\s*[\r\n]/gm, '');	// remove empty lines
	this.properties._points = this.properties._points.replace(/[\r\n]$/g, '');		// remove last empty line
	this.properties._points = this.properties._points.replace(/[\t ;]+/gm, ' ');		// remove tabs and double spaces
	this.properties._points = this.properties._points.replace(/,/g, '.');			// replace , with .
	this.properties._points = this.properties._points.replace(/^ +| +$/gm, '');		// remove leading and trailing spaces
	var points = this.properties._points.split("\n");
	
	this.output = new pointArray();
	for (var p = 0; p<points.length; p++)
	{
		var v = points[p].split(" ");
		this.output.push(parseFloat(v[0]), parseFloat(v[1]), parseFloat(v[2]), parseFloat(v[3]), parseFloat(v[4]), parseFloat(v[5]), parseFloat(v[6]));
	}
};

TextPts.prototype.onExecute = function()
{
	this.setOutputData(0, this.output);
}

LiteGraph.registerNodeType("Points/TextPts", TextPts);
	
// SpherePts
function SpherePts()
{
	this.properties = { Count:[100], Radius:[10] };
	this.addInput("Count", "numarray");
	this.addInput("Radius", "numarray");
	this.addOutput("Out", "pointarray");
}

SpherePts.title = "SpherePts";
SpherePts.desc = "SpherePts";

SpherePts.prototype.onPropertyChange = function()
{
	for (var i in this.properties.Count ) if (this.properties.Count[i] < 0) { this.properties.Count[i] = 0 } else { this.properties.Count[i] = Math.floor(this.properties.Count[i]);}
	for (var i in this.properties.Radius ) if (this.properties.Radius[i] <= 0) this.properties.Radius[i] = 0;
};

SpherePts.prototype.onExecute = function()
{
	var data = this.processInOut("Cross", this.multiProcess, this.properties.Count, this.properties.Radius);
	this.properties.Count = data.inputs[0];
	this.properties.Radius = data.inputs[1];
	this.setOutputData(0, data.outputs[0]);
}
SpherePts.prototype.multiProcess = function(n, r)
{
	var output = new pointArray();
	var numpoints = n;
	if (numpoints < 0) { numpoints = 0 } else { numpoints = Math.floor(numpoints);}
	
	var rd = r;
	var inc = Math.PI * (3.0 - Math.sqrt(5.0));
	var off2 = (numpoints === 0)?1:2 / numpoints;
	var off=off2/2;
	var phi = 0, x, y, z, radius, toDeg = 180.0/Math.PI;

	for ( var i = numpoints; i>0; i-- )
	{
		z = 1-off;
		radius = Math.sqrt(1 - z*z);
		x = Math.cos(phi) * radius;		y = Math.sin(phi) * radius;
		phi += inc;
		off += off2;
		output.push(x*rd, y*rd, z*rd, Math.atan2(y, z)*toDeg, -Math.asin(x)*toDeg, 0, 1);
	}
	return [output];
}

LiteGraph.registerNodeType("Points/SpherePts", SpherePts);
	
// PoygonPts
function PolygonPts()
{
	this.properties = { mode:["Long","Long","Short"], radius:[10], sides:[6], type:["Circumscribed","Circumscribed","Inscribed"] };
	this.addInput("Radius","numarray");
	this.addInput("Sides","numarray");
	this.addOutput("Out", "pointarray");
}

PolygonPts.title = "PolygonPts";
PolygonPts.desc = "PolygonPts";

PolygonPts.prototype.onPropertyChange = function()
{
	for (var i in this.properties.radius ) if (this.properties.radius[i] <= 0) { this.properties.radius[i] = 0 } else { this.properties.radius[i] = Math.floor(this.properties.radius[i])}
	for (var i in this.properties.sides ) if (this.properties.sides[i] <= 3) { this.properties.sides[i] = 3 } else { this.properties.sides[i] = Math.floor(this.properties.sides[i])}
};

PolygonPts.prototype.onExecute = function()
{
	var data = this.processInOut(this.properties.mode[0], this.multiProcess, this.properties.radius, this.properties.sides);
	this.properties.radius = data.inputs[0];
	this.properties.sides = data.inputs[1];
	this.setOutputData(0, data.outputs[0]);
}

PolygonPts.prototype.multiProcess = function(r, s)
{
	var output = new pointArray();
	if (s>2)
	{
		var x, y, stepA = 2*Math.PI/s, stepB = 360/s, alpha = 0, beta = 0;
		if (this.properties.type[0] === this.properties.type[1])
		{
			r = r*(1/Math.cos(stepA/2));
			alpha += stepA/2;
			beta += stepB/2;
		}
		for ( var i = 0; i<s; i++ )
		{
			x = r * Math.sin(alpha);
			y = r * Math.cos(alpha);
			output.push(x, y, 0, -90, beta-90, 0);
			alpha += stepA;
			beta += stepB;
		}
	}
	return [output];
}

LiteGraph.registerNodeType("Points/PolygonPts", PolygonPts);


// TransformPts
function TransformPts()
{
	this.properties = { mode:["All","All","Step","Twist","Explode"], value:[0] };
	this.addInput("In", "pointarray");
	this.addInput("Center", "pointarray");
	this.addInput("Angle", "numarray");
	this.addOutput("Out", "pointarray");
}

TransformPts.title = "TransformPts";
TransformPts.desc = "TransformPts";

TransformPts.prototype.onExecute = function()
{
	var output = this.getInputData(0, new pointArray(false));
	var center = this.getInputData(1, new pointArray(true));
	this.properties.value = this.getInputData(2, this.properties.value);
	if (this.properties.mode[0] === "Explode") { output.explode(center, this.properties.value[0] ); }
	else { output.rotateAroundFrame(this.properties.mode[0], center, this.properties.value[0] ); }
	this.setOutputData(0, output);
}

LiteGraph.registerNodeType("Points/TransformPts", TransformPts);

// MovePts
function MovePts()
{
	this.properties = { dX:[0], dY:[0], dZ:[0]};
	this.addInput("In", "pointarray");
	this.addInput("dX", "numarray");
	this.addInput("dY", "numarray");
	this.addInput("dZ", "numarray");
	this.addOutput("Out", "pointarray");
}

MovePts.title = "MovePts";
MovePts.desc = "MovePts";

MovePts.prototype.onExecute = function()
{
	var data = this.processInOut("Long#", this.multiProcess, new pointArray(false), this.properties.dX, this.properties.dY, this.properties.dZ);
	this.properties.dX = data.inputs[1];
	this.properties.dY = data.inputs[2];
	this.properties.dZ = data.inputs[3];
	this.setOutputData(0, data.outputs[0]);
}

MovePts.prototype.multiProcess = function(p, x, y, z)
{
	p.moveAll(x,y,z);
	return [p];
}

LiteGraph.registerNodeType("Points/MovePts", MovePts);


// RotatePts
function RotatePts()
{
	this.properties = { mode:["Fixed","Fixed","Incremental"], rX:[0], rY:[0], rZ:[0]};
	this.addInput("In", "pointarray");
	this.addInput("rX", "numarray");
	this.addInput("rY", "numarray");
	this.addInput("rZ", "numarray");
	this.addOutput("Out", "pointarray");
}

RotatePts.title = "RotatePts";
RotatePts.desc = "RotatePts";

RotatePts.prototype.onExecute = function()
{
	var data = this.processInOut("Long#", this.multiProcess, new pointArray(true), this.properties.rX, this.properties.rY, this.properties.rZ);
	this.properties.rX = data.inputs[1];
	this.properties.rY = data.inputs[2];
	this.properties.rZ = data.inputs[3];
	this.setOutputData(0, data.outputs[0]);
}

RotatePts.prototype.multiProcess = function(p, rX, rY, rZ)
{
	p.rotateAll(rX,rY,rZ,this.properties.mode[0]);
	return [p];
}

LiteGraph.registerNodeType("Points/RotatePts", RotatePts);

// ScalePts
function ScalePts()
{
	this.properties = { mode:["Repeat", "Repeat", "RepeatY", "RepeatZ"], scale:[1]};
	this.addInput("In", "pointarray");
	this.addInput("Scale", "numarray");
	this.addOutput("Out", "pointarray");
}

ScalePts.title = "ScalePts";
ScalePts.desc = "ScalePts";

ScalePts.prototype.onExecute = function()
{
	var data = this.processInOut(this.properties.mode[0], this.multiProcess, new pointArray(true), this.properties.scale);
	this.properties.scale = data.inputs[1];
	this.setOutputData(0, data.outputs[0]);
}

ScalePts.prototype.multiProcess = function(p, scale)
{
	console.json(p)
	for (var i=0, l=p.length; i<l; i++) p.setScale(i,scale);
	return [p];
}

LiteGraph.registerNodeType("Points/ScalePts", ScalePts);

// JitterPts
function JitterPts()
{
	this.internal = {}
	this.properties = { dX:[0], dY:[0], dZ:[0], rX:[0], rY:[0], rZ:[0], dS:[0]};
	this.addInput("In", "pointarray");
	this.addInput("dX", "numarray");
	this.addInput("dY", "numarray");
	this.addInput("dZ", "numarray");
	this.addInput("rX", "numarray");
	this.addInput("rY", "numarray");
	this.addInput("rZ", "numarray");
	this.addInput("Scale", "numarray");
	this.addOutput("Out", "pointarray");
}

JitterPts.title = "JitterPts";
JitterPts.desc = "JitterPts";

JitterPts.prototype.getExtraMenuOptions = function() { var that = this, thatgraph = this.graph; return [{content:lang.getTranslation("Update"), callback: function() { thatgraph.setisChangedFlag(that.id) }}]; }

JitterPts.prototype.onExecute = function()
{
	var data = this.processInOut("Long#", this.multiProcess, new pointArray(false), this.properties.dX, this.properties.dY, this.properties.dZ, this.properties.rX, this.properties.rY, this.properties.rZ, this.properties.dS);

	this.properties.dX = data.inputs[1];
	this.properties.dY = data.inputs[2];
	this.properties.dZ = data.inputs[3];
	this.properties.rX = data.inputs[4];
	this.properties.rY = data.inputs[5];
	this.properties.rZ = data.inputs[6];
	this.properties.dS = data.inputs[7];
	this.setOutputData(0, data.outputs[0]);
}

JitterPts.prototype.multiProcess = function(p, dX, dY, dZ, rX, rY, rZ, dS)
{
	p.jitterAll(dX, dY, dZ, rX, rY, rZ, dS);
	return [p];
}

LiteGraph.registerNodeType("Points/JitterPts", JitterPts);
	
// ConvertPts
function ConvertPts()
{
	this.addInput("Points","pointarray");
	this.addOutput("Objects","objectlist");
	this.properties = { mode:["Curves U", "Curves U", "Curves V", "Points"]};
}

ConvertPts.title = "ConvertPts";
ConvertPts.desc = "ConvertPts";

ConvertPts.prototype.onExecute = function()
{
	var input = this.getInputData(0, new pointArray());
	var output = moi.geometryDatabase.createObjectList();
	var pointF = moi.command.createFactory( 'point' );
	
	if ( this.properties.mode[0] === 'Points')
	{
		var len = input.getLength();
		for (var i = 0; i<len; i++)
		{
			pointF.setInput(0, input.getPoint(i));
			var pointV = pointF.calculate();
			output.addObject(pointV.item(0));
		}
	}
	if ( this.properties.mode[0] === 'Curves U')
	{
		var sz = input.ylength*input.xlength;
		var dz = 0;
		var curveF = moi.command.createFactory( 'curve' );
		for (var x = 0; x<input.xlength; x++) curveF.createInput('point');
		for (var z = 0; z<input.zlength; z++)
		{
			var i = dz;
			for (var y = 0; y<input.ylength; y++)
			{
				for (var x = 0; x<input.xlength; x++) { curveF.setInput(x, input.getPoint(i)); i++; }
				var curveV = curveF.calculate();
				if ( curveV.length > 0) { output.addObject(curveV.item(0)) } else {output.addObject(factory('point', input.getPoint(dz)).item(0)) }
			}
			dz += sz;
		}
		curveF.cancel();
	}
	if ( this.properties.mode[0] === 'Curves V')
	{
		var sz = input.ylength*input.xlength;
		var dz = 0;
		var curveF = moi.command.createFactory( 'curve' );
		for (var y = 0; y<input.ylength; y++) curveF.createInput('point');
		for (var z = 0; z<input.zlength; z++)
		{
			for (var x = 0; x<input.xlength; x++)
			{
				var i = dz+x;
				for (var y = 0; y<input.ylength; y++) { curveF.setInput(y, input.getPoint(i)); i+=input.xlength; }
				var curveV = curveF.calculate();
				if ( curveV.length > 0) { output.addObject(curveV.item(0)) } else {output.addObject(factory('point', input.getPoint(dz)).item(0)) }
			}
			dz += sz;
		}
		curveF.cancel();
	}
	pointF.cancel();
	this.setOutputData(0, output);
}
LiteGraph.registerNodeType("Points/ConvertPts", ConvertPts);


// CloneToPts
function CloneToPts()
{
	this.addInput("Objects","objectlist");
	this.addInput("Frame","pointarray");
	this.addInput("Target","pointarray");
	this.addOutput("Out","objectlist");
}

CloneToPts.title = "CloneToPts";
CloneToPts.desc = "CloneToPts";

CloneToPts.prototype.onExecute = function()
{
	var inObj = this.getInputData(0, moi.geometryDatabase.createObjectList());
	var outObj = moi.geometryDatabase.createObjectList();
	var sourceFrameArray = this.getInputData(1, new pointArray(true));
	var sourceFrame = sourceFrameArray.getFrame(0);
	var targetFrames = this.getInputData(2, new pointArray(true), true);
	
	var targetFramesLength = targetFrames.getLength();

	for (var i = 0; i<targetFramesLength; i++)
	{
		var tf = targetFrames.getFrame(i);
		var sc = targetFrames.getScale(i);
		var orientV = factory('orient', inObj, sourceFrame, tf, true);
		if ( sc !==1 ) orientV = factory('scale', orientV, tf.origin, sc, null, null, false);
		for ( var o=0; o<orientV.length; o++ ) outObj.addObject(orientV.item(o));
	}
	this.setOutputData(0, outObj);
}

LiteGraph.registerNodeType("Points/CloneToPts", CloneToPts);

})();