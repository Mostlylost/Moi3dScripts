// MoI Nodeedit
// Transform v.1.0 - Max Smirnov, 2018
// litegraph.js library (c) Javi Agenjo http://tamats.com

(function(){
	
// Move
function Move()
{
	this.addInput("Objects","objectlist");
	this.addInput("dX","numarray");
	this.addInput("dY","numarray");
	this.addInput("dZ","numarray");
	this.addOutput("Out","objectlist");
	this.properties = {mode:["Long","Long","Long+","Short","Short+"], dx:[0], dy:[0], dz:[0]};
}

Move.title = "Move";
Move.desc = "Move objects";

Move.prototype.onExecute = function()
{
	var data = this.processInOut(this.properties.mode[0], this.multiProcess, null, this.properties.dx, this.properties.dy, this.properties.dz );
	this.properties.dx = data.inputs[1];
	this.properties.dy = data.inputs[2];
	this.properties.dz = data.inputs[3];
	this.setOutputData(0, data.outputs[0]);
}

Move.prototype.multiProcess = function(o, dx, dy, dz)
{
	return [factory('move', o, moi.VectorMath.createPoint(0,0,0), moi.VectorMath.createPoint(dx, dy , dz), true )];
}

LiteGraph.registerNodeType("Transform/Move", Move);

// Orient
function Orient()
{
	this.addInput("Objects","objectlist");
	this.addInput("From","pointarray");
	this.addInput("To","pointarray");
	this.addOutput("Out","objectlist");
	this.properties = {mode:["Long","Long","Long+","Short","Short+"]};
}

Orient.title = "Orient";
Orient.desc = "Orient objects";

Orient.prototype.onExecute = function()
{
	var data = this.processInOut(this.properties.mode[0], this.multiProcess );
	this.setOutputData(0, data.outputs[0]);
}

Orient.prototype.multiProcess = function(o, f, t)
{
	return [factory('orient', o, f.getFrame(0), t.getFrame(0), true )];
}

LiteGraph.registerNodeType("Transform/Orient", Orient);

// Object Rotate
function ObjectRotate()
{
	this.addInput("Objects","objectlist");
	this.addInput("Frame","pointarray");
	this.addInput("rX","numarray");
	this.addInput("rY","numarray");
	this.addInput("rZ","numarray");
	this.addOutput("Out","objectlist");
	this.properties = {mode:["Long","Long","Long+","Short","Short+"], rX:[0], rY:[0], rZ:[0]};
}

ObjectRotate.title = "Rotate";
ObjectRotate.desc = "Rotate objects";

ObjectRotate.prototype.onExecute = function()
{
	var data = this.processInOut(this.properties.mode[0], this.multiProcess, null, null, this.properties.rX, this.properties.rY, this.properties.rZ );
	this.properties.rX = data.inputs[2];
	this.properties.rY = data.inputs[3];
	this.properties.rZ = data.inputs[4];
	this.setOutputData(0, data.outputs[0]);
}

ObjectRotate.prototype.multiProcess = function(o, f, x, y, z)
{
	return [factory('orient', o, f.getFrame(0), f.getFrame(0, x, y, z), true )];
}

LiteGraph.registerNodeType("Transform/Rotate", ObjectRotate);

// Twist
function Twist()
{
	this.addInput("Objects","objectlist");
	this.addInput("Axis start","pointarray");
	this.addInput("Axis end","pointarray");
	this.addInput("Angle","numarray");
	this.addInput("Ease in","numarray");
	this.addInput("Ease out","numarray");
	this.addOutput("Out","objectlist");
	this.properties = {mode:["Long","Long","Long+","Short","Short+"], angle:[0], ease_in:[0], ease_out:[0]};
}

Twist.title = "Twist";
Twist.desc = "Twist";

Twist.prototype.onExecute = function()
{
	var data = this.processInOut(this.properties.mode[0], this.multiProcess, null, null, null, this.properties.angle, this.properties.ease_in, this.properties.ease_out);
	this.properties.angle = data.inputs[3];
	this.properties.ease_in = data.inputs[4];
	this.properties.ease_out = data.inputs[5];
    this.setOutputData(0, data.outputs[0]);
}

Twist.prototype.multiProcess = function( obj, axiss, axise, angle, easei, easeo)
{
	var out = [];
	var as = axiss.getPoint(0);
	var ae = axise.getPoint(0);
	out[0] = factory('twist', obj, as, ae, angle, true, easei, easeo);
	return out;
}

LiteGraph.registerNodeType("Transform/Twist", Twist);

// Flow
function Flow()
{
	this.addInput("Objects","objectlist");
	this.addInput("Base","objectlist");
	this.addInput("Target","objectlist");
	this.addOutput("Out","objectlist");
	this.properties = {mode:["Long","Long","Long+","Short","Short+"], stretch:["On","On","Off"], rigid:["Off","On","Off"], flip:["Off","On","Off"], project:["Off","On","Off"], straight:["On","On","Off"] };
}

Flow.title = "Flow";
Flow.desc = "Flow";

Flow.prototype.onExecute = function()
{
	var data = this.processInOut(this.properties.mode[0], this.multiProcess, null, null, null);
    this.setOutputData(0, data.outputs[0]);
}

Flow.prototype.multiProcess = function( obj, base, target )
{
	var out = [];
    if( obj.length > 0 && base.length > 0 && target.length > 0)
	{
		var b = base.item(0);
		var t = target.item(0);
		var p = this.properties;
		var ok = false;
		if (( b.type === 1 || b.type === 2) && (t.type === 1 || t.type === 2 )) { ok = true }
		else if( b.type === 3 && t.type === 3) if( b.getFaces().length === 1 && t.getFaces().length ===1) { ok = true }
		if ( ok ) out[0] = factory ('flow', obj, b, t, true, p.stretch[0] === "On", p.rigid[0] === "On", null, null, null, null, p.flip[0] === "On", p.project[0] === "On", p.project[0] === "On");
	}
	return out;
}

LiteGraph.registerNodeType("Transform/Flow", Flow);

// CircularArray
function CircularArray()
{
	this.addInput("Objects","objectlist");
	this.addInput("Center","pointarray");
	this.addInput("Count","numarray");
	this.addOutput("Out","objectlist");
	this.properties = { count:[6] };
}

CircularArray.title = "Circular Array";
CircularArray.desc = "Circular Array";

CircularArray.prototype.onExecute = function()
{
	var inObj = this.getInputData(0, moi.geometryDatabase.createObjectList());
	var c = this.getInputData(1, new pointArray(true));
	this.properties.count[0] = this.getInputData(2, this.properties.count[0]);
	this.properties.count[0] = Math.floor(this.properties.count[0]);
	var outObj = moi.geometryDatabase.createObjectList();
	if ( inObj.length > 0 && this.properties.count[0] > 0 )
	{
		outObj = factory( 'arraycircular', inObj, c.getFrame(0), this.properties.count[0], 360 );
		for ( var i = 0; i<inObj.length; i++ ) outObj.addObject(inObj.item(i));
	}
	this.setOutputData(0, outObj);
}

LiteGraph.registerNodeType("Transform/CircularArray", CircularArray);


})();