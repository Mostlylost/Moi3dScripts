// MoI Nodeedit
// Curves v.1.0 - Max Smirnov, 2018
// litegraph.js library (c) Javi Agenjo http://tamats.com

(function(){

// Line
function Line()
{
	this.addInput("a","pointarray");
	this.addInput("b","pointarray");
	this.addOutput("Out","objectlist");
	this.properties = { mode:["Long","Long","Short","Cross","Average","Repeat"] };
}

Line.title = "Line";
Line.desc = "Line";

Line.prototype.onExecute = function()
{
	var data = this.processInOut(this.properties.mode[0], this.multiProcess );
	this.setOutputData(0, data.outputs[0]);
}

Line.prototype.multiProcess = function(a, b)
{
	return [factory( 'line', a.getPoint(), b.getPoint() )];
}

LiteGraph.registerNodeType("Curves/Line", Line);

// Circle
function Circle()
{
	this.addInput("Center","pointarray");
	this.addInput("Radius","numarray");
	this.addOutput("Out","objectlist");
	this.properties = { mode:["Long","Long","Short","Cross"], radius:[1] };
}

Circle.title = "Circle";
Circle.desc = "Circle";

Circle.prototype.onExecute = function()
{
	var data = this.processInOut(this.properties.mode[0], this.multiProcess, null, this.properties.radius );
	this.properties.radius = data.inputs[1];
	this.setOutputData(0, data.outputs[0]);
}

Circle.prototype.multiProcess = function(center, radius)
{
	return [factory( 'circle', true, center.getFrame() , null, radius )];
}

LiteGraph.registerNodeType("Curves/Circle", Circle);

// Rectangle
function Rectangle()
{
	this.addInput("Center","pointarray");
	this.addInput("Width","numarray");
	this.addInput("Height","numarray");
	this.addInput("Corners","numarray");
	this.addOutput("Out","objectlist");
	this.properties = { mode:["Long","Long","Short"], width:[10], height:[10], corners:[0] };
}

Rectangle.title = "Rectangle";
Rectangle.desc = "Rectangle";

Rectangle.prototype.onExecute = function()
{
	var data = this.processInOut(this.properties.mode[0], this.multiProcess, null, this.properties.width, this.properties.height, this.properties.corners );
	this.properties.width = data.inputs[1];
	this.properties.height = data.inputs[2];
	this.properties.corners = data.inputs[3];
	this.setOutputData(0, data.outputs[0]);
}

Rectangle.prototype.multiProcess = function(center, w, h, c)
{
	if ( c > 0 ) { return [factory( 'rectcenter', center.getFrame(), null, w, h, true, null, c) ] }
	else { return [factory( 'rectcenter', center.getFrame(), null, w, h, false) ] }
}

LiteGraph.registerNodeType("Curves/Rectangle", Rectangle);

// Polygon
function Polygon()
{
	this.addInput("Center","pointarray");
	this.addInput("Radius","numarray");
	this.addInput("Sides","numarray");
	this.addOutput("Out","objectlist");
	this.properties = { mode:["Long","Long","Short"], radius:[10], sides:[6], type:["Circumscribed","Circumscribed","Inscribed"] };
}

Polygon.title = "Polygon";
Polygon.desc = "Polygon";

Polygon.prototype.onExecute = function()
{
	var data = this.processInOut(this.properties.mode[0], this.multiProcess, null, this.properties.radius, this.properties.sides);
	this.properties.radius = data.inputs[1];
	this.properties.sides = data.inputs[2];
	this.setOutputData(0, data.outputs[0]);
}

Polygon.prototype.multiProcess = function(center, r, s)
{
	var frame = center.getFrame()
	return [factory( 'polygon', frame, frame.evaluate( 0, r, 0 ), s, (this.properties.type[0] === "Circumscribed"))];
}

LiteGraph.registerNodeType("Curves/Polygon", Polygon);

// Star
function Star()
{
	this.addInput("Center","pointarray");
	this.addInput("Radius","numarray");
	this.addInput("Ratio","numarray");
	this.addInput("Sides","numarray");
	this.addOutput("Out","objectlist");
	this.properties = { mode:["Long","Long","Short"], radius:[10], ratio:[0.4], sides:[5] };
}

Star.title = "Star";
Star.desc = "Star";

Star.prototype.onExecute = function()
{
	var data = this.processInOut(this.properties.mode[0], this.multiProcess, null, this.properties.radius, this.properties.ratio, this.properties.sides);
	this.properties.radius = data.inputs[1];
	this.properties.ratio = data.inputs[2];
	this.properties.sides = data.inputs[3];
	this.setOutputData(0, data.outputs[0]);
}

Star.prototype.multiProcess = function(center, r, rt, s)
{
	var frame = center.getFrame();
	return [factory( 'polygonstar', frame, frame.evaluate( 0, r, 0 ), s, frame.evaluate( 0, r*rt, 0 ))];
}

LiteGraph.registerNodeType("Curves/Star", Star);

// Curve
function Curve()
{
	this.addInput("In","pointarray");
	this.addOutput("Out","objectlist");
	this.properties = { mode:["Curve", "Curve", "Interpcurve"], closed:["No", "No", "Yes"]};
}

Curve.title = "Curve";
Curve.desc = "Curve";

Curve.prototype.onExecute = function()
{
	var data = this.processInOut("LongZ", this.multiProcess);
	this.setOutputData(0, data.outputs[0]);
}

Curve.prototype.multiProcess = function(p)
{

	var i, output, ln = p.length, factory;
	if (this.properties.mode[0] === "Curve") { factory = moi.command.createFactory( 'curve' ) }
	else if (this.properties.mode[0] === "Interpcurve") { factory = moi.command.createFactory( 'interpcurve' ) }
	for (i = 0; i<ln; i++)
	{
		factory.createInput('point');
		factory.setInput(i, p.getPoint(i));
	}
	if ( ln > 0 && this.properties.closed[0] === this.properties.closed[2]) { factory.createInput('point'); factory.setInput(i, p.getPoint(0)); }
	output = factory.calculate();
	factory.cancel();
	return [output]
}
LiteGraph.registerNodeType("Curves/Curve", Curve);

// Polyline
function Polyline()
{
	this.addInput("In","pointarray");
	this.addOutput("Out","objectlist");
	this.properties = {closed:["No", "No", "Yes"]};
}

Polyline.title = "Polyline";
Polyline.desc = "Polyline";

Polyline.prototype.onExecute = function()
{
	var data = this.processInOut("LongY", this.multiProcess);
	this.setOutputData(0, data.outputs[0]);
}

Polyline.prototype.multiProcess = function(p)
{
	var i, output, ln = p.length, factory = moi.command.createFactory( 'polyline' );
	for (i = 0; i<ln; i++)
	{
		factory.createInput('point');
		factory.setInput(i, p.getPoint(i));
	}
	if ( ln > 0 && this.properties.closed[0] === this.properties.closed[2]) { factory.createInput('point'); factory.setInput(i, p.getPoint(0)); }
	output = factory.calculate();
	factory.cancel();
	return [output]
}

LiteGraph.registerNodeType("Curves/Polyline", Polyline);

})();