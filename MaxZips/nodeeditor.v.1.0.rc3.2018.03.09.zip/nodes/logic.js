// MoI Nodeedit
// Logic v.1.0 - Max Smirnov, 2018
// litegraph.js library (c) Javi Agenjo http://tamats.com

(function(){

// Compare
function Compare()
{
	this.addInput("a","numarray");
	this.addInput("b","numarray");
	this.addOutput("Out","numarray");
	this.properties = { mode:["Long","Long","Short"], operator:["a < b","a < b","a <= b","a = b","a => b","a > b","a <> b","a & b","a | b"], a:[0], b:[0] };
	this.local = {operator:1};
}

Compare.title = "Compare";
Compare.desc = "Compare";

Compare.prototype.onAdded = function()
{
	this.onPropertyChange();
}

Compare.prototype.onPropertyChange = function()
{
	this.outputs[0].label = this.properties.operator[0];
	this.computeSize();
}

Compare.prototype.onExecute = function()
{
	this.local.operator = this.properties.operator.lastIndexOf(this.properties.operator[0]);
	var data = this.processInOut(this.properties.mode[0], this.multiProcess, this.properties.a, this.properties.b);
	this.properties.a = data.inputs[0];
	this.properties.b = data.inputs[1];
	if (data.outputs[0].length === 0) data.outputs[0] = [0];
	this.setOutputData(0, data.outputs[0]);
}

Compare.prototype.multiProcess = function(a, b)
{
	var x;
	switch (this.local.operator)
	{
		case 1: x = (a < b); break;
		case 2: x = (a <= b); break;
		case 3: x = (a === b); break;
		case 4: x = (a >= b); break;
		case 5: x = (a > b); break;
		case 6: x = (a !== b); break;

		case 7: x = ((a>0) && (b>0)); break;
		case 8: x = ((a>0) || (b>0)); break;
	}

	return [x*1];
}
LiteGraph.registerNodeType("Logic/Compare", Compare);

// Split
function Split()
{
	this.dynamicInputs = [0];
	this.dynamicOutputs = [0,1];
	this.addInput("Num","numarray");
	this.addInput("Mask","numarray");
	this.addOutput("1","numarray");
	this.addOutput("0","numarray");
	this.properties = { mode:["Repeat","Repeat", "Long","Short"], mask:[1,0] };
}

Split.title = "Split";
Split.desc = "Split";

Split.prototype.getExtraMenuOptions = function()
{
	var that = this;
	return [
	{content:lang.getTranslation("Numbers"), callback: function() { if (that.inputs[0].type !== "numarray" ) { that.changeInputType(0,"numarray","Num"); that.changeOutputType(0,"numarray"); that.changeOutputType(1,"numarray") }}},
	{content:lang.getTranslation("Points"), callback: function() { if (that.inputs[0].type !== "pointarray" ) { that.changeInputType(0,"pointarray","Pts"); that.changeOutputType(0,"pointarray"); that.changeOutputType(1,"pointarray") }}},
	{content:lang.getTranslation("Objects"), callback: function() { if (that.inputs[0].type !== "objectlist" ) { that.changeInputType(0,"objectlist","Obj"); that.changeOutputType(0,"objectlist"); that.changeOutputType(1,"objectlist") }}}
	];
}

Split.prototype.onExecute = function()
{
	var processFnc;
	if (this.inputs[0].type === "numarray") processFnc = this.multiProcessNum;
	if (this.inputs[0].type === "pointarray") processFnc = this.multiProcessPts;
	if (this.inputs[0].type === "objectlist") processFnc = this.multiProcessObj;

	var data = this.processInOut(this.properties.mode[0], processFnc, null, this.properties.mask);
	this.properties.mask = data.inputs[1];
	this.setOutputData(0, data.outputs[0]);
	this.setOutputData(1, data.outputs[1]);
}

Split.prototype.multiProcessNum = function(a, m) { return (m>0)?[a,null]:[null, a] }

Split.prototype.multiProcessPts = function(a, m)
{
	var empty = new pointArray(false);
	if (m>0) return [a,empty];
	return [empty, a];
}

Split.prototype.multiProcessObj = function(a, m)
{
	var empty = moi.geometryDatabase.createObjectList();
	if (m>0) return [a,empty];
	return [empty, a];
}


LiteGraph.registerNodeType("Logic/Split", Split);


})();