// MoI Nodeedit
// Objects v.1.0 - Max Smirnov, 2018
// litegraph.js library (c) Javi Agenjo http://tamats.com

(function(){

// Object clone
function Clone()
{
	this.addInput("In","objectlist");
	this.addOutput("a","objectlist");
	this.addOutput("b","objectlist");
}

Clone.title = "Clone";
Clone.desc = "Clone objects";

Clone.prototype.onExecute = function()
{
	var inObj = this.getInputData(0, moi.geometryDatabase.createObjectList());
	var cloneObj = moi.geometryDatabase.createObjectList();
	for (var i = 0; i < inObj.length; i++ ) { cloneObj.addObject(inObj.item(i).clone()); cloneObj.item(i).styleIndex = inObj.item(i).styleIndex; }
	this.setOutputData(0, inObj);
	this.setOutputData(1, cloneObj);
}
LiteGraph.registerNodeType("Objects/Clone", Clone);

// Get selected objects
function SelectedObjects()
{
	this.addOutput("","objectlist");
	this.inputobjects = moi.geometryDatabase.createObjectList();
	this.clones = moi.geometryDatabase.getObjects();
}

SelectedObjects.title = "Selected";
SelectedObjects.desc = "Selected objects";

SelectedObjects.prototype.onAdded = function()
{
	var allobjects = moi.geometryDatabase.getObjects();
	var createdObjs = this.graph.getCreatedObjects();
	for ( var o = 0; o < allobjects.length; o++ ) { var obj = allobjects.item(o); if ( obj.selected && obj.displayMode === 0 && !obj.hidden && createdObjs.indexOf(obj.id)<0 ) this.inputobjects.addObject(obj); }
	this.inputobjects.sortBySelectionOrder();
	this.inputobjects.setProperty( 'selected',0);
	this.inputobjects.setProperty( 'displayMode',1);
	if (this.graph.status > 1 && !this.selected ) this.inputobjects.setProperty( 'hidden', true);
	this.outputs[0].label = "("+this.inputobjects.length+")";
	this.clones = moi.geometryDatabase.createObjectList();
	for ( var o = 0; o < this.inputobjects.length; o++ ) { this.clones.addObject(this.inputobjects.item(o).clone()); this.clones.item(o).styleIndex = this.inputobjects.item(o).styleIndex; }
	this.computeSize();
}
SelectedObjects.prototype.getExtraMenuOptions = function() {var that = this, thatgraph = this.graph;  return [{content:lang.getTranslation("Update"), callback: function() { that.onClear(); that.onAdded(); thatgraph.setisChangedFlag(that.id);}}, { content:lang.getTranslation("Clear"), callback: function() { that.onClear(); thatgraph.setisChangedFlag(that.id);}}]; }
SelectedObjects.prototype.onClear = function() { this.onRemoved(); this.inputobjects = moi.geometryDatabase.createObjectList(); this.outputs[0].label = this.inputobjects.length; this.clones = moi.geometryDatabase.createObjectList();}
SelectedObjects.prototype.onRemoved = function() { this.inputobjects.setProperty( 'displayMode',0); this.inputobjects.setProperty( 'hidden', false);  this.inputobjects.setProperty( 'selected',1);}
SelectedObjects.prototype.onStart = function() { if (!this.selected) this.inputobjects.setProperty( 'hidden',true); }
SelectedObjects.prototype.onStop = function() { this.inputobjects.setProperty( 'hidden', false); }
SelectedObjects.prototype.onSelected = function() { this.inputobjects.setProperty( 'hidden', false); }
SelectedObjects.prototype.onDeselected = function() { if (this.graph.status > 1) this.inputobjects.setProperty( 'hidden',true); }
SelectedObjects.prototype.onExecute = function()
{
	this.setOutputData(0, this.clones);
}
SelectedObjects.prototype.onApply = function() {}
SelectedObjects.prototype.onDrawBackground = function() {}

LiteGraph.registerNodeType("Objects/Selected", SelectedObjects);


// GetByName
function GetByName()
{
	this.properties = {name:["--", "--"]};
	this.addOutput("","objectlist");
	this.inputobjects = moi.geometryDatabase.createObjectList();
	this.clones = moi.geometryDatabase.getObjects();
}

GetByName.title = "Get by name";
GetByName.desc = "Get objects by name";

GetByName.prototype.onAdded = function()
{
	this.properties.name = this.properties.name.slice(0,2);
	var allobjects = moi.geometryDatabase.getObjects();
	var objname = [];
	for ( var o = 0; o < allobjects.length; o++ ) if (allobjects.item(o).name !== "") objname[allobjects.item(o).name] = true;
	for ( var n in objname ) this.properties.name.push(n);
	this.onPropertyChange();
}

GetByName.prototype.onPropertyChange = function()
{
	this.inputobjects.setProperty( 'displayMode',0);
	this.inputobjects.setProperty( 'hidden', false);
	this.inputobjects = moi.geometryDatabase.createObjectList();
	var allobjects = moi.geometryDatabase.getObjects();
	var createdObjs = this.graph.getCreatedObjects();
	for ( var o = 0; o < allobjects.length; o++ ) { var obj = allobjects.item(o); if ( obj.name === this.properties.name[0] && obj.displayMode === 0 && !obj.hidden && createdObjs.indexOf(obj.id)<0 ) this.inputobjects.addObject(obj); }
	this.inputobjects.setProperty( 'displayMode',1);
	if (this.graph.status > 1 && !this.selected ) this.inputobjects.setProperty( 'hidden', true);
	this.outputs[0].label = this.properties.name[0]+" ("+this.inputobjects.length+")";
	this.clones = moi.geometryDatabase.createObjectList();
	for ( var o = 0; o < this.inputobjects.length; o++ ) { this.clones.addObject(this.inputobjects.item(o).clone()); this.clones.item(o).styleIndex = this.inputobjects.item(o).styleIndex; }
	this.computeSize();
}

GetByName.prototype.onClear = function() { this.inputobjects.setProperty( 'hidden', false); this.inputobjects.setProperty( 'displayMode',0); this.clones = moi.geometryDatabase.createObjectList();}
GetByName.prototype.onStart = function() { if (!this.selected) this.inputobjects.setProperty( 'hidden',true); }
GetByName.prototype.onStop = function() { this.inputobjects.setProperty( 'hidden', false); }
GetByName.prototype.onSelected = function() { this.inputobjects.setProperty( 'hidden', false); }
GetByName.prototype.onDeselected = function() { if (this.graph.status > 1) this.inputobjects.setProperty( 'hidden',true); }
GetByName.prototype.onRemoved = function() { this.onClear(); }
GetByName.prototype.getExtraMenuOptions = function() { var that = this, thatgraph = this.graph; return [{content:lang.getTranslation("Update"), callback: function() { that.onPropertyChange(); thatgraph.setisChangedFlag(that.id);}}]; }
GetByName.prototype.onExecute = function()
{
	this.setOutputData(0, this.clones);
}
GetByName.prototype.onApply = function() {}
GetByName.prototype.onDrawBackground = function() {}

LiteGraph.registerNodeType("Objects/GetByName", GetByName);


// GetByStyle
function GetByStyle()
{
	this.properties = {style:["--", "--"]};
	this.addOutput("","objectlist");
	this.inputobjects = moi.geometryDatabase.createObjectList();
	this.clones = moi.geometryDatabase.getObjects();
}

GetByStyle.title = "Get by style";
GetByStyle.desc = "Get objects by style";

GetByStyle.prototype.onAdded = function()
{
	this.properties.style = this.properties.style.slice(0,2);
	var styles = moi.geometryDatabase.getObjectStyles();
	for ( var n=0; n<styles.length; n++ ) this.properties.style.push(styles.item(n).name);
	this.onPropertyChange();
}

GetByStyle.prototype.onPropertyChange = function()
{
	var styles = moi.geometryDatabase.getObjectStyles();
	this.inputobjects.setProperty( 'displayMode',0);
	this.inputobjects.setProperty( 'hidden', false);
	this.inputobjects = moi.geometryDatabase.createObjectList();
	var allobjects = moi.geometryDatabase.getObjects();
	var createdObjs = this.graph.getCreatedObjects();
	for ( var o = 0; o < allobjects.length; o++ ) { var obj = allobjects.item(o); if (styles.item(obj.styleIndex).name === this.properties.style[0] && obj.displayMode === 0 && !obj.hidden && createdObjs.indexOf(obj.id)<0 ) this.inputobjects.addObject(obj); }
	this.inputobjects.setProperty( 'displayMode',1);
	if (this.graph.status > 1 && !this.selected ) this.inputobjects.setProperty( 'hidden', true);
	this.outputs[0].label = this.properties.style[0]+" ("+this.inputobjects.length+")";
	this.clones = moi.geometryDatabase.createObjectList();
	for ( var o = 0; o < this.inputobjects.length; o++ ) { this.clones.addObject(this.inputobjects.item(o).clone()); this.clones.item(o).styleIndex = this.inputobjects.item(o).styleIndex; }
	// if ( this.inputobjects.length > 0 ) this.color = styles.item(this.inputobjects.item(0).styleIndex).hexcolor;
	this.computeSize();
}

GetByStyle.prototype.onClear = function() { this.inputobjects.setProperty( 'hidden', false); this.inputobjects.setProperty( 'displayMode',0); this.clones = moi.geometryDatabase.createObjectList();}
GetByStyle.prototype.onStart = function() { if (!this.selected) this.inputobjects.setProperty( 'hidden',true); }
GetByStyle.prototype.onStop = function() { this.inputobjects.setProperty( 'hidden', false); }
GetByStyle.prototype.onSelected = function() { this.inputobjects.setProperty( 'hidden', false); }
GetByStyle.prototype.onDeselected = function() { if (this.graph.status > 1) this.inputobjects.setProperty( 'hidden',true); }
GetByStyle.prototype.onRemoved = function() { this.onClear(); }
GetByStyle.prototype.getExtraMenuOptions = function() { var that = this, thatgraph = this.graph; return [{content:"Update", callback: function() { that.onPropertyChange(); thatgraph.setisChangedFlag(that.id);}}]; }
GetByStyle.prototype.onExecute = function()
{
	this.setOutputData(0, this.clones);
}
GetByStyle.prototype.onApply = function() { }
GetByStyle.prototype.onDrawBackground = function() {}

LiteGraph.registerNodeType("Objects/GetByStyle", GetByStyle);


// ObjtoArray
function ObjtoArray()
{
	this.addInput("In","objectlist");
	this.addOutput("Out","objectlist");
	this.addOutput("Array","pointarray");
	this.properties = {mode:["Points", "Points"]};
}

ObjtoArray.title = "ObjtoArray";
ObjtoArray.desc = "Objects to pointarray";

ObjtoArray.prototype.onExecute = function()
{
	var input = this.getInputData(0, moi.geometryDatabase.createObjectList());
	var out = new pointArray();
	if (this.properties.mode[0] === "Points" )
	{
		var obj = input.getPoints();
		for ( var i = 0; i<obj.length; i++ ) out.pushPoint(obj.item(i).pt);
	}
	this.setOutputData(0, input);
	this.setOutputData(1, out);
}

LiteGraph.registerNodeType("Objects/ObjtoArray", ObjtoArray);


// GetBBox
function GetBBox()
{
	this.addInput("In","objectlist");
	this.addOutput("Out","objectlist");
	this.addOutput("BBox Center","pointarray");
}

GetBBox.title = "BoundingBox";
GetBBox.desc = "Get BoundingBox";

GetBBox.prototype.onExecute = function()
{
	var input = this.getInputData(0, moi.geometryDatabase.createObjectList());
	var bbox = new pointArray();
	bbox.pushPoint(input.getBoundingBox().center);
	this.setOutputData(0, input);
	this.setOutputData(1, bbox);
}

LiteGraph.registerNodeType("Objects/GetBBox", GetBBox);

})();