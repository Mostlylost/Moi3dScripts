// MoI Nodeedit
// Macros v.1.0 - Max Smirnov, 2018
// litegraph.js library (c) Javi Agenjo http://tamats.com

(function(){
	
//Macros: a node that contains a graph
function Subgraph()
{
	var that = this;
	this.isMacro = true;
	this.size = [120,60];
	this.dynamicInputs = ["*"];
	this.dynamicOutputs = ["*"];
	this.updateInput = [];

	//create inner graph
	this.subgraph = new LGraph();
	this.subgraph._subgraph_node = this;
	this.subgraph._is_subgraph = true;
	this.subgraph.onGlobalInputAdded = this.bindFunction(this.onSubgraphNewGlobalInput, this);
	this.subgraph.onGlobalOutputAdded = this.bindFunction(this.onSubgraphNewGlobalOutput, this);
	this.bgcolor = LiteGraph.NODE_MACRO_COLOR;
}

Subgraph.title = "Macro";
Subgraph.desc = "Macro inside a node";

Subgraph.prototype.bindFunction = function(func, context){ return function() { return func.apply(context, arguments) }}

Subgraph.prototype.onDblClick = function()
{
	if(!this.graph || !this.graph.list_of_graphcanvas) return;
	var canvas = this.graph.list_of_graphcanvas[0];
	canvas.openSubgraph(this.subgraph);
}

Subgraph.prototype.onClear = function() { this.subgraph.sendEventToAllNodes("onClear") }
Subgraph.prototype.onApply = function() { this.subgraph.sendEventToAllNodes("onApply") }
Subgraph.prototype.onStart = function() { this.subgraph.status = LGraph.STATUS_RUNNING; this.subgraph.sendEventToAllNodes("onStart") }
Subgraph.prototype.onStop = function() { this.subgraph.status = LGraph.STATUS_STOPPED; this.subgraph.sendEventToAllNodes("onStop") }
Subgraph.prototype.onRemoved = function() { this.subgraph.sendEventToAllNodes("onClear") }

Subgraph.prototype.onSubgraphNewGlobalInput = function(id, name, type)
{
	//add input to the node
	this.updateInput.push(true);
	for ( var i in this.inputs ) if ( this.inputs[i].globalid ) if ( this.inputs[i].globalid === id ) return;
	this.addInput(name, type, { globalid: id });
}

Subgraph.prototype.onSubgraphNewGlobalOutput = function(id, name, type)
{
	//add output to the node
	for ( var i in this.outputs ) if ( this.outputs[i].globalid ) if ( this.outputs[i].globalid === id ) return;
	this.addOutput(name, type, { globalid: id });
}

Subgraph.prototype.exportMacro = function ()
{
	if (this.graph.blocked) return;
	var saveFilePath = moi.filesystem.getSaveFileName( lang.getTranslation('Export')+' ..',  lang.getTranslation('MoI Nodeeditor macro')+' (*.nod)|*.nod' );
	if ( !saveFilePath ) return false;
	var data = this.subgraph.serialize();
	for (var n in data.nodes) if ( data.nodes[n].internal ) if ( data.nodes[n].internal.globalid ) delete data.nodes[n].internal.globalid;
	data.macroTitle = this.title;
	var file = moi.filesystem.openFileStream( saveFilePath, 'w' );
	file.writeLine(LiteGraph.JSONprettify(data, {"indent":"	", 'maxLength':150}));
	file.close();
}

Subgraph.prototype.getExtraMenuOptions = function(graphcanvas)
{
	var that = this;
	return [{content:lang.getTranslation("Open"), callback: function() { graphcanvas.openSubgraph( that.subgraph ) }},
			{content:lang.getTranslation("Export"), callback: function() { that.exportMacro() }}];
}

Subgraph.prototype.onExecute = function()
{
	var i;
	for ( i in this.updateInput )
	{
		if ( this.updateInput[i] ) this.subgraph.setGlobalInputData( this.inputs[i].globalid, this.getInputData(i));
		this.updateInput[i] = false;
	}
	this.subgraph.runStep();
	if( this.outputs ) for( i = 0; i < this.outputs.length; i++) this.setOutputData(i, this.subgraph.getGlobalOutputData( this.outputs[i].globalid ));
}

Subgraph.prototype.onInputRemoved = function(slot)
{
	this.updateInput.splice(slot,1);
}

Subgraph.prototype.configure = function(o)
{
	LGraphNode.prototype.configure.call(this, o);
	if (LiteGraph.debug) console.log("Subgraph configured");
}

Subgraph.prototype.serialize = function()
{
	var data = LGraphNode.prototype.serialize.call(this, true);
	data.subgraph = this.subgraph.serialize();
	return data;
}

Subgraph.prototype.clone = function()
{
	var node = LiteGraph.createNode(this.type);
	var data = this.serialize(true);
	for (var i in data.inputs) data.inputs[i].link = null;
	for (var o in data.outputs) data.outputs[o].links = null;
	for (var n in data.subgraph.nodes) if ( data.subgraph.nodes[n].internal ) if ( data.subgraph.nodes[n].internal.globalid ) delete data.subgraph.nodes[n].internal.globalid;
	delete data["id"];
	delete data["inputs"];
	delete data["outputs"];
	node.configure(data);
	return node;
}

LiteGraph.registerNodeType("Macros/Container", Subgraph );


//Input for a macro
function GlobalInput()
{
	this.bgcolor = LiteGraph.link_type_colors["numarray"];
	this.dynamicOutputs = [0];
	this.dynamicInternal = ["globalid"];
	this.internal = { type:"numarray" };
}

GlobalInput.title = "In";
GlobalInput.desc = "Input of the macro";

GlobalInput.prototype.onAdded = function()
{
	var thatnode = this;
	if ( this.outputs.length < 1) this.addOutput("", this.internal.type);
	if ( !this.internal.hasOwnProperty("globalid") ) this.internal.globalid = "in_" + (Math.random()*1000000).toFixed();
	if ( this.graph.isGlobalExists(this.internal.globalid) ) this.internal.globalid = "in_" + (Math.random()*1000000).toFixed();
	this.graph.addGlobalInput( this.internal.globalid, this.title, this.internal.type, thatnode );
}

GlobalInput.prototype.onRemoved = function()
{
	var i = this.graph._subgraph_node.getGlobalInput(this.internal.globalid);
	this.graph.removeGlobalInput(this.internal.globalid);
	if ( i === null ) return;
	this.graph._subgraph_node.removeInput(i,this.title);
	this.graph._subgraph_node.computeSize();
}

GlobalInput.prototype.onTitleChange = function()
{
	var i = this.graph._subgraph_node.getGlobalInput(this.internal.globalid);
	if ( i === null ) return;
	this.graph._subgraph_node.inputs[i].name = this.title;
	this.graph._subgraph_node.computeSize();
}

GlobalInput.prototype.changeGlobalType = function( iType )
{
	if ( this.outputs[0].type !== iType )
	{
		this.internal.type = iType;
		this.bgcolor = LiteGraph.link_type_colors[iType];
		this.changeOutputType(0,iType);
		this.setDirtyCanvas(true);
		this.graph.global_inputs[this.internal.globalid].type = iType;
		var i = this.graph._subgraph_node.getGlobalInput(this.internal.globalid);
		if ( i === null ) return;
		this.graph._subgraph_node.changeInputType(i,iType);
		this.graph._subgraph_node.computeSize();
	}
}

GlobalInput.prototype.getExtraMenuOptions = function()
{
	var that = this;
	return [
	{content:lang.getTranslation("Numbers"), callback: function() { that.changeGlobalType("numarray") }},
	{content:lang.getTranslation("Points"), callback: function() { that.changeGlobalType("pointarray") }},
	{content:lang.getTranslation("Objects"), callback: function() { that.changeGlobalType("objectlist") }}
	];
}

GlobalInput.prototype.onExecute = function()
{
	var	data = this.graph.global_inputs[this.internal.globalid];
	if(!data) return;
	this.setOutputData(0,data.value);
}

LiteGraph.registerNodeType("Macros/Input", GlobalInput);

//Output for a macro
function GlobalOutput()
{
	this.bgcolor = LiteGraph.link_type_colors["numarray"];
	this.macro_out = true;
	this.dynamicInputs = [0];
	this.dynamicInternal = ["globalid"];
	this.internal = { type:"numarray" };
}

GlobalOutput.title = "Out";
GlobalOutput.desc = "Output of the macro";

GlobalOutput.prototype.onAdded = function()
{
	var thatnode = this;
	if ( this.inputs.length < 1) this.addInput("", this.internal.type);
	if ( !this.internal.hasOwnProperty("globalid") ) this.internal.globalid = "out_" + (Math.random()*1000000).toFixed();
	if ( this.graph.isGlobalExists(this.internal.globalid) ) this.internal.globalid = "out_" + (Math.random()*1000000).toFixed();
	this.graph.addGlobalOutput( this.internal.globalid, this.title, this.internal.type );
}

GlobalOutput.prototype.onRemoved = function()
{
	var i = this.graph._subgraph_node.getGlobalOutput(this.internal.globalid);
	this.graph.removeGlobalOutput(this.internal.globalid);
	if ( i === null ) return;
	this.graph._subgraph_node.removeOutput(i,this.title);
	this.graph._subgraph_node.computeSize();
}

GlobalOutput.prototype.onTitleChange = function()
{
	var i = this.graph._subgraph_node.getGlobalOutput(this.internal.globalid);
	if ( i === null ) return;
	this.graph._subgraph_node.outputs[i].name = this.title;
	this.graph._subgraph_node.computeSize();
}

GlobalOutput.prototype.changeGlobalType = function( iType )
{
	if ( this.inputs[0].type !== iType )
	{
		this.internal.type = iType;
		this.bgcolor = LiteGraph.link_type_colors[iType];
		this.changeInputType(0,iType);
		this.setDirtyCanvas(true);
		this.graph.global_outputs[this.internal.globalid].type = iType;
		var i = this.graph._subgraph_node.getGlobalOutput(this.internal.globalid);
		if ( i === null ) return;
		this.graph._subgraph_node.changeOutputType(i,iType);
		this.graph._subgraph_node.computeSize();
	}
}

GlobalOutput.prototype.getExtraMenuOptions = function()
{
	var that = this;
	return [
	{content:lang.getTranslation("Numbers"), callback: function() { that.changeGlobalType("numarray") }},
	{content:lang.getTranslation("Points"), callback: function() { that.changeGlobalType("pointarray") }},
	{content:lang.getTranslation("Objects"), callback: function() { that.changeGlobalType("objectlist") }}
	];
}

GlobalOutput.prototype.onExecute = function()
{
	this.graph.setGlobalOutputData( this.internal.globalid, this.getInputData(0, null ) );
	//if (this.graph.is_macro) if (this.graph._subgraph_node.isChanged) this.graph._subgraph_node.graph.setisChangedFlag(this.graph._subgraph_node.id);
}

LiteGraph.registerNodeType("Macros/Output", GlobalOutput);

LiteGraph.macrosActivated = true;
})();