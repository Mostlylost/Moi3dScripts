﻿//	Nodeedit for Moment of inspiration 1.0, Max Smirnov Copyright (C) 2018
//  Color schemes

var scheme = { SCHEME: (NeParameters.scheme === undefined )?"Default":NeParameters.scheme }

scheme.colors = {
	Default:{
				'editor_background'		:"rgb(62,62,62)",		//
				'editor_grid'			:"rgb(50,50,50)",		//
				'editor_border'			:"rgba(0,0,0,0.2)",		//
				'editor_menu_background':"#333",				//
				'editor_menu_buttons'	:"#DDD",				//
/* disabled */	'editor_menu_buttons_bg':"#444",				//
/* obsolete	*/	'link_number'			:"#399",				//
				'link_numarray'			:"#9CA",				//
				'link_pointarray'		:"#B7A",				//
				'link_objectlist'		:"#CA0",				//
/* reserved	*/	'link_boolean'			:"#9BC",				//
				'link_border'			:"rgba(0,0,0,0.5)",		// DON'T
				'link_connect_point'	:"#FC0",				//
				'node_default'			:"#999",				// EDIT
				'node_background'		:"#444",				//
				'node_box'				:"#AAA",				// THIS
				'node_title'			:"#222",				//
				'node_shadow'			:"rgba(20,20,20,0.5)",	// SCHEME
				'node_error_box'		:"#F00",				//
				'node_macro'			:"#445",				//
				'node_error_title'		:"#700",				//
				'menu_text'				:"#FFF",				//
				'menu_border'			:"#888",				//
				'menu_border_shadow'	:"#222",				//
				'menu_background'		:"#404045",				//
				'selection'				:"#CCC",				//
				'info'					:"#CCC",				//
				'title_text_font'		:"bold 0.14in Arial",	//
				'io_text_font'			:"normal 0.13in Arial"	//
			},
		
	Light:	{
				'editor_background'		:"#BBBBB8",
				'editor_grid'			:"#AAA",
				'link_border'			:"rgba(0,0,0,0.45)",
				'node_background'		:"#383838",
				'node_box'				:"#AAA",
				'node_title'			:"#CCC",
				'node_shadow'			:"rgba(80,80,80,0.5)",
				'menu_text'				:"#000",
				'menu_border'			:"#EEE",
				'menu_border_shadow'	:"#888",
				'menu_background'		:"#BBB",
				'selection'				:"#77F",
				'info'					:"#222"
			},

	MyColors:{
				// ADD CUSTOM COLOR SCHEME HERE
	}
}

scheme.getColor = function( cl ) { if (this.colors[this.SCHEME][cl]) { return this.colors[this.SCHEME][cl] } else { return this.colors["Default"][cl] } }

if (!scheme.colors[scheme.SCHEME]) { scheme.SCHEME = "Default" }