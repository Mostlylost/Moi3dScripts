﻿//	Nodeedit for Moment of inspiration 1.0, Max Smirnov Copyright (C) 2018
//  Compatibility lib

var compatibilityLookupTable = { }

compatibilityLookupTable.nodetype = {
	"Arrays/MathArray"			: "Points/MathPts",
	"Arrays/TextArray"			: "Points/TextPts",
	"Arrays/SphereArray"		: "Points/SpherePts",
	"Arrays/MoveArray"			: "Points/MovePts",
	"Arrays/RotateArray"		: "Points/RotatePts",
	"Arrays/JitterArray"		: "Points/JitterPts",
	"Arrays/ConcatArray"		: "Points/ConcatPts",
	"Arrays/ShowPointArray"		: "Points/ConvertPts",
	"Arrays/ConvertArray"		: "Points/ConvertPts",
	"Arrays/CloneToArray"		: "Points/CloneToPts",
	"Arrays/CloneObject"		: "Objects/Clone",
	"Basic/Frame"				: "Points/RotatePts",
	"Factories/Sphere"			: "Solids/Sphere",
	"Factories/Circle"			: "Curves/Circle",
	"Factories/CircularArray"	: "Transform/CircularArray",
	"Factories/Loft"			: "Construct/Loft",
	"Objects/Rotate"			: "Transform/Rotate",
	"Objects/ObjByName"			: "Objects/GetByName",
	"Points/ConcatPts"			: "Basic/Concat",
	"Objects/Concat"			: "Basic/Concat"
}

compatibilityLookupTable.properties = {
	"Points/SpherePts"	: {"P_num":"Count", "PtNum":"Count"},
	"Points/JitterPts"	: {"ds":"dS"},
	"Points/RotatePts"	: {"x_angle":"rX", "y_angle":"rY", "z_angle":"rZ"}
}

compatibilityLookupTable.getNodeType = function( type )
{
	while (this.nodetype[type]) type = this.nodetype[type];
	return type;
}

compatibilityLookupTable.getPropName = function( type, name )
{
	if (this.properties[type]) if (this.properties[type][name]) name = this.properties[type][name];
	return name;
}