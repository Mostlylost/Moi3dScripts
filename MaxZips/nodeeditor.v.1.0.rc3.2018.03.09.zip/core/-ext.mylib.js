//	Nodeedit for Moment of inspiration 1.0, Max Smirnov Copyright (C) 2018
//  Core extension example

function MyUI(e)
{
	this.editor = e;
	this.panel = this.addCustomPanel();
	this.insertX = 150;
	this.insertY = 50;
	this.initCustomPanel();
	this.addCustomButton("myui_button", "", "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAACUmlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNS41LjAiPgogPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4KICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgeG1sbnM6dGlmZj0iaHR0cDovL25zLmFkb2JlLmNvbS90aWZmLzEuMC8iCiAgICB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iCiAgICB4bWxuczpleGlmRVg9Imh0dHA6Ly9jaXBhLmpwL2V4aWYvMS4wLyIKICAgIHhtbG5zOmF1eD0iaHR0cDovL25zLmFkb2JlLmNvbS9leGlmLzEuMC9hdXgvIgogICB0aWZmOkltYWdlTGVuZ3RoPSIzMiIKICAgdGlmZjpJbWFnZVdpZHRoPSIzMiIKICAgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBJbWFnZVJlYWR5IgogICBleGlmRVg6TGVuc01vZGVsPSIiCiAgIGF1eDpMZW5zPSIiLz4KIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+Cjw/eHBhY2tldCBlbmQ9InIiPz7F1STYAAABS2lDQ1BBZG9iZSBSR0IgKDE5OTgpAAAokWNgYArJSc4tZhJgYMjNKykKcndSiIiMUmC/wMDBwM0gzGDMYJ2YXFzgGBDgwwAEefl5qQwY4Ns1BkYQfVkXZBamPF7AlVxQVAKk/wCxUUpqcTIDA6MBkD2hvKQAKM54AMgWScoGs6+A2EUhQc5A9gsgmy8dwv4BYieB2UwcIHYR0BNAtgRIfTqErQM2B8J2ALFLUitA9jI45xdUFmWmZ5QoGBkYGCg4puQnpSoEVxaXpOYWK3jmJecXFeQXJZakpgDVQtwHBoIQhaAQ0zC0tLTQhHlIkMGRIYUhnyGJIZVBgSGIwZ3BCUhrMBgyWAKhBQNcIRUAKK4grM+B4DhgFDuDEEOA5NKiMiiTkcmYMB9hxhxgGPovZWBg+YMQM+llYFgADE/+qQgxNUMGBgF9BoZ9cwA5v1VT+Fev5gAAAAlwSFlzAAALEwAACxMBAJqcGAAAAD1JREFUWIXt06EVACAUQtGvY7D/bKyhWZPlH4LvRgoUqgD8btyB7dVZKOnonJ1lL+IDAG4YHwBww/gAAHEbIqcMEAu86woAAAAASUVORK5CYII=");
}

MyUI.prototype.addCustomButton = function (id, name, icon)
{
	var root = document.querySelector(".tools-left");
	var button = document.createElement("button");
	button.id = id;
	button.style.color = scheme.getColor('editor_menu_buttons');
	button.innerHTML = "<img src='" + icon + "'/> " + name;
	button.addEventListener("click", this.bindFunction(this.onCustomButtonClick, this));
	root.insertBefore(button, root.firstChild);
}

MyUI.prototype.addCustomPanel = function()
{
	var root = document.querySelector(".content");
	var panel = document.createElement("div");
	panel.id = "custom-panel";
	panel.className = "node-panel";
	panel.style.cssText = "color: #333; width: 160px; left: 0px; display:none; background-color: #777;";
	panel.innerHTML = "<div id='custom-list' class='node-panel-list' style='margin-left:10px;'></div>";
	panel.addEventListener("mousewheel", this.bindFunction(this.processMouseWheelInfo, this), false);
	return root.appendChild(panel);
}

MyUI.prototype.initCustomPanel = function()
{
	var element;
	var content = this.panel.querySelector("#custom-list");
	var categories = LiteGraph.getNodeTypesCategories();
	for (var i in categories)
	{
		if (categories[i] !== "Macros")
		{
			element = document.createElement("div");
			element.innerHTML = "<strong>"+lang.getTranslation(categories[i])+"</strong>";
			content.appendChild(element);
			var node_types = LiteGraph.getNodeTypesInCategory(categories[i]);
			for (var j in node_types)
			{
				element = document.createElement("div");
				element["data-type"] = node_types[j].type;
				element.innerHTML = " - "+lang.getTranslation(node_types[j].title);
				element.addEventListener("click", this.bindFunction(addNode, this));
				content.appendChild(element);
			}
		}
	}
	function addNode(e)
	{
		var node = LiteGraph.createNode(e.target["data-type"]);
		node.pos = [this.insertX,this.insertY];
		this.editor.graphcanvas.graph.add(node);
		this.insertX +=20;
		this.insertY +=20;
		if (this.insertY>250) {this.insertX -=100; this.insertY -=220;}
	}
}

MyUI.prototype.processMouseWheelInfo = function (e)
{
	var delta = e.wheelDeltaY/120*50;
	if (delta>50) delta=50;
	if (delta<-50) delta=-50;
	this.panel.scrollTop -= delta;
	e.preventDefault();
	return false;
}

MyUI.prototype.bindFunction = function (func, context) { return function () { return func.apply(context, arguments)} }
MyUI.prototype.onCustomButtonClick = function() { this.panel.style.display = (this.panel.style.display === "none")?"block":"none"; }

var myui = new MyUI(editor);