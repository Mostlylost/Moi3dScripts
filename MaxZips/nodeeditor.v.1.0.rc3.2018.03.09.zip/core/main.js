//	***********************************************************************
//	Nodeedit for Moment of inspiration 1.0 rc3, Max Smirnov Copyright (C) 2018
//		based on litegraph.js library, Javi Agenjo Copyright (C) 2013
//	***********************************************************************
//
//	Permission is hereby granted, free of charge, to any person obtaining a copy
//	of this software and associated documentation files (the "Software"), to deal
//	in the Software without restriction, including without limitation the rights
//	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//	copies of the Software, and to permit persons to whom the Software is
//	furnished to do so, subject to the following conditions:
//
//	The above copyright notice and this permission notice shall be included in
//	all copies or substantial portions of the Software.
//
//	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//	THE SOFTWARE.


//       LiteGraph CLASS
/**
* The Global Scope. It contains all the registered node classes.
*
* @class LiteGraph
* @constructor
*/
var LiteGraph = {

	debug: false,

	NODE_TITLE_HEIGHT: 18,
	NODE_SLOT_HEIGHT: 15,
	NODE_WIDTH: 140,
	NODE_MIN_WIDTH: 50,
	NODE_COLLAPSED_RADIUS: 5,
	NODE_COLLAPSED_WIDTH: 80,
	CANVAS_GRID_SIZE: 20,
	NODE_TITLE_COLOR: scheme.getColor('node_title'),
	NODE_DEFAULT_COLOR: scheme.getColor('node_default'),
	NODE_DEFAULT_BGCOLOR: scheme.getColor('node_background'),
	NODE_DEFAULT_BOXCOLOR: scheme.getColor('node_box'),
	NODE_DEFAULT_SHADOW: scheme.getColor('node_shadow'),
	NODE_MACRO_COLOR: scheme.getColor('node_macro'),
	NODE_SELECTION: scheme.getColor('selection'),
	NODE_VIEWPORT_BORDER: scheme.getColor('editor_border'),
	NODE_INFO: scheme.getColor('info'),
	MENU_TEXT: scheme.getColor('menu_text'),
	MENU_BORDER: scheme.getColor('menu_border'),
	MENU_BORDER_SHADOW: scheme.getColor('menu_border_shadow'),
	MENU_BACKGROUND: scheme.getColor('menu_background'),
	EDITOR_BACKGROUND: scheme.getColor('editor_background'),
	MAX_NUMBER_OF_NODES: 1000, //avoid infinite loops
	DEFAULT_POSITION: [100,100], //default node position
	NODE_SHADOW_OFFSET: 3,
	NODE_SHADOW_BLUR: 3,
	NODE_SHADOW_OFFSET_SELECTED: moi.majorVersionNumber>3?16:6,
	NODE_SHADOW_BLUR_SELECTED: moi.majorVersionNumber>3?20:3,
	EXT_ENGINE: (moi.majorVersionNumber>3),
	TITLE_TEXT_FONT: scheme.getColor('title_text_font'),
	IO_TEXT_FONT: scheme.getColor('io_text_font'),
	node_images_path: "",
	link_type_colors:{
		'number':     scheme.getColor('link_number'),
		'numarray':   scheme.getColor('link_numarray'),
		'pointarray': scheme.getColor('link_pointarray'),
		'objectlist': scheme.getColor('link_objectlist'),
		'boolean':    scheme.getColor('link_boolean'),
		'border':     scheme.getColor('link_border'),
		'connect':    scheme.getColor('link_connect_point')
	},

	scheme_colors:{
		'node_error_box'  : scheme.getColor('node_error_box'),
		'node_error_title': scheme.getColor('node_error_title')
	},

	render_shadows: true,
	throw_errors: true,
	registered_node_types: {},
	Nodes: {},

	/**
	* Register a node class so it can be listed when the user wants to create a new one
	* @method registerNodeType
	* @param {String} type name of the node and path
	* @param {Class} base_class class containing the structure of a node
	*/

	registerNodeType: function(type, base_class)
	{
		if (!base_class.prototype) throw("Cannot register a simple object, it must be a class with a prototype");
		base_class.type = type;
		var categories = type.split("/");
		base_class.category = type.substr(0, type.lastIndexOf("/"));
		//extend class
		if ( base_class.prototype ) for (var i in LGraphNode.prototype) if (!base_class.prototype[i]) base_class.prototype[i] = LGraphNode.prototype[i];

		if (base_class.icon) if (typeof(base_class.icon) === 'string')  // convert base64 to image at first node create
		{
			base_class.iconsrc = base_class.icon;
			var tmpicon = base_class.icon;
			base_class.icon = new Image();
			base_class.icon.src = tmpicon;
		}
		this.registered_node_types[ base_class.type ] = base_class;
		
	//	if (base_class.constructor.name) this.Nodes[ base_class.constructor.name ] = base_class;
		if (LiteGraph.debug) console.log("Node registered: " + base_class.type);
	},

	/**
	* Create a node of a given type with a name. The node is not attached to any graph yet.
	* @method createNode
	* @param {String} type full name of the node class. p.e. "math/sin"
	* @param {String} name a name to distinguish from other nodes
	* @param {Object} options to set options
	*/

	createNode: function(type, title, options)
	{
		var base_class = this.registered_node_types[type];
		if (!base_class)
		{
			if (LiteGraph.debug) console.log("GraphNode type \"" + type + "\" not registered.");
			var node = new LGraphNode();
			node.init(title);
			node.type = type;
			node.internal = {};
			node.missed = true;
			node.clonable = false;
			return node;
		}

		title = title || base_class.title || type;
		var node = new base_class( title );
		node.init(title);
		node.type = type;
		if (base_class.icon) { node.icon = base_class.icon; }

		//extra options
		if (options) for(var i in options) node[i] = options[i];
		return node;
	},

	/**
	* Returns a registered node type with a given name
	* @method getNodeType
	* @param {String} type full name of the node class. p.e. "math/sin"
	* @return {Class} the node class
	*/

	getNodeType: function(type)
	{
		return this.registered_node_types[type];
	},

	/**
	* Returns a list of node types matching one category
	* @method getNodeType
	* @param {String} category category name
	* @return {Array} array with all the node classes
	*/

	getNodeTypesInCategory: function(category)
	{
		var r = [];
		for(var i in this.registered_node_types)
			if (category == "") { if (this.registered_node_types[i].category == null) r.push(this.registered_node_types[i]); }
				else { if (this.registered_node_types[i].category == category) r.push(this.registered_node_types[i]); }
		return r;
	},

	/**
	* Returns a list with all the node type categories
	* @method getNodeTypesCategories
	* @return {Array} array with all the names of the categories
	*/

	getNodeTypesCategories: function()
	{
		var categories = {"":1};
		for(var i in this.registered_node_types)
			if (this.registered_node_types[i].category && !this.registered_node_types[i].skip_list)
				categories[ this.registered_node_types[i].category ] = 1;
		var result = [];
		for(var i in categories) result.push(i);
		return result;
	},
	
	//separated just to improve if it doesnt work
	cloneObject: function(obj, target)
	{
		if (obj == null) return null;
		var r = JSON.parse( JSON.stringify( obj ) );
		if (!target) return r;

		for(var i in r) target[i] = r[i];
		return target;
	},

	setClipboard: function(clipboard)
	{
		moi.command.setOption('nodeEditorClipboard', clipboard, false);
	},

	getClipboard: function()
	{
		var data;
		try { data = moi.command.getOption('nodeEditorClipboard', false); } catch (e) {}
		return data;
	}
};

if ( typeof(performance) != "undefined" ) { LiteGraph.getTime = function getTime() { return performance.now(); }}
	else { LiteGraph.getTime = function getTime() { return Date.now(); }}
 

//*********************************************************************************
// LGraph CLASS
//*********************************************************************************

/**
* LGraph is the class that contain a full graph. We instantiate one and add nodes to it, and then we can run the execution loop.
*
* @class LGraph
* @constructor
*/

function LGraph()
{
	if (LiteGraph.debug) console.log("Graph created");
	this.list_of_graphcanvas = null;
	this.clear();
}
LGraph.prototype = { constructor: LGraph}

//default supported types
LGraph.supported_types = ["number","numarray","pointarray","objectlist","boolean"];

//used to know which types of connections support this graph (some graphs do not allow certain types)
LGraph.prototype.getSupportedTypes = function() { return this.supported_types || LGraph.supported_types; }

LGraph.STATUS_STOPPED = 1;
LGraph.STATUS_RUNNING = 2;

/**
* Removes all nodes from this graph
* @method clear
*/

LGraph.prototype.clear = function()
{
	if (this.status === LGraph.STATUS_RUNNING) this.stop();
	this.status = LGraph.STATUS_STOPPED;
	this.last_node_id = 0;

	//nodes
	this._nodes = [];
	this._nodes_by_id = {};

	//links
	this.last_link_id = 0;
	this.links = {}; //container with all the links

	//iterations
	this.iteration = 0;
	this.config = {};
	this.config.align_to_grid = true;

	//timing
	this.globaltime = 0;
	this.runningtime = 0;
	this.fixedtime =  0;
	this.fixedtime_lapse = 0.01;
	this.elapsed_time = 0.01;
	this.starttime = 0;

	//globals
	this.global_inputs = {};
	this.global_outputs = {};
	this.debug = false;
	this.sendActionToCanvas("clear");
	this.filename = "";
	this.unblockGraph();
}

/**
* Attach Canvas to this graph
* @method attachCanvas
* @param {GraphCanvas} graph_canvas
*/

LGraph.prototype.attachCanvas = function(graphcanvas)
{
	if (graphcanvas.constructor != LGraphCanvas) throw ("attachCanvas expects a LGraphCanvas instance");
	if (graphcanvas.graph && graphcanvas.graph != this) graphcanvas.graph.detachCanvas( graphcanvas );

	graphcanvas.graph = this;
	if (!this.list_of_graphcanvas) this.list_of_graphcanvas = [];
	this.list_of_graphcanvas.push(graphcanvas);
}

/**
* Detach Canvas from this graph
* @method detachCanvas
* @param {GraphCanvas} graph_canvas
*/

LGraph.prototype.detachCanvas = function(graphcanvas)
{
	var pos = this.list_of_graphcanvas.indexOf(graphcanvas);
	if (pos == -1) return;
	graphcanvas.graph = null;
	this.list_of_graphcanvas.splice(pos,1);
}

/**
* Starts running this graph every interval milliseconds.
* @method start
* @param {number} interval amount of milliseconds between executions, default is 1
*/

LGraph.prototype.start = function(interval)
{
	if (this.status == LGraph.STATUS_RUNNING) return;
	this.status = LGraph.STATUS_RUNNING;
	if (this.onPlayEvent) this.onPlayEvent();
	this.sendEventToAllNodes("onStart");

	//launch
	this.starttime = LiteGraph.getTime();
	interval = interval || 100;
	var that = this;
	this.execution_timer_id = setInterval( function() { that.runStep(); },interval );
}

/**
* Stops the execution loop of the graph
* @method stop execution
*/

LGraph.prototype.stop = function()
{
	if (this.status === LGraph.STATUS_STOPPED) return;
	this.status = LGraph.STATUS_STOPPED;
	if (this.onStopEvent) this.onStopEvent();
	if (this.execution_timer_id != null) clearInterval(this.execution_timer_id);
	this.execution_timer_id = null;
	this.sendEventToAllNodes("onStop");
}

/**
* Run N steps (cycles) of the graph
* @method runStep
* @param {number} num number of steps to run, default is 1
*/
LGraph.prototype.runStep = function()
{
	if (this.skipstep) return;
	var start = LiteGraph.getTime();
	try
	{
		this.executeAllNodes();
	//	if ( this.onExecuteStep ) this.onExecuteStep();
	//	if ( this.onAfterExecute ) this.onAfterExecute();
		this.errors_in_execution = false;
	}
	catch (err)
	{
		this.errors_in_execution = true;
		if (LiteGraph.throw_errors) throw err;
		if (LiteGraph.debug) console.log("Error during execution: " + err);
		this.stop();
	}

	var elapsed = LiteGraph.getTime() - start;
	if (elapsed === 0) elapsed = 1;
	this.elapsed_time = elapsed;
	this.iteration += 1;
}

/**
* Updates the graph execution order according to relevance of the nodes (nodes with only outputs have more relevance than
* nodes with only inputs.
* @method updateExecutionOrder
*/
	
LGraph.prototype.updateExecutionOrder = function()
{
	this._nodes_in_order = this.computeExecutionOrder(this);
}

//This is more internal, it computes the order and returns it
LGraph.prototype.computeExecutionOrder = function(thatgraph)
{
	var L = [], S = [], M = {}, missed_nodes = 0;
	var remaining_links = {}, visited_links = {};	//to avoid repeating links
	
	for (var i in this._nodes)						//search for the nodes without inputs (starting nodes)
	{
		var n = this._nodes[i];
		M[n.id] = n;								//add to pending nodes
		var num = 0;								//num of input connections
		if (n.inputs) for(var j = 0, l = n.inputs.length; j < l; j++) if (n.inputs[j] && n.inputs[j].link != null) num += 1;

		if (num == 0) S.push(n);					//is a starting node
			else remaining_links[n.id] = num;		//num of input links

		if ( n.missed ) missed_nodes++;
	}

	while(true)
	{
		if (S.length == 0) break;
		
		var n = S.shift();					//get an starting node
		L.push(n);							//add to ordered list
		delete M[n.id];						//remove from the pending nodes
		
		if (n.outputs) for(var i = 0; i < n.outputs.length; i++)									//for every output
		{
			var output = n.outputs[i];
			if (output == null || output.links == null || output.links.length == 0) continue;	//not connected
			for (var j = 0; j < output.links.length; j++)										//for every connection
			{
				var link_id = output.links[j];
				var link = this.links[link_id];
				if (!link) continue;
				if (visited_links[ link.id ]) continue;											//already visited link (ignore it)

				var target_node = this.getNodeById( link.target_id );
				if (target_node == null) { visited_links[ link.id ] = true; continue; }

				visited_links[link.id] = true;													//mark as visited
				remaining_links[target_node.id] -= 1; 											//reduce the number of links remaining
				if (remaining_links[target_node.id] == 0) S.push(target_node); 					//if no more links, then add to Starters array
			}
		}
	}
	
	for (var i in M) L.push(M[i]);			//the remaining ones (loops)
	if (L.length != this._nodes.length && LiteGraph.debug) console.log("something went wrong, nodes missing");
	for (var i in L) L[i].order = i;			//save order number in the node
	
	if (missed_nodes>0)
	{
		if (this._subgraph_node)
		{
			if (!this._subgraph_node.missed)
			{
				this._subgraph_node.missed = true;
				if (this._subgraph_node.graph) this._subgraph_node.graph.computeExecutionOrder(thatgraph || this);
			}
		}
		else
		{
			thatgraph.blockGraph();
			if ( this.status !== LGraph.STATUS_STOPPED ) editor.onPlayButton();
		}
		this.blocked = true;
	}
	else
	{
		if ( this.blocked )
		{
			if (this._subgraph_node)
			{
				if (this._subgraph_node.missed)
				{
					this._subgraph_node.missed = false;
					this._subgraph_node.graph.computeExecutionOrder(thatgraph || this);
				}
			}
			else
			{
				if (thatgraph) { thatgraph.unblockGraph() } else { this.unblockGraph() }
			}
			this.blocked = false;
		}
	}

	return L;
}

// it refreshes isChanged flag
LGraph.prototype.setisChangedFlag = function(node_id, doNotUpdateUpperLevel)
{
	var S = [], visited_links = {};		//to avoid repeating links
	
	var n = this.getNodeById(node_id);
	S.push(n);

	while(true)
	{
		if ( S.length == 0) break;
		var n = S.shift();																		// get an starting node
		n.isChanged = true;
		
		if ( n.outputs ) for ( var i = 0; i < n.outputs.length; i++ )							// for every output
		{
			var output = n.outputs[i];
			if ( output == null || output.links == null || output.links.length == 0) continue;	// not connected
			for(var j = 0; j < output.links.length; j++)										// for every connection
			{
				var link_id = output.links[j];
				var link = this.links[link_id];
				if ( !link || visited_links[link.id]) continue;									// no link or already visited link (ignore it)

				var target_node = this.getNodeById( link.target_id );
				visited_links[link.id] = true;													// mark as visited
				if ( target_node == null ) continue;
				if (target_node.isMacro) target_node.updateInput[link.target_slot] = true;
				S.push(target_node);
			}
		}
	}
	if (doNotUpdateUpperLevel) return;
	while ( n.graph._is_subgraph ) { n = n.graph._subgraph_node; n.graph.setisChangedFlag(n.id); }
}

/**
* Returns the amount of time the graph has been running in milliseconds
* @method getTime
* @return {number} number of milliseconds the graph has been running
*/

LGraph.prototype.getTime = function()
{
	return this.globaltime;
}

/**
* Returns the amount of time accumulated using the fixedtime_lapse var. This is used in context where the time increments should be constant
* @method getFixedTime
* @return {number} number of milliseconds the graph has been running
*/

LGraph.prototype.getFixedTime = function()
{
	return this.fixedtime;
}

/**
* Returns the amount of time it took to compute the latest iteration. Take into account that this number could be not correct
* if the nodes are using graphical actions
* @method getElapsedTime
* @return {number} number of milliseconds it took the last cycle
*/

LGraph.prototype.getElapsedTime = function()
{
	return this.elapsed_time;
}

/**
* Returns list of created objects
* @method getCreatedObjects
* @return {Array} ID list
*/

LGraph.prototype.getCreatedObjects = function()
{
	var list = [];
	var M = this._nodes_in_order ? this._nodes_in_order : this._nodes;
	for(var j in M)
		if (M[j]["onGetCreatedObjects"])
		{
			var clist = M[j]["onGetCreatedObjects"]();
			list.push.apply(list, clist);
		}
	return list;
}

/**
* Sends an event to all the nodes, useful to trigger stuff
* @method sendEventToAllNodes
* @param {String} eventname the name of the event (function to be called)
* @param {Array} params parameters in array format
*/

LGraph.prototype.sendEventToAllNodes = function(eventname, params)
{
	var j, jl, M = this._nodes_in_order ? this._nodes_in_order : this._nodes;
	for ( j=0, jl=M.length; j<jl; j++ )
		if (M[j][eventname])
		{
			if (params === undefined) M[j][eventname]();
			else if (params && params.constructor === Array) M[j][eventname].apply(M[j], params);
			else M[j][eventname](params);
		}
}

/**
* Sends an excute event to all the nodes
* @method executeAllNodes
* @param {Array} params parameters in array format
*/

LGraph.prototype.executeAllNodes = function(params)
{
	var n, j, jl, forcednodes=[];
	var eventname = "onExecute";
	var M = this._nodes_in_order ? this._nodes_in_order : this._nodes;
	for ( j=0, jl=M.length; j<jl; j++ )
	{
		n = M[j];
		if ( n.isChanged )
		{
			n.isChanged = false;
			if ( n.isImmortal ) forcednodes.push(n.id);
			var start = LiteGraph.getTime();
			if (n[eventname])
			{
	// DEBUG	console.log(n.type+" "+n.title)
				if (params === undefined) n[eventname]();
				else if (params && params.constructor === Array) n[eventname].apply(n, params);
				else n[eventname](params);
			}
			n.elapsed_time = LiteGraph.getTime()-start;
			// Update node data in all infopanels
			if (!this.list_of_graphcanvas) continue;
			for (var i=0, il=this.list_of_graphcanvas.length; i<il; i++)
			{
				var c = this.list_of_graphcanvas[i], nodeid = n.id;
				if (!c.infopanel_visible) continue;
				if (c.infopanel_nodes[nodeid])
				{
					var cin = c.infopanel_nodes[nodeid]["editable"];
					for (var p in cin) if (p !== 'Title' ) cin[p].value = n.properties[p];
				}
			}
		}
	}
	for (j in forcednodes) this.setisChangedFlag(forcednodes[j]);
}

LGraph.prototype.sendActionToCanvas = function(action, params)
{
	if (!this.list_of_graphcanvas) return;
	for (var i=0, il=this.list_of_graphcanvas.length; i<il; i++)
	{
		var c = this.list_of_graphcanvas[i];
		if ( c[action] ) c[action].apply(c, params);
	}
}

/**
* Adds a new node instasnce to this graph
* @method add
* @param {LGraphNode} node the instance of the node
*/

LGraph.prototype.add = function(node, skip_compute_order, skipCanvasUpdate)
{
	if (!node || (node.id != -1 && this._nodes_by_id[node.id] != null)) return; //already added
	if (this._nodes.length >= LiteGraph.MAX_NUMBER_OF_NODES) throw("LiteGraph: max number of nodes in a graph reached");

	//give him an id
	if ( node.id == null || node.id == -1 ) node.id = this.last_node_id++;
	node.graph = this;

	this._nodes.push(node);
	this._nodes_by_id[node.id] = node;

	if (node.onAdded) node.onAdded();
	if (this.config.align_to_grid) node.alignToGrid();
	if (!skip_compute_order) this.updateExecutionOrder();
	if (this.onNodeAdded) this.onNodeAdded(node);
	node.computeSize();
	if (!skipCanvasUpdate) this.setDirtyCanvas(true);
	return node;
}

/**
* Removes a nodes from the graph
* @method remove
* @param {LGraphNode} node id
* @param {selected node object}
*/

LGraph.prototype.removeNodes = function(id, selectedNodes)
{
	if (!selectedNodes[id]) { this.remove(this._nodes_by_id[id]) }
		else { for (var cid in selectedNodes) this.remove(this._nodes_by_id[cid]) }
}

/**
* Copies a nodes from the graph
* @method copy
* @param {LGraphNode} node id
* @param {selected node objects}
* @param {canvas position}
*/

LGraph.prototype.copyNodes = function(id, selectedNodes, pos, shift)
{
	var i, clipboard = { nodes:[], id:[] };
	if (!selectedNodes[id]) { clipboard.nodes.push(this._nodes_by_id[id].copyAsObject(true)) }
		else { for (var cid in selectedNodes) { clipboard.nodes.push(this._nodes_by_id[cid].copyAsObject(true)) }}
	clipboard.links = LiteGraph.cloneObject( this.links );
	var cx = pos[0]+shift[0];
	var cy = pos[1]+shift[1];

	for ( i=0; i<clipboard.nodes.length; i++ )
	{
		clipboard.nodes[i].pos[0] -= cx;
		clipboard.nodes[i].pos[1] -= cy;
		clipboard.id.push(clipboard.nodes[i].id);
		delete clipboard.nodes[i].id;
	}

	for ( i in clipboard.links ) if ( ( clipboard.id.indexOf(clipboard.links[i].origin_id) < 0 ) || ( clipboard.id.indexOf(clipboard.links[i].target_id) < 0 ) ) delete clipboard.links[i];
	return clipboard;
}

/**
* Paste a nodes to the graph
* @method paste
* @param {clipboard} clipboard object
* @param {pos} screen position
*/

LGraph.prototype.pasteNodes = function(clipboard, pos)
{
	var i, c, cl, newid = [];
	if (clipboard.nodes.length === 0) return false;
	for ( c=0, cl=this.list_of_graphcanvas.length; c<cl; c++) this.list_of_graphcanvas[c].deselectAllNodes();
	for ( i=0; i<clipboard.nodes.length; i++ )
	{
		if ( !this._is_subgraph )
			if ( clipboard.nodes[i].type === "Macros/Input" || clipboard.nodes[i].type === "Macros/Output" )
			{
				clipboard.nodes[i].type = "Macros/Blocked";
				clipboard.nodes[i].internal = {};
				if ( clipboard.nodes[i].bgcolor ) delete clipboard.nodes[i].bgcolor;
			}
		var node = LiteGraph.createNode(clipboard.nodes[i].type);
		node.configure(clipboard.nodes[i]);
		node.pos[0] += pos[0];
		node.pos[1] += pos[1];
		this.add(node);
		newid.push(node.id)
		for ( c=0, cl=this.list_of_graphcanvas.length; c<cl; c++) this.list_of_graphcanvas[c].processNodeSelected(node);
	}
	for ( i in clipboard.links ) this.getNodeById(newid[clipboard.id.indexOf(clipboard.links[i].origin_id)]).connect(clipboard.links[i].origin_slot, this.getNodeById(newid[clipboard.id.indexOf(clipboard.links[i].target_id)]), clipboard.links[i].target_slot );
}

/**
* Removes a node from the graph
* @method remove
* @param {LGraphNode} node the instance of the node
*/

LGraph.prototype.remove = function(node)
{
	if (this._nodes_by_id[node.id] == null) return; //not found
	if (node.ignore_remove) return; //cannot be removed

	//disconnect inputs
	if (node.inputs) for(var i = 0; i < node.inputs.length; i++)
	{
		var slot = node.inputs[i];
		if (slot.link != null) node.disconnectInput(i);
	}
	//disconnect outputs
	if (node.outputs) for(var i = 0; i < node.outputs.length; i++)
	{
		var slot = node.outputs[i];
		if (slot.links != null && slot.links.length) node.disconnectOutput(i);
	}
	//callback
	if (node.onRemoved) node.onRemoved();
	node.graph = null;

	//remove from canvas render
	for(var i in this.list_of_graphcanvas)
	{
		var canvas = this.list_of_graphcanvas[i];
		if ( canvas.selected_nodes[node.id] )
		{
			canvas.removeNodeInfo(node);
			delete canvas.selected_nodes[node.id];
		}
		if ( canvas.node_dragged == node ) canvas.node_dragged = null;
	}
	node.id = -1;

	//remove from containers
	var pos = this._nodes.indexOf(node);
	if (pos != -1) this._nodes.splice(pos,1);
	delete this._nodes_by_id[node.id];

	if (this.onNodeRemoved) this.onNodeRemoved(node);
	this.setDirtyCanvas(true,true);
	this.updateExecutionOrder();
}

/**
* Returns a node by its id.
* @method getNodeById
* @param {String} id
*/

LGraph.prototype.getNodeById = function(id)
{
	if (id==null) return null;
	return this._nodes_by_id[id];
}

/**
* Returns a list of nodes that matches a class
* @method findNodesByClass
* @param {Class} classObject the class itself (not an string)
* @return {Array} a list with all the nodes of this type
*/

LGraph.prototype.findNodesByClass = function(classObject)
{
	var r = [];
	for(var i in this._nodes)
		if (this._nodes[i].constructor === classObject)
			r.push(this._nodes[i]);
	return r;
}

/**
* Returns a list of nodes that matches a type
* @method findNodesByType
* @param {String} type the name of the node type
* @return {Array} a list with all the nodes of this type
*/

LGraph.prototype.findNodesByType = function(type)
{
	var type = type.toLowerCase();
	var r = [];
	for(var i in this._nodes)
		if (this._nodes[i].type.toLowerCase() == type )
			r.push(this._nodes[i]);
	return r;
}

/**
* Returns a list of nodes that matches a name
* @method findNodesByName
* @param {String} name the name of the node to search
* @return {Array} a list with all the nodes with this name
*/

LGraph.prototype.findNodesByTitle = function(title)
{
	var result = [];
	for (var i in this._nodes)
		if (this._nodes[i].title == title)
			result.push(this._nodes[i]);
	return result;
}

/**
* Returns the top-most node in this position of the canvas
* @method getNodeOnPos
* @param {number} x the x coordinate in canvas space
* @param {number} y the y coordinate in canvas space
* @param {Array} nodes_list a list with all the nodes to search from, by default is all the nodes in the graph
* @return {Array} a list with all the nodes that intersect this coordinate
*/

LGraph.prototype.getNodeOnPos = function(x,y, nodes_list)
{
	nodes_list = nodes_list || this._nodes;
	for (var i = nodes_list.length - 1; i >= 0; i--)
	{
		var n = nodes_list[i];
		if (n.isPointInsideNode( x, y, 2 ))
			return n;
	}
	return null;
}

// ********** GLOBALS *****************

//Tell this graph has a global input of this type
LGraph.prototype.addGlobalInput = function(id, name, type, thatnode, value)
{
	this.global_inputs[id] = { id: id, type: type, node: thatnode, value: value };
	if (this.onGlobalInputAdded) this.onGlobalInputAdded(id, name, type);
}

LGraph.prototype.addGlobalOutput = function(id, name, type, value)
{
	this.global_outputs[id] = { id: id, type: type, value: value };
	if (this.onGlobalOutputAdded) this.onGlobalOutputAdded(id, name, type);
	if (this.onGlobalsChange) this.onGlobalsChange();
}

//assign a data to the global input
LGraph.prototype.setGlobalInputData = function(id, data)
{
	var input = this.global_inputs[id];
	if (!this.global_inputs[id]) return;
	input.value = data;
	input.node.graph.setisChangedFlag(input.node.id);
}

//get data from global input
LGraph.prototype.getGlobalInputData = function(id)
{
	var input = this.global_inputs[id];
	if (!input) return null;
	return input.value;
}

//assign a data to the global output
LGraph.prototype.setGlobalOutputData = function(id, value)
{
	var output = this.global_outputs[id];
	if (!output) return;
	output.value = value;
}

//get data from global output
LGraph.prototype.getGlobalOutputData = function(id)
{
	var output = this.global_outputs[id];
	if (!output) return null;
	return output.value;
}

LGraph.prototype.isGlobalExists= function(id)
{
	if ( id === undefined ) return false;
	if ( id.charAt(0) === "i" ) { if ( this.global_inputs[id] === undefined ) return false; }
		else { if ( this.global_outputs[id] === undefined ) return false; }
	return true;
}

LGraph.prototype.removeGlobalInput = function(name)
{
	if (!this.global_inputs[name]) return false;
	delete this.global_inputs[name];
	if (this.onGlobalInputRemoved) this.onGlobalInputRemoved(name);

	return true;
}

LGraph.prototype.removeGlobalOutput = function(id)
{
	if (!this.global_outputs[id]) return false;
	delete this.global_outputs[id];
	if (this.onGlobalOutputRemoved) this.onGlobalOutputRemoved(name);

	return true;
}

/**
* Assigns a value to all the nodes that matches this name. This is used to create global variables of the node that
* can be easily accesed from the outside of the graph
* @method setInputData
* @param {String} name the name of the node
* @param {*} value value to assign to this node
*/

LGraph.prototype.setInputData = function(name,value)
{
	var m = this.findNodesByName(name);
	for (var i=0, il = m.length; i<il; i++) m[i].setValue(value);
}

/**
* Returns the value of the first node with this name. This is used to access global variables of the graph from the outside
* @method setInputData
* @param {String} name the name of the node
* @return {*} value of the node
*/

LGraph.prototype.getOutputData = function(name)
{
	var m = this.findNodesByName(name);
	if (m.length) return m[0].getValue();
	return null;
}

LGraph.prototype.onConnectionChange = function()
{
	this.updateExecutionOrder();
}

LGraph.prototype.setDirtyCanvas = function(fg,bg)
{
	this.sendActionToCanvas("setDirty",[fg,bg]);
}

LGraph.prototype.refreshNodeInfo = function(node)
{
	if (!this.list_of_graphcanvas) return;
	for(var i in this.list_of_graphcanvas)
	{
		var c = this.list_of_graphcanvas[i];
		c.refreshNodeInfo(node);
	}
}

//save and recover app state ***************************************
/**
* Creates a Object containing all the info about this graph, it can be serialized
* @method serialize
* @return {Object} value of the node
*/
LGraph.prototype.serialize = function()
{
	var nodes_info = [];
	var includeInputsOutputs = true;
	for (var i in this._nodes) nodes_info.push( this._nodes[i].serialize(includeInputsOutputs) );
	for (var i in this._nodes) this._nodes[i].isChanged = true;

	//remove data from links, we dont want to store it
	for (var i in this.links) this.links[i].data = null;

	var data = {
		iteration: 0,
		frame: this.frame,
		last_node_id: this.last_node_id,
		last_link_id: this.last_link_id,
		links: LiteGraph.cloneObject( this.links ),
		config: this.config,
		nodes: nodes_info
	};
	return data;
}


/**
* Configure a graph from a JSON string
* @method configure
* @param {String} str configure a graph from a JSON string
*/
LGraph.prototype.configure = function(data, keep_old, checkCompatibility)
{
	if ( !keep_old ) this.clear();

	if (checkCompatibility) data = this.checkCompatibility(data);
	var nodes = data.nodes;

	//copy all stored fields
	for (var i in data) this[i] = data[i];
	var error = false;

	//create nodes
	this._nodes = [];
	for (var i in nodes)
	{
		var n_info = nodes[i]; //stored info
		if ( !this._is_subgraph ) if ( n_info.type === "Macros/Input" || n_info.type === "Macros/Output" ) { n_info.type = "Macros/Blocked"; if ( n_info.bgcolor ) delete n_info.bgcolor;	}
		var node = LiteGraph.createNode( n_info.type, n_info.title );
		if (!node)
		{
			if (LiteGraph.debug) console.log("Node not found: " + n_info.type);
			error = true;
			continue;
		}

		node.id = n_info.id; //id it or it will create a new id
		node.configure(n_info); // << --- configure before add. 2016
		this.add(node, true, true);
	}
	this.updateExecutionOrder();
	this.setDirtyCanvas(true,true);
	this.filename ="";
	return error;
}

LGraph.prototype.blockGraph = function()
{
	if (this.blocked) return;
	for(var i in this.list_of_graphcanvas)
	{
		var c = this.list_of_graphcanvas[i];
		var ref_window = c.getCanvasWindow();
		ref_window.document.body.querySelector("#savesession_button").style.opacity = "0.2";
		ref_window.document.body.querySelector("#applyobjects_button").style.opacity = "0.2";
		ref_window.document.body.querySelector("#playnode_button").style.opacity = "0.2";
		ref_window.document.body.querySelector("#playstepnode_button").style.opacity = "0.2";
		ref_window.editor.Stop();
	}
	this.blocked = true;
}

LGraph.prototype.unblockGraph = function()
{
	this.blocked = false;
	for(var i in this.list_of_graphcanvas)
	{
		var c = this.list_of_graphcanvas[i];
		var ref_window = c.getCanvasWindow();
		ref_window.document.body.querySelector("#savesession_button").style.opacity = "1.0";
		ref_window.document.body.querySelector("#applyobjects_button").style.opacity = "1.0";
		ref_window.document.body.querySelector("#playnode_button").style.opacity = "1.0";
		ref_window.document.body.querySelector("#playstepnode_button").style.opacity = "1.0";
	}
}

LGraph.prototype.checkCompatibility = function(data)
{
	var comp = compatibilityLookupTable, n, p, newp;

	for (n in data.nodes)
	{
		data.nodes[n].type = comp.getNodeType(data.nodes[n].type);
		if (data.nodes[n].hasOwnProperty('properties')) for (p in data.nodes[n].properties)
		{
			newp = comp.getPropName(data.nodes[n].type, p);
			if ( p !== newp ) {data.nodes[n].properties[newp]=data.nodes[n].properties[p]; delete data.nodes[n].properties[p]}
			data.nodes[n].type = comp.getNodeType(data.nodes[n].type);
		}
		if (data.nodes[n].hasOwnProperty('internal')) for (p in data.nodes[n].internal)
		{
			newp = comp.getPropName(data.nodes[n].type, p);
			if ( p !== newp ) {data.nodes[n].internal[newp]=data.nodes[n].internal[p]; delete data.nodes[n].internal[p]}
			data.nodes[n].type = comp.getNodeType(data.nodes[n].type);
		}
	}
	return data;
}

LGraph.prototype.onNodeTrace = function(node, msg, color)
{
	//TODO
}

// *************************************************************
//   Node CLASS                                          *******
// *************************************************************

/*
	title: string
	pos: [x,y]
	size: [x,y]

	input|output: every connection
		+  { name:string, type:string, pos: [x,y]=Optional, direction: "input"|"output", links: Array });

	flags:
		+ skip_title_render
		+ clip_area

	supported callbacks:
		+ onAdded: when added to graph
		+ onRemoved: when removed from graph
		+ onStart:	when starts playing
		+ onStop:	when stops playing
		+ onDrawForeground: render the inside widgets inside the node
		+ onDrawBackground: render the background area inside the node (only in edit mode)
		+ onMouseDown
		+ onMouseMove
		+ onMouseUp
		+ onMouseEnter
		+ onMouseLeave
		+ onExecute: execute the node
		+ onPropertyChange: when a property is changed in the panel (return true to skip default behaviour)
		+ onGetInputs: returns an array of possible inputs
		+ onGetOutputs: returns an array of possible outputs
		+ onDblClick
		+ onSerialize
		+ onSelected
		+ onDeselected
		+ onDropFile
		+ onClear
*/

/**
* Base Class for all the node type classes
* @class LGraphNode
* @param {String} name a name for the node
*/

function LGraphNode(title)
{
//	this._ctor( title );
}

LGraphNode.prototype = { constructor: LGraphNode }

LGraphNode.prototype.init = function( title )
{
	if (!this.title) this.title = title || "Unnamed";
//	this.title = lang.getTranslation(this.title);
	if (!this.graph) this.graph = null;
	if (!this.size) this.size = this.computeSize();

	if (!this.pos) this.pos = LiteGraph.DEFAULT_POSITION.concat();
	if (!this.id) this.id = -1;
	if (!this.type) this.type = null;

	//inputs available: array of inputs
	if (!this.inputs) this.inputs = [];
	if (!this.outputs) this.outputs = [];
	if (!this.connections) this.connections = [];

	if (!this.elapsed_time) this.elapsed_time = 0;
	
	//local data
	if (!this.properties) this.properties = {};
	if (!this.data) this.data = null; //persistent local data
	if (!this.isChanged) this.isChanged = true;
	if (!this.flags) this.flags = {
	//	skip_title_render: true
	};
}

/**
* configure a node from an object containing the serialized info
* @method configure
*/
LGraphNode.prototype.configure = function(info)
{
	var importThis;
	var dynamicProperties = (this.hasOwnProperty("dynamicProperties"))?this.dynamicProperties:[];
	var dynamicInternal = (this.hasOwnProperty("dynamicInternal"))?this.dynamicInternal:[];
	var dynamicInputs = (this.hasOwnProperty("dynamicInputs"))?this.dynamicInputs:[];
	var dynamicOutputs = (this.hasOwnProperty("dynamicOutputs"))?this.dynamicOutputs:[];

	for (var j in info)
	{
		if (j === "console") continue;

		if (j === "properties")
		{
			if ( dynamicProperties.indexOf("*") < 0 )
			{
				for ( var k in dynamicProperties )
					if (this.properties.hasOwnProperty(dynamicProperties[k])) delete this.properties[dynamicProperties[k]]; // removes all dynamic properties
			} else { this.properties = [] }

			for ( var k in info.properties )
			{
				importThis = 0; // don't import
				if ( this.properties.hasOwnProperty(k) ) { importThis = 1 } // import normal property
					else if ( dynamicProperties.indexOf(k) >=0 ) { importThis = 2 } // import dynamic property
				if (importThis > 0)
				{
					if (info.properties[k].constructor === Array)
					{
					//	if (typeof(info.properties[k][0]) === 'string') { this.properties[k][0] = info.properties[k][0] }
					//		else
								this.properties[k] = info.properties[k];
					}
					else if (typeof(info.properties[k]) === 'number' && importThis === 1 && this.properties[k].constructor === Array) this.properties[k] = [info.properties[k]]
					else this.properties[k] = info.properties[k];
				}
			}
			continue;
		}

		if (j === "internal")
		{
			if ( dynamicInternal.indexOf("*") < 0 )
			{
				for ( var k in dynamicInternal )
					if (this.internal.hasOwnProperty(dynamicInternal[k])) delete this.internal[dynamicInternal[k]];
			} else { this.internal = [] }

			for ( var k in info.internal )
			{
				importThis = 0;
				if ( this.internal.hasOwnProperty(k) ) { importThis = 1 }
					else if ( dynamicInternal.indexOf(k) >=0 ) { importThis = 2 }
				if (importThis > 0)
				{
					if (info.internal[k].constructor === Array)
					{
					//	if (typeof(info.internal[k][0]) === 'string') { this.internal[k][0] = info.internal[k][0] }
					//		else
								this.internal[k] = info.internal[k];
					}
					else if (typeof(info.internal[k]) === 'number' && importThis === 1 && this.internal[k].constructor === Array) this.internal[k] = [info.internal[k]]
					else this.internal[k] = info.internal[k];
				}
			}
			continue;
		}

		if ( info[j] == null ) continue;
		else if (typeof(info[j]) === 'object') //object
		{
			if (j === 'inputs')
			{
				var ilen = (info.inputs.length<this.inputs.length)?info.inputs.length:this.inputs.length;
				for (var i=0; i<ilen; i++) if ( dynamicInputs.indexOf(i)<0 && dynamicInputs.indexOf("*")<0 )
				{
					info.inputs[i].name = this.inputs[i].name;
					info.inputs[i].type = this.inputs[i].type;
					if (info.inputs[i].hasOwnProperty("label") && !this.inputs[i].hasOwnProperty("label")) delete info.inputs[i].label;
				}
			}
			if (j === 'outputs')
			{
				var ilen = (info.outputs.length<this.outputs.length)?info.outputs.length:this.outputs.length;
				for (var i=0; i<ilen; i++) if ( dynamicOutputs.indexOf(i)<0 && dynamicOutputs.indexOf("*")<0 )
				{
					info.outputs[i].name = this.outputs[i].name;
					info.outputs[i].type = this.outputs[i].type;
					if (info.outputs[i].hasOwnProperty("label") && !this.outputs[i].hasOwnProperty("label")) delete info.outputs[i].label;
				}
			}
			if ( this[j] && this[j].configure ) this[j].configure( info[j] );
			else this[j] = LiteGraph.cloneObject(info[j], this[j]);
		}
		else this[j] = info[j]; //value
	}
	if (LiteGraph.debug) console.log("Node configured: " + this.title);
}

/**
* serialize the content
* @method serialize
*/

LGraphNode.prototype.serialize = function(includeIO)
{
	var o = {
		id: this.id,
		title: this.title,
		type: this.type,
		pos: LiteGraph.cloneObject(this.pos),
		size: LiteGraph.cloneObject(this.size),
		data: this.data,
		flags: LiteGraph.cloneObject(this.flags),
		inputs: [],
		outputs: []
	};
	if (this.inputs && includeIO) o.inputs = LiteGraph.cloneObject(this.inputs);
	if (this.outputs && includeIO) o.outputs = LiteGraph.cloneObject(this.outputs);
	if (this.properties) o.properties = LiteGraph.cloneObject(this.properties);
	if (this.internal) o.internal = LiteGraph.cloneObject(this.internal);
	if (!o.type) o.type = this.constructor.type;
	if (this.color) o.color = this.color;
	if (this.bgcolor) o.bgcolor = this.bgcolor;
	if (this.boxcolor) o.boxcolor = this.boxcolor;
	if (this.shape) o.shape = this.shape;
	if (this.onSerialize) this.onSerialize(o);
	return o;
}


/* Creates a clone of this node */
LGraphNode.prototype.clone = function()
{
	var node = LiteGraph.createNode(this.type);
	var data = this.copyAsObject();
	node.configure(data);
	return node;
}

/* Copy node */
LGraphNode.prototype.copyAsObject = function(keepID)
{
	var data = this.serialize(true);
	for (var i in data.inputs) data.inputs[i].link = null;
	for (var o in data.outputs) data.outputs[o].links = null;
	if (!keepID) delete data["id"];
	return data;
}

/**
* serialize and stringify
* @method toString
*/
LGraphNode.prototype.toString = function()
{
	return JSON.stringify( this.serialize() );
}

/**
* get the title string
* @method getTitle
*/
LGraphNode.prototype.getTitle = function()
{
	return this.title || this.constructor.title;
}

// Execution *************************
/**
* sets the output data
* @method setOutputData
* @param {number} slot
* @param {*} data
*/
LGraphNode.prototype.setOutputData = function(slot,data)
{
	if (!this.outputs) return;

	if (slot > -1 && slot < this.outputs.length && this.outputs[slot] && this.outputs[slot].links != null)
	{
		for(var i = 0; i < this.outputs[slot].links.length; i++)
		{
			var link_id = this.outputs[slot].links[i];
			this.graph.links[ link_id ].data = data;
		}
	}
}

/**
* retrieves the input data (data traveling through the connection) from one slot
* @method getInputData
* @param {number} slot
* @param {*} default data ( if slot data undefined )
* @return {*} data
*/
LGraphNode.prototype.getInputData = function(slot, dafaultdata, donotclone)
{
	if ( !this.inputs ) return dafaultdata;
	if ( slot < this.inputs.length )
	{
		if ( this.inputs[slot].link != null )
		{
			if ( this.graph.links[ this.inputs[slot].link ].data != null )
			{
				if ( this.inputs[slot].type === "pointarray" && !donotclone) { return this.graph.links[ this.inputs[slot].link ].data.clone(); }
				else if  (this.inputs[slot].type === "numarray" && !donotclone) { return this.graph.links[ this.inputs[slot].link ].data.slice(0) }
				else { return this.graph.links[ this.inputs[slot].link ].data; }
			}
			else return dafaultdata;
		}
		else
		{
			if ( typeof dafaultdata === 'undefined' )
			{
				if ( this.inputs[slot].type === "objectlist" ) { return moi.geometryDatabase.createObjectList()}
				else if (this.inputs[slot].type === "pointarray" ) { return new pointArray(true) }
				else { return [0] }
			}
		}
	}
	return dafaultdata;
}

/**
* processes the multiple data from all slots
* @method processInputData
*/
LGraphNode.prototype.processInOut = function(mode, processfunc)
{
	var modeExt = mode[mode.length-1];
	var oneobject = false, oneparray = false, sliceparrayZ = false, sliceparrayY = false;
	if (modeExt === '+') { oneobject = true; mode = mode.slice(0, -1); }
	if (modeExt === '#') { oneparray = true; mode = mode.slice(0, -1); }
	if (modeExt === 'Z') { sliceparrayZ = true; mode = mode.slice(0, -1); }
	if (modeExt === 'Y') { sliceparrayY = true; mode = mode.slice(0, -1); }


	var inp = [], outp = [], inpLength = [], inType = [], outType = [], args, lnk, t, il = this.inputs.length, ol = this.outputs.length, s, o, minl = 1e99, maxl = 0, cl, cll; // (t)ype, (l)ength, (s)lot, (o)utput
	for ( s=0; s<il; s++) // loading input types (data, lengths)
	{
		t = this.inputs[s].type;
		lnk = this.inputs[s].link;
		if ( lnk !== null ) { if ( t === "number") { inp[s] = [this.graph.links[lnk].data] } else { inp[s] = this.graph.links[lnk].data } }
		else
		{
			if (arguments[s+2] && arguments[s+2] !== null ) { inp[s] = arguments[s+2] }
			else if ( t === "pointarray" ) { inp[s] = new pointArray(true) }
			else if ( t === "number" || t === "numarray" ) { inp[s] = [1] }
			else if ( t === "objectlist" ) { inp[s] = moi.geometryDatabase.createObjectList() }
		}
		
		if ( (t === "objectlist" && oneobject) || (t === "pointarray" && oneparray) ) { inpLength[s] = 1 }
		else
		{
			if (t === "pointarray" && sliceparrayZ) { inpLength[s] = inp[s].zlength }
				else if (t === "pointarray" && sliceparrayY) { inpLength[s] = inp[s].zlength*inp[s].ylength}
					else { inpLength[s] = inp[s].length }
		}
		if (inpLength[s] < minl) minl = inpLength[s];
		if (inpLength[s] > maxl) maxl = inpLength[s];
		
		inType[s] = t;
		inpLength[s]--;  // correction
	}
	for ( s=0; s<ol; s++)  // Loading output types
	{
		outType[s] = this.outputs[s].type;
		if (outType[s] === "pointarray") { outp[s] = new pointArray(false) }
		else if (outType[s] === "objectlist") { outp[s] = moi.geometryDatabase.createObjectList()}
		else { outp[s] = [] }
	}
	
	if ( minl > 0 && il > 0)
	{
		if ( mode === "Long" )
		{
			for ( cl = 0; cl < maxl; cl++ )
			{
				args = [];
				for ( s=0; s<il; s++)
				{
					cll = ( cl > inpLength[s] )?inpLength[s]:cl;
					if (inType[s] === "pointarray" )
					{
						if (oneparray){ args.push(inp[s].clone()) }
						else if (sliceparrayZ) { args.push(inp[s].getZLayer(cll)) }
						else if (sliceparrayY) { args.push(inp[s].getYLayer(cll)) }
						else { args.push(inp[s].getElement(cll))}
					}
					else if (inType[s] === "number" || inType[s] === "numarray") { args.push(inp[s][cll]) }
					else if (inType[s] === "objectlist") if (oneobject) { args.push(inp[s]) } else { var ps = moi.geometryDatabase.createObjectList(); ps.addObject(inp[s].item(cll)); args.push(ps) }
				}
				o = processfunc.apply(this, args);
				for ( s=0; s<ol; s++)
				{
					if (outType[s] === "pointarray") { outp[s].concat(o[s]) }
					else if (outType[s] === "objectlist"){ for ( var i=0, olen = o[s].length; i <olen; i++ ) { outp[s].addObject(o[s].item(i)) }}
					else if (o[s] != null) { outp[s].push(o[s]) }
				}
			}
		}

		if ( mode === "Repeat" )
		{
			for ( cl = 0; cl < maxl; cl++ )
			{
				args = [];
				for ( s=0; s<il; s++)
				{
					cll = ( cl > inpLength[s] )?cl%(inpLength[s]+1):cl;
					if (inType[s] === "pointarray" )
					{
						if (oneparray){ args.push(inp[s].clone()) }
						else if (sliceparrayZ) { args.push(inp[s].getZLayer(cll)) }
						else if (sliceparrayY) { args.push(inp[s].getYLayer(cll)) }
						else { args.push(inp[s].getElement(cll))}
					}
					else if (inType[s] === "number" || inType[s] === "numarray") { args.push(inp[s][cll]) }
					else if (inType[s] === "objectlist") if (oneobject) { args.push(inp[s]) } else { var ps = moi.geometryDatabase.createObjectList(); ps.addObject(inp[s].item(cll)); args.push(ps) }
				}
				o = processfunc.apply(this, args);
				for ( s=0; s<ol; s++)
				{
					if (outType[s] === "pointarray") { outp[s].concat(o[s]) }
					else if (outType[s] === "objectlist"){ for ( var i=0, olen = o[s].length; i <olen; i++ ) { outp[s].addObject(o[s].item(i)) }}
					else if (o[s] != null) { outp[s].push(o[s]) }
				}
			}
		}
	
		else if ( mode === "Short" )
		{
			for ( cl = 0; cl < minl; cl++ )
			{
				args = [];
				for ( s=0; s<il; s++)
				{
					if (inType[s] === "pointarray" )
					{
						if (oneparray){ args.push(inp[s].clone()) }
						else if (sliceparrayZ) { args.push(inp[s].getZLayer(cl)) }
						else if (sliceparrayY) { args.push(inp[s].getYLayer(cl)) }
						else { args.push(inp[s].getElement(cl))}
					}
					else if (inType[s] === "number" || inType[s] === "numarray") { args.push(inp[s][cl]) }
					else if (inType[s] === "objectlist") if (oneobject) { args.push(inp[s]) } else { var ps = moi.geometryDatabase.createObjectList(); ps.addObject(inp[s].item(cl)); args.push(ps) }
				}
				o = processfunc.apply(this, args);
				for ( s=0; s<ol; s++)
				{
					if (outType[s] === "pointarray") { outp[s].concat(o[s]) }
					else if (outType[s] === "objectlist"){ for ( var i=0, olen = o[s].length; i<olen; i++ ) { outp[s].addObject(o[s].item(i)) }}
					else if (o[s] != null) { outp[s].push(o[s]) }
				}
			}
		}
	
		else if ( mode === "Cross" ) // use only with 2-input nodes
		{
			args = [];
			for ( var c0 = 0; c0 <= inpLength[0]; c0++ )
			{
				if (inType[0] === "pointarray" ) { if (oneparray){ args[0]=inp[0].clone() } else { args[0] = inp[0].getElement(c0) } }
				else if (inType[0] === "number" || inType[0] === "numarray") { args[0] = inp[0][c0] }
				else if (inType[0] === "objectlist") if (oneobject) { args[0] = inp[0] } else { args[0] = moi.geometryDatabase.createObjectList(); args[0].addObject(inp[0].item(c0)) }
				for ( var c1 = 0; c1 <= inpLength[1]; c1++ )
				{
					if (inType[1] === "pointarray" ) { if (oneparray){ args[1]=inp[1].clone() } else { args[1] = inp[1].getElement(c1) } }
					else if (inType[1] === "number" || inType[1] === "numarray") { args[1] = inp[1][c1] }
					else if (inType[1] === "objectlist") if (oneobject) { args[1] = inp[1] } else { args[1] = moi.geometryDatabase.createObjectList(); args[1].addObject(inp[1].item(c1)) }
					o = processfunc.apply(this, args);
					for ( s=0; s<ol; s++)
					{
						if (outType[s] === "pointarray") { outp[s].concat(o[s]) }
						else if (outType[s] === "objectlist"){ for ( var i=0, olen = o[s].length; i<olen; i++ ) { outp[s].addObject(o[s].item(i)) }}
						else if (o[s] != null) { outp[s].push(o[s]) }
					}
				}
			}
		}
	
		else if ( mode === "Average" )
		{
			for ( cl = 0; cl < maxl; cl++ )
			{
				args = [];
				for ( s=0; s<il; s++)
				{
					cll = (maxl === 1)?0:Math.floor((inpLength[s]+1)*cl/(maxl));
					if (inType[s] === "pointarray" )
					{
						if (oneparray){ args.push(inp[s].clone()) }
						else if (sliceparrayZ) { args.push(inp[s].getZLayer(cll)) }
						else if (sliceparrayY) { args.push(inp[s].getYLayer(cll)) }
						else { args.push(inp[s].getElement(cll))}
					}
					else if (inType[s] === "number" || inType[s] === "numarray") { args.push(inp[s][cll]) }
					else if (inType[s] === "objectlist") if (oneobject) { args.push(inp[s]) } else { var ps = moi.geometryDatabase.createObjectList(); ps.addObject(inp[s].item(cll)); args.push(ps) }
				}
				o = processfunc.apply(this, args);
				for ( s=0; s<ol; s++)
				{
					if (outType[s] === "pointarray") { outp[s].concat(o[s]) }
					else if (outType[s] === "objectlist"){ for ( var i=0, olen = o[s].length; i <olen; i++ ) { outp[s].addObject(o[s].item(i)) }}
					else if (o[s] != null) { outp[s].push(o[s]) }
				}
			}
		}
	}
	if ( il === 0)
	{
		o = processfunc.apply(this, []);
		for ( s=0; s<ol; s++)
		{
			if (outType[s] === "pointarray") { outp[s].concat(o[s]) }
			else if (outType[s] === "objectlist"){ for ( var i=0, olen = o[s].length; i<olen; i++ ) { outp[s].addObject(o[s].item(i)) }}
			else { outp[s].push(o[s]) }
		}
	}
	return { inputs:inp, outputs:outp };
}

/**
* tells you if there is a connection in one input slot
* @method isInputConnected
* @param {number} slot
* @return {boolean}
*/
LGraphNode.prototype.isInputConnected = function(slot)
{
	if (!this.inputs) return false;
	return (slot < this.inputs.length && this.inputs[slot].link != null);
}

/**
* tells you info about an input connection (which node, type, etc)
* @method getInputInfo
* @param {number} slot
* @return {Object} object or null
*/
LGraphNode.prototype.getInputInfo = function(slot)
{
	if (!this.inputs)	return null;
	if (slot < this.inputs.length) return this.inputs[slot];
	return null;
}

/**
* tells you info about an output connection (which node, type, etc)
* @method getOutputInfo
* @param {number} slot
* @return {Object}  object or null
*/
LGraphNode.prototype.getOutputInfo = function(slot)
{
	if (!this.outputs) return null;
	if (slot < this.outputs.length) return this.outputs[slot];
	return null;
}


/**
* tells you if there is a connection in one output slot
* @method isOutputConnected
* @param {number} slot
* @return {boolean}
*/
LGraphNode.prototype.isOutputConnected = function(slot)
{
	if (!this.outputs) return null;
	return (slot < this.outputs.length && this.outputs[slot].links && this.outputs[slot].links.length);
}

/**
* retrieves all the nodes connected to this output slot
* @method getOutputNodes
* @param {number} slot
* @return {array}
*/
LGraphNode.prototype.getOutputNodes = function(slot)
{
	if (!this.outputs || this.outputs.length == 0) return null;
	if (slot < this.outputs.length)
	{
		var output = this.outputs[slot];
		var r = [];
		for(var i = 0; i < output.length; i++) r.push( this.graph.getNodeById( output.links[i].target_id ));
		return r;
	}
	return null;
}

/**
* tells you if there is a connection in any output slot
* @method isOutputConnected
* @param {number} slot
* @return {boolean}
*/
LGraphNode.prototype.isOutputsConnected = function()
{
	var result = false;
	if (this.outputs)
	for(var i = 0, l = this.outputs.length; i < l; ++i)
		if (this.outputs[i].links) if (this.outputs[i].links.length > 0) { result = true; break; }
	return result;
}
// LGraphNode.prototype.triggerOutput = function(slot,param) // Smirnov //
// {
// 	var n = this.getOutputNode(slot);
// 	if (n && n.onTrigger) n.onTrigger(param);
// }

//connections

/**
* add a new output slot to use in this node
* @method addOutput
* @param {string} name
* @param {string} type string defining the output type ("vec3","number",...)
* @param {Object} extra_info this can be used to have special properties of an output (label, special color, position, etc)
*/
LGraphNode.prototype.addOutput = function(name,type,extra_info)
{
	var o = {name:name,type:type,links:null, locked:true};
//	if ( extra_info ) if ( extra_info.label ) extra_info.label = lang.getTranslation(extra_info.label);
	if (extra_info) for(var i in extra_info) o[i] = extra_info[i];

	if (!this.outputs) this.outputs = [];
	this.outputs.push(o);
	if (this.onOutputAdded) this.onOutputAdded(o);
	this.size = this.computeSize();
}

/**
* add a new output slot to use in this node
* @method addOutputs
* @param {Array} array of triplets like [[name,type,extra_info],[...]]
*/
LGraphNode.prototype.addOutputs = function(array)
{
	for(var i in array)
	{
		var info = array[i];
		var o = {name:info[0],type:info[1],link:null, locked:true};
		if (array[2]) for(var j in info[2]) o[j] = info[2][j];

		if (!this.outputs) this.outputs = [];
		this.outputs.push(o);
		if (this.onOutputAdded) this.onOutputAdded(o);
	}
	this.size = this.computeSize();
}

/**
* remove an existing output slot
* @method removeOutput
* @param {number} slot
*/
LGraphNode.prototype.removeOutput = function(slot, name)
{
	this.disconnectOutput(slot);
	this.outputs.splice(slot,1);
	var links = this.graph.links;
	for ( var l in links ) { if ( links[l].origin_id === this.id ) if ( links[l].origin_slot > slot ) links[l].origin_slot-- }
	this.size = this.computeSize();
	if (this.onOutputRemoved) this.onOutputRemoved(slot, name);
}

/**
* change an existing output slot type
* @method changeOutputType
* @param {number} slot
*/
LGraphNode.prototype.changeOutputType = function(slot, type, name)
{
	this.disconnectOutput(slot);
	this.outputs[slot].type = type;
	this.outputs[slot].name = name || this.outputs[slot].name;
	this.size = this.computeSize();
}

/**
* add a new input slot to use in this node
* @method addInput
* @param {string} name
* @param {string} type string defining the input type ("vec3","number",...), it its a generic one use 0
* @param {Object} extra_info this can be used to have special properties of an input (label, color, position, etc)
*/
LGraphNode.prototype.addInput = function(name,type,extra_info)
{
	type = type || 0;
	var o = {name:name,type:type,link:null, locked:true};
//	if ( extra_info ) if ( extra_info.label ) extra_info.label = lang.getTranslation(extra_info.label);
	if ( extra_info ) for(var i in extra_info) o[i] = extra_info[i];

	if (!this.inputs)	this.inputs = [];
	this.inputs.push(o);
	this.size = this.computeSize();
	if (this.onInputAdded) this.onInputAdded(o);
	
	if (!this.graph) return;
	this.graph.refreshNodeInfo(this.id);
}

/**
* add several new input slots in this node
* @method addInputs
* @param {Array} array of triplets like [[name,type,extra_info],[...]]
*/
LGraphNode.prototype.addInputs = function(array)
{
	for(var i in array)
	{
		var info = array[i];
		var o = {name:info[0], type:info[1], link:null, locked:true};
		if (array[2]) for(var j in info[2]) o[j] = info[2][j];

		if (!this.inputs) this.inputs = [];
		this.inputs.push(o);
		if (this.onInputAdded) this.onInputAdded(o);
	}
	this.size = this.computeSize();
}

/**
* remove an existing input slot
* @method removeInput
* @param {number} slot
*/
LGraphNode.prototype.removeInput = function(slot, name)
{
	this.disconnectInput(slot);
	this.inputs.splice(slot,1);
	var links = this.graph.links;
	for ( var l in links ) { if ( links[l].target_id === this.id ) if ( links[l].target_slot > slot ) links[l].target_slot-- }
	this.size = this.computeSize();
	if (this.onInputRemoved) this.onInputRemoved(slot, name);
	if (!this.graph) return;
	this.graph.refreshNodeInfo(this.id);
}

/**
* change an existing input slot type
* @method changeInputType
* @param {number} slot
*/
LGraphNode.prototype.changeInputType = function(slot, type, name)
{
	this.disconnectInput(slot);
	this.inputs[slot].type = type;
	this.inputs[slot].name = name || this.inputs[slot].name;
	this.size = this.computeSize();
	if (!this.graph) return;
	this.graph.refreshNodeInfo(this.id);
}

/**
* add an special connection to this node (used for special kinds of graphs)
* @method addConnection
* @param {string} name
* @param {string} type string defining the input type ("vec3","number",...)
* @param {[x,y]} pos position of the connection inside the node
* @param {string} direction if is input or output
*/
LGraphNode.prototype.addConnection = function(name,type,pos,direction)
{
	this.connections.push({name:name, type:type, pos:pos, direction:direction, links:null });
}

/**
* computes the size of a node according to its inputs and output slots
* @method computeSize
* @return {number} the total size
*/
LGraphNode.prototype.computeSize = function()
{
	if ( !this.title ) return;		// skip thin step on first init
	
	var c = editor.graphcanvas;
	var ctx = c.bgcanvas.getContext("2d");
	
	var rows = Math.max( this.inputs ? this.inputs.length : 1, this.outputs ? this.outputs.length : 1);
	var size = (this.size)?this.size:[0,0];
	rows = Math.max(rows, 1);
	size[0] = (this.minsize)?this.minsize[0]:0;
	size[1] = (this.minsize)?this.minsize[1]:0;

	ctx.font = c.title_text_font;
	var title_width = ctx.measureText(lang.getTranslation(this.title)).width+LiteGraph.NODE_TITLE_HEIGHT+5;
	var input_width = 0;
	var output_width = 0;

	ctx.font = c.inner_text_font;
	if (this.inputs)
		for(var i = 0, l = this.inputs.length; i < l; ++i)
		{
			var input = this.inputs[i];
			var text = input.label || input.name || "";
			var text_width = ctx.measureText(lang.getTranslation(text)).width;
			if ( input_width < text_width ) input_width = text_width;
		}

	if (this.outputs)
		for(var i = 0, l = this.outputs.length; i < l; ++i)
		{
			var output = this.outputs[i];
			var text = output.label || output.name || "";
			var text_width = ctx.measureText(lang.getTranslation(text)).width;
			if (output_width < text_width) output_width = text_width;
		}
	var newWidth = (input_width > 0 && output_width > 0)?input_width + output_width + 30:input_width + output_width+20;	
	size[0] = Math.max( size[0], Math.max( newWidth, title_width ));
	size[1] = Math.max( size[1], rows * 15 + 5);
	size[2] = title_width;
	
	return size;
}

/**
* returns the bounding of the object, used for rendering purposes
* @method getBounding
* @return {Float32Array[4]} the total size
*/
LGraphNode.prototype.getBounding = function()
{
	return [this.pos[0] - 4, this.pos[1] - LiteGraph.NODE_TITLE_HEIGHT, this.pos[0] + this.size[0] + 4, this.pos[1] + this.size[1] + LGraph.NODE_TITLE_HEIGHT];
}

/**
* checks if a point is inside the shape of a node
* @method isPointInsideNode
* @param {number} x
* @param {number} y
* @return {boolean}
*/
LGraphNode.prototype.isPointInsideNode = function(x,y, margin)
{
	margin = margin || 0;

	var margin_top = LiteGraph.NODE_TITLE_HEIGHT;
	if (this.flags.collapsed)
	{
		if ( isInsideRectangle( x, y, this.pos[0] - margin, this.pos[1] - LiteGraph.NODE_TITLE_HEIGHT - margin, this.size[2] + 2 * margin, LiteGraph.NODE_TITLE_HEIGHT + 2 * margin ) )	return true;
	}
	else if ( (this.pos[0] - 4 - margin) < x && (this.pos[0] + this.size[0] + 4 + margin) > x	&& (this.pos[1] - margin_top - margin) < y && (this.pos[1] + this.size[1] + margin) > y) return true;
	return false;
}

/**
* checks if a node is inside the rectangle
* @method isNodeInsideRectangle
* @param {number} x1
* @param {number} y1
* @param {number} x2
* @param {number} y2
* @return {boolean}
*/
LGraphNode.prototype.isNodeInsideRectangle = function(x1,y1,x2,y2)
{
	var buf;
	if ( x1>x2 ) { buf=x1; x1=x2; x2=buf; }
	if ( y1>y2 ) { buf=y1; y1=y2; y2=buf; }
	
	if (this.flags.collapsed) { if (x1<this.pos[0] && y1<this.pos[1]-LiteGraph.NODE_TITLE_HEIGHT && x2>this.pos[0]+this.size[0] && y2>this.pos[1]) return true; }
	else if (x1<this.pos[0] && y1<this.pos[1]-LiteGraph.NODE_TITLE_HEIGHT && x2>this.pos[0]+this.size[0] && y2>this.pos[1]+this.size[1]) return true; 
	return false;
}

/**
* checks if a point is inside a node slot, and returns info about which slot
* @method getSlotInPosition
* @param {number} x
* @param {number} y
* @return {Object} if found the object contains { input|output: slot object, slot: number, link_pos: [x,y] }
*/
LGraphNode.prototype.getSlotInPosition = function( x, y )
{
	//search for inputs
	if (this.inputs)
		for(var i = 0, l = this.inputs.length; i < l; ++i)
		{
			var input = this.inputs[i];
			var link_pos = this.getConnectionPos( true,i );
			if ( isInsideRectangle(x, y, link_pos[0] - 10, link_pos[1] - 8, 20,16) ) return { input: input, slot: i, link_pos: link_pos, locked: input.locked };
		}

	if (this.outputs)
		for(var i = 0, l = this.outputs.length; i < l; ++i)
		{
			var output = this.outputs[i];
			var link_pos = this.getConnectionPos(false,i);
			if ( isInsideRectangle(x, y, link_pos[0] - 10, link_pos[1] - 8, 20,16) ) return { output: output, slot: i, link_pos: link_pos, locked: output.locked };
		}

	return null;
}

/**
* returns the input slot with a given name (used for dynamic slots), -1 if not found
* @method findInputSlot
* @param {string} name the name of the slot
* @return {number} the slot (-1 if not found)
*/
LGraphNode.prototype.findInputSlot = function(name)
{
	if (!this.inputs) return -1;
	for(var i = 0, l = this.inputs.length; i < l; ++i)	if (name == this.inputs[i].name) return i;
	return -1;
}

/**
* returns the output slot with a given name (used for dynamic slots), -1 if not found
* @method findOutputSlot
* @param {string} name the name of the slot
* @return {number} the slot (-1 if not found)
*/
LGraphNode.prototype.findOutputSlot = function(name)
{
	if (!this.outputs) return -1;
	for(var i = 0, l = this.outputs.length; i < l; ++i) if (name == this.outputs[i].name) return i;
	return -1;
}

/**
* connect this node output to the input of another node
* @method connect
* @param {number_or_string} slot (could be the number of the slot or the string with the name of the slot)
* @param {LGraphNode} node the target node
* @param {number_or_string} target_slot the input slot of the target node (could be the number of the slot or the string with the name of the slot)
* @return {boolean} if it was connected succesfully
*/
LGraphNode.prototype.connect = function(slot, node, target_slot)
{
	target_slot = target_slot || 0;

	//seek for the output slot
	if ( slot.constructor === String )
	{
		slot = this.findOutputSlot(slot);
		if (slot === -1) { if (LiteGraph.debug) console.log("Connect: Error, no slot of name " + slot); return false; }
	}	else if (!this.outputs || slot >= this.outputs.length) { if (LiteGraph.debug) console.log("Connect: Error, slot number not found"); return false; }

	//avoid loopback
	if (node == this) return false;
	//if ( node.constructor != LGraphNode ) throw ("LGraphNode.connect: node is not of type LGraphNode");
	

	if (target_slot.constructor === String)
	{
		target_slot = node.findInputSlot(target_slot);
		if (target_slot === -1) { if (LiteGraph.debug) console.log("Connect: Error, no slot of name " + target_slot); return false; }
	}	else if (!node.inputs || target_slot >= node.inputs.length) { if (LiteGraph.debug) console.log("Connect: Error, slot number not found"); return false; }

	//if there is something already plugged there, disconnect
	if (target_slot !== -1 && node.inputs[target_slot].link != null) if (this.outputs[slot].type === node.inputs[target_slot].type) node.disconnectInput(target_slot);
		
	//special case: -1 means node-connection, used for triggers
	var output = this.outputs[slot];
	if (target_slot === -1)
	{
		if ( output.links == null ) output.links = [];
		output.links.push({id:node.id, slot: -1});
	}
	else if ( !output.type ||  //generic output
			!node.inputs[target_slot].type || //generic input
			output.type.toLowerCase() == node.inputs[target_slot].type.toLowerCase() ) //same type
	{
		if ( this.outputs[slot].type === "objectlist" ) this.disconnectOutput(slot);
		var link = { id: this.graph.last_link_id++, origin_id: this.id, origin_slot: slot, target_id: node.id, target_slot: target_slot };
		this.graph.links[ link.id ] = link;

		//connect
		if ( output.links == null )	output.links = [];
		output.links.push( link.id );
		node.inputs[target_slot].link = link.id;

		this.graph.setisChangedFlag(this.id);
		this.setDirtyCanvas(false,true);
		this.graph.onConnectionChange();
	}
	return true;
}

/**
* disconnect one output to an specific node
* @method disconnectOutput
* @param {number_or_string} slot (could be the number of the slot or the string with the name of the slot)
* @param {LGraphNode} target_node the target node to which this slot is connected [Optional, if not target_node is specified all nodes will be disconnected]
* @return {boolean} if it was disconnected succesfully
*/
LGraphNode.prototype.disconnectOutput = function(slot, target_node)
{
	if ( slot.constructor === String )
	{
		slot = this.findOutputSlot(slot);
		if (slot === -1) { if (LiteGraph.debug) console.log("Connect: Error, no slot of name " + slot); return false; }
	}	else if (!this.outputs || slot >= this.outputs.length) { if (LiteGraph.debug) console.log("Connect: Error, slot number not found"); return false; }

	//get output slot
	var output = this.outputs[slot];
	if (!output.links || output.links.length == 0) return false;

	if (target_node)
	{
		for(var i = 0, l = output.links.length; i < l; i++)
		{
			var link_id = output.links[i];
			var link_info = this.graph.links[ link_id ];

			//is the link we are searching for...
			if ( link_info.target_id == target_node.id )
			{
				output.links.splice(i,1); //remove here
				target_node.inputs[ link_info.target_slot ].link = null; //remove there
				delete this.graph.links[ link_id ]; //remove the link from the links pool
				break;
			}
		}
	}
	else
	{
		for(var i = 0, l = output.links.length; i < l; i++)
		{
			var link_id = output.links[i];
			var link_info = this.graph.links[ link_id ];

			var target_node = this.graph.getNodeById( link_info.target_id );
			if (target_node)
				target_node.inputs[ link_info.target_slot ].link = null; //remove other side link
			delete this.graph.links[ link_id ]; //remove the link from the links pool
		}
		output.links = null;
	}

	this.graph.setisChangedFlag(target_node.id);

	this.setDirtyCanvas(false,true);
	this.graph.onConnectionChange();
	return true;
}

/**
* disconnect one input
* @method disconnectInput
* @param {number_or_string} slot (could be the number of the slot or the string with the name of the slot)
* @return {boolean} if it was disconnected succesfully
*/
LGraphNode.prototype.disconnectInput = function(slot)
{
	this.graph.setisChangedFlag(this.id);
	//seek for the output slot
	if ( slot.constructor === String )
	{
		slot = this.findInputSlot(slot);
		if (slot === -1)
		{
			if (LiteGraph.debug)
				console.log("Connect: Error, no slot of name " + slot);
			return false;
		}
	}
	else if (!this.inputs || slot >= this.inputs.length) 
	{
		if (LiteGraph.debug)
			console.log("Connect: Error, slot number not found");
		return false;
	}

	var input = this.inputs[slot];
	if (!input) return false;
	
	var link_id = this.inputs[slot].link;
	this.inputs[slot].link = null;

	//remove other side
	var link_info = this.graph.links[ link_id ];
	if ( link_info )
	{
		var node = this.graph.getNodeById( link_info.origin_id );
		if (!node) return false;

		var output = node.outputs[ link_info.origin_slot ];
		if (!output || !output.links || output.links.length == 0) 	return false;

		//check outputs
		for(var i = 0, l = output.links.length; i < l; i++)
		{
			var link_id = output.links[i];
			var link_info = this.graph.links[ link_id ];
			if ( link_info.target_id == this.id && link_info.target_slot == slot )
			{
				output.links.splice(i,1);
				break;
			}
		}
		delete this.graph.links[ link_id ]; //remove the link from the links pool
	}
	
	this.setDirtyCanvas(false,true);
	this.graph.onConnectionChange();
	return true;
}

/**
* returns the center of a connection point in canvas coords
* @method getConnectionPos
* @param {boolean} is_input true if if a input slot, false if it is an output
* @param {number_or_string} slot (could be the number of the slot or the string with the name of the slot)
* @return {[x,y]} the position
**/
LGraphNode.prototype.getConnectionPos = function(is_input, slot_number)
{
	if (this.flags.collapsed)
	{
		if (is_input)
			return [this.pos[0], this.pos[1] - LiteGraph.NODE_TITLE_HEIGHT * 0.5];
		else
			return [this.pos[0] + this.size[2], this.pos[1] - LiteGraph.NODE_TITLE_HEIGHT * 0.5];
	}

	if (is_input && slot_number === -1)
	{
		return [this.pos[0] + 10, this.pos[1] + 10];
	}

	if (is_input && this.inputs.length > slot_number && this.inputs[slot_number].pos)
		return [this.pos[0] + this.inputs[slot_number].pos[0],this.pos[1] + this.inputs[slot_number].pos[1]];
	else if (!is_input && this.outputs.length > slot_number && this.outputs[slot_number].pos)
		return [this.pos[0] + this.outputs[slot_number].pos[0],this.pos[1] + this.outputs[slot_number].pos[1]];

	if (!is_input) //output
		return [this.pos[0] + this.size[0] + 1, this.pos[1] + 10 + slot_number * LiteGraph.NODE_SLOT_HEIGHT];
	return [this.pos[0] , this.pos[1] + 10 + slot_number * LiteGraph.NODE_SLOT_HEIGHT];
}

/* Force align to grid */
LGraphNode.prototype.alignToGrid = function(checkPos)
{
	this.pos[0] = LiteGraph.CANVAS_GRID_SIZE * Math.round(this.pos[0] / LiteGraph.CANVAS_GRID_SIZE)+1;
	this.pos[1] = LiteGraph.CANVAS_GRID_SIZE * Math.round((this.pos[1]-LiteGraph.NODE_TITLE_HEIGHT) / LiteGraph.CANVAS_GRID_SIZE)+LiteGraph.NODE_TITLE_HEIGHT+1;
	if ( !checkPos || !this.graph ) return;
	var posChanged = true;
	while (posChanged)
	{
		posChanged = false;
		for (var i in this.graph._nodes)
		{
			var n = this.graph._nodes[i];
			if ( this.id !== n.id && this.pos[0] === n.pos[0] && this.pos[1] === n.pos[1] )
			{
				this.pos[0] += LiteGraph.CANVAS_GRID_SIZE;
				this.pos[1] += LiteGraph.CANVAS_GRID_SIZE;
				posChanged = true;
				break;
			}
		}
	}
}

/* Console output */
LGraphNode.prototype.trace = function(msg)
{
	if (!this.console) this.console = [];
	this.console.push(msg);
	if (this.console.length > LGraphNode.MAX_CONSOLE) this.console.shift();
	this.graph.onNodeTrace(this,msg);
}

/* Forces to redraw or the main canvas (LGraphNode) or the bg canvas (links) */
LGraphNode.prototype.setDirtyCanvas = function(dirty_foreground, dirty_background)
{
	if (!this.graph) return;
	this.graph.sendActionToCanvas("setDirty",[dirty_foreground, dirty_background]);
}

LGraphNode.prototype.loadImage = function(url)
{
	var img = new Image();
	img.src = LiteGraph.node_images_path + url;
	img.ready = false;

	var that = this;
	img.onload = function() { this.ready = true; that.setDirtyCanvas(true); }
	return img;
}

/* Updates node graph without background updating */
LGraphNode.prototype.updateThisNodeGraph = function()
{
	if (!this.graph || !this.graph.list_of_graphcanvas)	return;
	var list = this.graph.list_of_graphcanvas, canvas;
	if (this.onDrawForeground) for(var i in list)
	{
		canvas = list[i];
		if ( canvas.ctx )
		{
			canvas.ctx.save();
			canvas.ctx.scale(canvas.scale,canvas.scale);
			canvas.ctx.translate(canvas.offset[0],canvas.offset[1]);
			canvas.ctx.translate( this.pos[0], this.pos[1] );
			this.onDrawForeground(canvas.ctx);
			canvas.ctx.restore();
		}
	}
}

/* Allows to get onMouseMove and onMouseUp events even if the mouse is out of focus */
LGraphNode.prototype.captureInput = function(v)
{
	if (!this.graph || !this.graph.list_of_graphcanvas)	return;

	var list = this.graph.list_of_graphcanvas;

	for(var i in list)
	{
		var c = list[i];
		if (!v && c.node_capturing_input != this) continue;	//releasing somebody elses capture?!
		c.node_capturing_input = v ? this : null;			//change
	}
}

/**
* Collapse the node to make it smaller on the canvas
* @method collapse
**/
LGraphNode.prototype.collapse = function()
{
	if (!this.flags.collapsed) this.flags.collapsed = true;
	else this.flags.collapsed = false;
	this.setDirtyCanvas(true,true);
}

/**
* return this node input number by global id
* @method connect
* @param {string} Global input id
*/
LGraphNode.prototype.getGlobalInput = function(id)
{
	for ( var i in this.inputs )
	{
		if ( this.inputs[i].hasOwnProperty("globalid") )
			if ( this.inputs[i].globalid === id ) return i*1;
	}
	return null;
}

/**
* return this node input number by global id
* @method connect
* @param {string} Global input id
*/
LGraphNode.prototype.getGlobalOutput = function(id)
{
	for ( var o in this.outputs )
	{
		if ( this.outputs[o].hasOwnProperty("globalid") )
			if ( this.outputs[o].globalid === id ) return o*1;
	}
	return null;
}


/**
* Forces the node to do not move or realign on Z
* @method pin
**/

LGraphNode.prototype.pin = function(v)
{
	if (v === undefined) { this.flags.pinned = !this.flags.pinned } else { this.flags.pinned = v }
}

LGraphNode.prototype.localToScreen = function(x,y, graphcanvas)
{
	return [(x + this.pos[0]) * graphcanvas.scale + graphcanvas.offset[0], (y + this.pos[1]) * graphcanvas.scale + graphcanvas.offset[1]];
}



//*********************************************************************************
// LGraphCanvas: LGraph renderer CLASS
//*********************************************************************************

/**
* The Global Scope. It contains all the registered node classes.
*
* @class LGraphCanvas
* @constructor
* @param {HTMLCanvas} canvas the canvas where you want to render (it accepts a selector in string format or the canvas itself)
* @param {LGraph} graph [optional]
*/
function LGraphCanvas(canvas, graph, uiRatio, pixelRatio, skip_render)
{
//	if (graph === undefined)	throw ("No graph assigned");

	if (canvas && canvas.constructor === String) canvas = document.querySelector(canvas);

	this.uiRatio = uiRatio || 1;
	this.pixelRatio = pixelRatio || 1;
	this.max_zoom = 2.484 * this.uiRatio * this.pixelRatio;
	this.min_zoom = 0.279 * this.uiRatio * this.pixelRatio;

	//link canvas and graph
	if (graph) graph.attachCanvas(this);

	this.setCanvas(canvas);
	this.clear();
	if (!skip_render) this.startRendering();
}

LGraphCanvas.prototype = { constructor: LGraphCanvas }

LGraphCanvas.link_type_colors = LiteGraph.link_type_colors;
/**
* clears all the data inside
*
* @method clear
*/
LGraphCanvas.prototype.clear = function()
{
	if (this.selected_nodes) this.deselectAllNodes();
	this.frame = 0;
	this.last_draw_time = 0;
	this.render_time = 0;
	this.fps = 0;

	this.scale = 1 * this.uiRatio * this.pixelRatio;
	this.offset = [0, 0];

	this.selected_nodes = {};
	this.infopanel_nodes = {};
	
	this.node_dragged = null;
	this.node_over = null;
	this.node_capturing_input = null;
	this.connecting_node = null;

	this.highquality_render = true;
	this.editor_alpha = 1;
	this.editor_zoomalpha = 1;
	this.editor_zoomalpha_title = 1; //used for transition
	this.pause_rendering = false;
	this.render_shadows = true;
	this.clear_background = true;

	this.render_only_selected = true;
	this.show_info = false;
	this.io_info = false;

	this.allow_dragcanvas = true;
	this.allow_dragnodes = true;

	this.dirty_canvas = true;
	this.dirty_bgcanvas = true;
	this.dirty_area = null;

	this.node_in_panel = null;

	this.last_mouse = [0, 0];
	this.last_mouseclick = 0;
	this.selection = null;

	this.title_text_font = LiteGraph.scaleCssFont(LiteGraph.TITLE_TEXT_FONT, this.uiRatio);
	this.inner_text_font = LiteGraph.scaleCssFont(LiteGraph.IO_TEXT_FONT, this.uiRatio);

	this.render_connections_shadows = false; //too much cpu
	this.render_connections_border = true;
	this.render_curved_connections = true;
	this.render_connection_arrows = true;

	this.connections_width = 3;

	if (this.onClear) this.onClear();
}

/**
* assigns a graph, you can reasign graphs to the same canvas
*
* @method setGraph
* @param {LGraph} graph
*/
LGraphCanvas.prototype.setGraph = function( graph, skip_clear )
{
	if (this.graph == graph) return;
	if (!skip_clear) this.clear();
	if (!graph && this.graph) { this.graph.detachCanvas(this); return; }

	/*
	if (this.graph) this.graph.canvas = null; //remove old graph link to the canvas
	this.graph = graph;
	if (this.graph) this.graph.canvas = this;
	*/

	graph.attachCanvas(this);
	this.setDirty(true,true);
}

/**
* opens a graph contained inside a node in the current graph
*
* @method openSubgraph
* @param {LGraph} graph
*/
LGraphCanvas.prototype.openSubgraph = function(graph)
{
	if (!graph) throw("graph cannot be null");
	if (this.graph == graph) throw("graph cannot be the same");
	this.clear();

	if (this.graph)
	{
		if (!this._graph_stack) this._graph_stack = [];
		this._graph_stack.push(this.graph);
	}

	var ref_window = this.getCanvasWindow();
	ref_window.document.body.querySelector("#newsession_button").style.display = "none";
	ref_window.document.body.querySelector("#loadsession_button").style.display = "none";
	ref_window.document.body.querySelector("#savesession_button").style.display = "none";
	ref_window.document.body.querySelector("#applyobjects_button").style.display = "none";
	ref_window.document.body.querySelector("#back_button").style.display = "inline-block";

	graph.attachCanvas(this);
	this.setDirty(true,true);
}

/**
* closes a subgraph contained inside a node
*
* @method closeSubgraph
* @param {LGraph} assigns a graph
*/
LGraphCanvas.prototype.closeSubgraph = function()
{
	if (this.selected_nodes) this.deselectAllNodes();
	if (!this._graph_stack || this._graph_stack.length == 0) return;
	var graph = this._graph_stack.pop();
	graph.attachCanvas(this);

	if ( !this.graph._is_subgraph )
	{
		var ref_window = this.getCanvasWindow();
		ref_window.document.body.querySelector("#newsession_button").style.display = "inline-block";
		ref_window.document.body.querySelector("#loadsession_button").style.display = "inline-block";
		ref_window.document.body.querySelector("#savesession_button").style.display = "inline-block";
		ref_window.document.body.querySelector("#applyobjects_button").style.display = "inline-block";
		ref_window.document.body.querySelector("#back_button").style.display = "none";
	}

	this.setDirty(true,true);
}

/**
* assigns a canvas
*
* @method setCanvas
* @param {Canvas} assigns a canvas
*/
LGraphCanvas.prototype.setCanvas = function( canvas, skip_events )
{
	var that = this;

	if (canvas) if ( canvas.constructor === String )
	{
		canvas = document.getElementById(canvas);
		if (!canvas) throw("Error creating LiteGraph canvas: Canvas not found");
	}

	if (canvas === this.canvas) return;
	if (!canvas && this.canvas) { if (!skip_events) this.unbindEvents(); } //maybe detach events from old_canvas
	this.canvas = canvas;
	if (!canvas) return;

	//this.canvas.tabindex = "1000";
	canvas.className += " lgraphcanvas";
	canvas.data = this;

	//bg canvas: used for non changing stuff
	this.bgcanvas = null;
	if (!this.bgcanvas)
	{
		this.bgcanvas = document.createElement("canvas");
		this.bgcanvas.width = this.canvas.width;
		this.bgcanvas.height = this.canvas.height;
	}

	if (canvas.getContext == null) { throw("This browser doesnt support Canvas"); }

	var ctx = this.ctx = canvas.getContext("2d");
	if (ctx == null)
	{
		console.warn("This canvas seems to be WebGL, enabling WebGL renderer");
		this.enableWebGL();
	}

	//input:  (move and up could be unbinded)
	this._mousemove_callback = this.bindFunction(this.processMouseMove, this);
	this._mouseup_callback = this.bindFunction(this.processMouseUp, this);

	if (!skip_events) this.bindEvents();
}

//used in some events to capture them
LGraphCanvas.prototype._doNothing = function doNothing() { return false; };

LGraphCanvas.prototype.bindFunction = function(func, context) { return function() { return func.apply(context, arguments); };}

LGraphCanvas.prototype.bindEvents = function()
{
	if (this._events_binded) { console.warn("LGraphCanvas: events already binded"); return; }

	var canvas = this.canvas;
	this._mousedown_callback = this.bindFunction(this.processMouseDown, this);
	this._mousewheel_callback = this.bindFunction(this.processMouseWheel, this);
	this._trackpadgesture_callback = this.bindFunction(this.trackpadgestureHandler, this);

	canvas.addEventListener("mousedown", this._mousedown_callback, true ); //down do not need to store the binded
	canvas.addEventListener("mousemove", this._mousemove_callback );
	canvas.addEventListener("mousewheel", this._mousewheel_callback, false);

	canvas.addEventListener("contextmenu", this._doNothing );
	canvas.addEventListener("DOMMouseScroll", this._mousewheel_callback, false);

	canvas.addEventListener("trackpadgesture", this._trackpadgesture_callback, true);

	//touch events
	// this._touchpad_callback = this.bindFunction(this.touchHandler, this);
	//if ( 'touchstart' in document.documentElement ) {
	//if (!LiteGraph.EXT_ENGINE)
	// {
	// 	canvas.addEventListener("touchstart", this._touchpad_callback, true);
	// 	canvas.addEventListener("touchmove", this._touchpad_callback, true);
	// 	canvas.addEventListener("touchend", this._touchpad_callback, true);
	// 	canvas.addEventListener("touchcancel", this._touchpad_callback, true);
	// }
	//}

	//Keyboard ******************

	this._key_callback = this.bindFunction(this.processKey, this);
	canvas.addEventListener("keydown", this._key_callback );
	canvas.addEventListener("keyup", this._key_callback );

	//Droping Stuff over nodes ************************************
	this._ondrop_callback = this.bindFunction(this.processDrop, this);

	canvas.addEventListener("dragover", this._doNothing, false );
	canvas.addEventListener("dragend", this._doNothing, false );
	canvas.addEventListener("drop", this._ondrop_callback, false );

	this._events_binded = true;
}

LGraphCanvas.prototype.unbindEvents = function()
{
	if (	!this._events_binded ) { console.warn("LGraphCanvas: no events binded"); return; }

	this.canvas.removeEventListener( "mousedown", this._mousedown_callback );
	this.canvas.removeEventListener( "mousewheel", this._mousewheel_callback );

	this.canvas.removeEventListener( "contextmenu", this._doNothing );
	this.canvas.removeEventListener( "DOMMouseScroll", this._mousewheel_callback );

	this.canvas.removeEventListener( "trackpadgesture", this._mousewheel_callback );
	
	this.canvas.removeEventListener( "keydown", this._key_callback );
	this.canvas.removeEventListener( "keyup", this._key_callback );
	
	this.canvas.removeEventListener( "drop", this._ondrop_callback );

	// if (!LiteGraph.EXT_ENGINE)
	// {
	// 	this.canvas.removeEventListener("touchstart", this.touchHandler );
	// 	this.canvas.removeEventListener("touchmove", this.touchHandler );
	// 	this.canvas.removeEventListener("touchend", this.touchHandler );
	// 	this.canvas.removeEventListener("touchcancel", this.touchHandler );
	// }

	this._mousedown_callback = null;
	this._mousewheel_callback = null;
	this._key_callback = null;
	this._ondrop_callback = null;

	this._events_binded = false;
}

// this file allows to render the canvas using WebGL instead of Canvas2D
// this is useful if you plant to render 3D objects inside your nodes

LGraphCanvas.prototype.enableWebGL = function()
{
	// TODO

	// if (typeof(GL) === undefined) throw("litegl.js must be included to use a WebGL canvas");
	// if (typeof(enableWebGLCanvas) === undefined) throw("webglCanvas.js must be included to use this feature");
	// this.gl = this.ctx = enableWebGLCanvas(this.canvas);
	// this.ctx.webgl = true;
	// this.bgcanvas = this.canvas;
	// this.bgctx = this.gl;
	// GL.create({ canvas: this.bgcanvas });
	// this.bgctx = enableWebGLCanvas( this.bgcanvas );
	// window.gl = this.gl;
}

/**
* marks as dirty the canvas, this way it will be rendered again
*
* @class LGraphCanvas
* @method setDirty
* @param {bool} fgcanvas if the foreground canvas is dirty (the one containing the nodes)
* @param {bool} bgcanvas if the background canvas is dirty (the one containing the wires)
*/
LGraphCanvas.prototype.setDirty = function(fgcanvas,bgcanvas)
{
	if (fgcanvas) this.dirty_canvas = true;
	if (bgcanvas) this.dirty_bgcanvas = true;
}

/**
* Used to attach the canvas in a popup
*
* @method getCanvasWindow
* @return {window} returns the window where the canvas is attached (the DOM root node)
*/
LGraphCanvas.prototype.getCanvasWindow = function()
{
	var doc = this.canvas.ownerDocument;
	return doc.defaultView || doc.parentWindow;
}

/**
* starts rendering the content of the canvas when needed
*
* @method startRendering
*/
LGraphCanvas.prototype.startRendering = function()
{
	if (this.is_rendering) return; //already rendering

	this.is_rendering = true;
	renderFrame.call(this);

	function renderFrame()
	{
		if (!this.pause_rendering) this.draw();

		var window = this.getCanvasWindow();
		if (this.is_rendering)
			if (LiteGraph.EXT_ENGINE) { window.requestAnimationFrame( renderFrame.bind(this) ) } else { window.setTimeout(this.bindFunction(renderFrame,this), 1000 / 50) }
		//	alternate command // window.requestAnimationFrame( this.bindFunction(renderFrame,this) );
	}
}

/**
* stops rendering the content of the canvas (to save resources)
*
* @method stopRendering
*/
LGraphCanvas.prototype.stopRendering = function()
{
	this.is_rendering = false;
}

/* LiteGraphCanvas input */

LGraphCanvas.prototype.processMouseDown = function(e)
{
	if (!this.graph) return;

	this.adjustMouseEvent(e);
	
	var ref_window = this.getCanvasWindow();
	var document = ref_window.document;

	//move mouse move event to the window in case it drags outside of the canvas
	this.canvas.removeEventListener("mousemove", this._mousemove_callback );
	ref_window.document.addEventListener("mousemove", this._mousemove_callback, true ); //catch for the entire window
	ref_window.document.addEventListener("mouseup", this._mouseup_callback, true );

	var n = this.graph.getNodeOnPos( e.canvasX, e.canvasY, this.visible_nodes );

	var skip_dragging = false;
	LiteGraph.closeAllContextualMenus();

	if (e.which === 1) //left button mouse
	{
		//another node selected
		var clicking_canvas_bg = false;

		//when clicked on top of a node
		//and it is not interactive
		if (n)
		{
			if (!n.flags.pinned) this.bringToFront(n); //if it wasnt selected?
			var skip_action = false;

			//not dragging mouse to connect two slots
			if (!this.connecting_node && !n.flags.collapsed)
			{
				//search for outputs
				if (n.outputs) for(var i = 0, l = n.outputs.length; i < l; ++i)
				{
					var output = n.outputs[i];
					var link_pos = n.getConnectionPos(false,i);
					if ( isInsideRectangle(e.canvasX, e.canvasY, link_pos[0] - 10, link_pos[1] - 8, 20,16) )
					{
						this.connecting_node = n;
						this.connecting_output = output;
						this.connecting_pos = n.getConnectionPos(false,i);
						this.connecting_slot = i;
						skip_action = true;
						break;
					}
				}

				//search for inputs
				if (n.inputs) for(var i = 0, l = n.inputs.length; i < l; ++i)
				{
					var input = n.inputs[i];
					var link_pos = n.getConnectionPos(true,i);
					if ( isInsideRectangle(e.canvasX, e.canvasY, link_pos[0] - 10, link_pos[1] - 8, 20,16) )
					{
						if (input.link !== null)
						{
							var link_info = n.graph.links[input.link];
							var link_node = n.graph.getNodeById(link_info.origin_id);
							if (link_node)
							{
								this.connecting_node = link_node;
								this.connecting_output = link_node.outputs[link_info.origin_slot];
								this.connecting_pos = link_node.getConnectionPos(false,link_info.origin_slot);
								this.connecting_slot = link_info.origin_slot;
								this.graph.skipstep = true;
							}
							n.disconnectInput(i);
							this.dirty_bgcanvas = true;
							skip_action = true;
						}
					}
				}

				// Search for corner
				// RESIZE DISABLED
				//	if ( !skip_action && isInsideRectangle(e.canvasX, e.canvasY, n.pos[0] + n.size[0] - 5, n.pos[1] + n.size[1] - 5 ,5,5 )) {
				//		this.resizing_node = n; this.canvas.style.cursor = "se-resize"; skip_action = true; }
			}

			//Search for corner
			if ( !skip_action && isInsideRectangle(e.canvasX, e.canvasY, n.pos[0], n.pos[1] - LiteGraph.NODE_TITLE_HEIGHT ,LiteGraph.NODE_TITLE_HEIGHT, LiteGraph.NODE_TITLE_HEIGHT ))
			{
				n.collapse();
				skip_action = true;
			}

			//it wasnt clicked on the links boxes
			if (!skip_action)
			{
				var block_drag_node = false;
				//double clicking
				var now = LiteGraph.getTime();
				if ((now - this.last_mouseclick) < 300 && this.selected_nodes[n.id])
				{
					//double click node
					if ( n.onDblClick) { n.onDblClick(e) } else { this.processNodeDblClicked(n) }
					block_drag_node = true;
				}

				//if do not capture mouse
				if ( n.onMouseDown && n.onMouseDown(e) ) block_drag_node = true;
				
				if (!block_drag_node)
				{
					if (!e.shiftKey) //REFACTOR: integrate with function
					{
						var todeselect = [];
						if ( !this.selected_nodes[n.id] ) for(var i in this.selected_nodes) if (this.selected_nodes[i] != n) todeselect.push(this.selected_nodes[i]);
						//two passes to avoid problems modifying the container
						for(var i in todeselect) this.processNodeDeselected(todeselect[i]);
					}

					if (e.ctrlKey)
					{
						var clp = this.graph.copyNodes(n.id, this.selected_nodes, [e.canvasX, e.canvasY], [0,0]);
						var todeselect = [];
						if ( !this.selected_nodes[n.id] ) for(var i in this.selected_nodes) if (this.selected_nodes[i] != n) todeselect.push(this.selected_nodes[i]);
						//two passes to avoid problems modifying the container
						for(var i in todeselect) this.processNodeDeselected(todeselect[i]);
						this.graph.pasteNodes(clp, [e.canvasX, e.canvasY]);
					}
					else { if (!this.selected_nodes[n.id]) this.processNodeSelected(n); }
					if (this.allow_dragnodes) this.node_dragged = n;
				}
				this.dirty_canvas = true;
			}
		}
		else
		{
			if (!e.shiftKey) this.deselectAllNodes();
			if ((LiteGraph.getTime() - this.last_mouseclick) < 300)
				if (e && e.shiftKey) { this.selectAllNodes() }
					else if (e && e.altKey) { this.clear() }
						else { this.show_info = !this.show_info }
			clicking_canvas_bg = true;
		}

		if (clicking_canvas_bg /* && this.allow_dragcanvas */) if (!e.altKey) { this.selection_mode = true } else { this.dragging_canvas = true }
	}
	else if (e.which === 2 && !this.selection_mode ) //middle button
	{
		if ( n == null ) { this.dragging_canvas = true } else if (this.selected_nodes[n.id]) { this.processNodeDeselected(n) } else { this.processNodeSelected(n) }
	}
	else if (e.which === 3 && !this.selection_mode ) //right button
	{
		this.dragging_canvas = true;
		// this.processContextualMenu(n,e);
	}

	//TODO
	// if (this.node_selected != prev_selected) this.onNodeSelectionChange(this.node_selected);
	if ( this.selection_mode && !this.selection ) this.selection = { startX:e.canvasX, startY:e.canvasY, endX:e.canvasX, endY:e.canvasY };

	this.last_mouse[0] = e.localX;
	this.last_mouse[1] = e.localY;
	this.last_mouseclick = LiteGraph.getTime();
	this.canvas_mouse = [e.canvasX, e.canvasY];

	this.graph.sendActionToCanvas("setDirty",[true,true]);

	//this is to ensure to defocus(blur) if a text input element is on focus
	if (!ref_window.document.activeElement || (ref_window.document.activeElement.nodeName.toLowerCase() !== "input" && ref_window.document.activeElement.nodeName.toLowerCase() !== "textarea")) e.preventDefault();
	e.stopPropagation();
	return false;
}

LGraphCanvas.prototype.processMouseMove = function(e)
{
	if (!this.graph) return;

	this.adjustMouseEvent(e);
	var mouse = [e.localX, e.localY];
	var delta = [mouse[0] - this.last_mouse[0], mouse[1] - this.last_mouse[1]];
	this.last_mouse = mouse;
	this.canvas_mouse = [e.canvasX, e.canvasY];

	if (this.dragging_canvas)
	{
		this.offset[0] += delta[0] / this.scale;
		this.offset[1] += delta[1] / this.scale;
		if (Math.abs(delta[0]) > 3 || Math.abs(delta[1]) > 3) { this.canvas_moved = true }
		this.dirty_canvas = true;
		this.dirty_bgcanvas = true;
	}
	else if (this.selection_mode)
	{
		this.selection.endX = e.localX / this.scale - this.offset[0];
		this.selection.endY = e.localY / this.scale - this.offset[1];
		this.dirty_canvas = true;
		this.dirty_bgcanvas = true;
	}
	else
	{
		if (this.connecting_node) this.dirty_canvas = true;

		//get node over
		var n = this.graph.getNodeOnPos(e.canvasX, e.canvasY, this.visible_nodes);

		//remove mouseover flag
		for(var i in this.graph._nodes)
		{
			if (this.graph._nodes[i].mouseOver && n != this.graph._nodes[i])
			{
				//mouse leave
				this.graph._nodes[i].mouseOver = false;
				if (this.node_over && this.node_over.onMouseLeave) this.node_over.onMouseLeave(e);
				this.node_over = null;
				this.dirty_canvas = true;
			}
		}

		//mouse over a node
		if (n)
		{
			//this.canvas.style.cursor = "move";
			if (!n.mouseOver)
			{
				//mouse enter
				n.mouseOver = true;
				this.node_over = n;
				this.dirty_canvas = true;
				if (n.onMouseEnter) n.onMouseEnter(e);
			}

			if (n.onMouseMove) n.onMouseMove(e);

			//ontop of input
			if (this.connecting_node)
			{
				var pos = this._highlight_input || [0,0];
				var slot = this.isOverNodeInput(n, e.canvasX, e.canvasY, pos);
				if (slot != -1 && n.inputs[slot])
				{
					var slot_type = n.inputs[slot].type;
					this._highlight_input = ( !this.connecting_output.type || !slot_type || slot_type.toLowerCase() == this.connecting_output.type.toLowerCase() )?pos:null;
				}
				else this._highlight_input = null;
			}

			//Search for corner
			// if ( isInsideRectangle(e.canvasX, e.canvasY, n.pos[0] + n.size[0] - 5, n.pos[1] + n.size[1] - 5 ,5,5 ))
			//	this.canvas.style.cursor = null;  //    this.canvas.style.cursor = "se-resize";   <<--- RESIZE DISABLED
			// else
				this.canvas.style.cursor = null;
		}
		else
		{
			this.canvas.style.cursor = null;
			this._highlight_input = null;
		}

		if (this.node_capturing_input && this.node_capturing_input != n && this.node_capturing_input.onMouseMove) { this.node_capturing_input.onMouseMove(e) }

		if (this.node_dragged)
		{
			/*
			this.node_dragged.pos[0] += delta[0] / this.scale;
			this.node_dragged.pos[1] += delta[1] / this.scale;
			this.node_dragged.pos[0] = Math.round(this.node_dragged.pos[0]);
			this.node_dragged.pos[1] = Math.round(this.node_dragged.pos[1]);
			*/
			
			for(var i in this.selected_nodes)
			{
				var n = this.selected_nodes[i];
				n.pos[0] += delta[0] / this.scale;
				n.pos[1] += delta[1] / this.scale;
			}
			
			this.dirty_canvas = true;
			this.dirty_bgcanvas = true;
		}

		if (this.resizing_node)
		{
			this.resizing_node.size[0] += delta[0] / this.scale;
			this.resizing_node.size[1] += delta[1] / this.scale;
			var max_slots = Math.max( this.resizing_node.inputs ? this.resizing_node.inputs.length : 0, this.resizing_node.outputs ? this.resizing_node.outputs.length : 0);
			if (this.resizing_node.size[1] < max_slots * LiteGraph.NODE_SLOT_HEIGHT + 4)
				this.resizing_node.size[1] = max_slots * LiteGraph.NODE_SLOT_HEIGHT + 4;
			if (this.resizing_node.size[0] < LiteGraph.NODE_MIN_WIDTH)
				this.resizing_node.size[0] = LiteGraph.NODE_MIN_WIDTH;

			this.canvas.style.cursor = "se-resize";
			this.dirty_canvas = true;
			this.dirty_bgcanvas = true;
		}
	}

	e.preventDefault();
	//e.stopPropagation();
	return false;
	//this is not really optimal
	//this.graph.change();
}

LGraphCanvas.prototype.processMouseUp = function(e)
{
	if (!this.graph) return;
	var window = this.getCanvasWindow();
	var document = window.document;

	//restore the mousemove event back to the canvas
	document.removeEventListener("mousemove", this._mousemove_callback, true );
	this.canvas.addEventListener("mousemove", this._mousemove_callback, true);
	document.removeEventListener("mouseup", this._mouseup_callback, true );

	this.adjustMouseEvent(e);

	if (e.which === 1) //left button
	{
		//dragging a connection
		if (this.connecting_node)
		{
			this.dirty_canvas = true;
			this.dirty_bgcanvas = true;

			var node = this.graph.getNodeOnPos(e.canvasX, e.canvasY, this.visible_nodes);

			//node below mouse
			if (node)
			{
				if (this.connecting_output.type === 'node') { this.connecting_node.connect(this.connecting_slot, node, -1); }
				else
				{
					//slot below mouse? connect
					var slot = this.isOverNodeInput(node, e.canvasX, e.canvasY);
					if (slot !== -1) { this.connecting_node.connect(this.connecting_slot, node, slot); }
					else
					{ //not on top of an input
						var input = node.getInputInfo(0);
						//simple connect
						if (input && !input.link && input.type == this.connecting_output.type) this.connecting_node.connect(this.connecting_slot, node, 0); //toLowerCase missing
					}
				}
			}

			this.connecting_output = null;
			this.connecting_pos = null;
			this.connecting_node = null;
			this.connecting_slot = -1;
			delete this.graph.skipstep;

		}//not dragging connection
		else if (this.resizing_node)
		{
			this.dirty_canvas = true;
			this.dirty_bgcanvas = true;
			this.resizing_node = null;
		}
		else if (this.node_dragged) //node being dragged?
		{
			this.dirty_canvas = true;
			this.dirty_bgcanvas = true;
			this.node_dragged.pos[0] = Math.round(this.node_dragged.pos[0]);
			this.node_dragged.pos[1] = Math.round(this.node_dragged.pos[1]);
			if (this.graph.config.align_to_grid) for(var i in this.selected_nodes) {  this.selected_nodes[i].alignToGrid(true); }
			this.node_dragged = null;
		}
		else if (this.selection_mode)
		{
			this.dirty_canvas = true;
			this.selection_mode = false;
			this.selectAllNodesInRectangle(this.selection.startX, this.selection.startY, this.selection.endX, this.selection.endY);
			this.selection = null;
		}
		else //no node being dragged
		{
			this.dirty_canvas = true;
			this.dragging_canvas = false;
			if ( this.node_over && this.node_over.onMouseUp ) this.node_over.onMouseUp(e);
			if ( this.node_capturing_input && this.node_capturing_input.onMouseUp ) this.node_capturing_input.onMouseUp(e);
		}
	}
	else if (e.which === 2) //middle button
	{
		//trace("middle");
		this.dirty_canvas = true;
		this.dragging_canvas = false;
	}
	else if (e.which === 3 ) //right button
	{
		if (!this.canvas_moved) this.processContextualMenu(this.graph.getNodeOnPos(e.canvasX, e.canvasY, this.visible_nodes),e);
		this.dragging_canvas = false;
		this.dirty_canvas = true;
	}

	if (this.canvas_moved) delete this.canvas_moved;
	this.graph.sendActionToCanvas("setDirty",[true,true]);

	e.stopPropagation();
	e.preventDefault();
	this._highlight_input = null;
	return false;
}

LGraphCanvas.prototype.processMouseWheel = function(e)
{
	if (!this.graph || !this.allow_dragcanvas || this.selection_mode) return;
	this.adjustMouseEvent(e);
	e.preventDefault();
	var n = this.graph.getNodeOnPos( e.canvasX, e.canvasY, this.visible_nodes );
	if (n && n.onMouseWheel) { n.onMouseWheel(e); }
	else
	{
		this.adjustMouseEvent(e);
		var delta = (e.wheelDeltaY != null ? e.wheelDeltaY/120 : -e.detail/2);
		var cscale = this.scale;
		if (delta>1) delta = 1;
		if (delta<-1) delta = -1;
		if (delta>0) cscale = cscale*(1+0.2*delta);
		if (delta<0) cscale = cscale/(1-0.2*delta);
		this.setZoom( cscale, [ e.localX, e.localY ] );
		this.graph.sendActionToCanvas("setDirty",[true,true]);
	}
	return false; // prevent default
}

LGraphCanvas.prototype.isOverNodeInput = function(node, canvasx, canvasy, slot_pos)
{
	if (node.inputs)
		for(var i = 0, l = node.inputs.length; i < l; ++i)
		{
			var input = node.inputs[i];
			var link_pos = node.getConnectionPos(true,i);
			if ( isInsideRectangle(canvasx, canvasy, link_pos[0] - 10, link_pos[1] - 8, 20,16) )
			{
				if (slot_pos) { slot_pos[0] = link_pos[0]; slot_pos[1] = link_pos[1] }
				return i;
			}
		}
	return -1;
}

LGraphCanvas.prototype.processKey = function(e)
{
	if (!this.graph) return;
	var block_default = false;
	if (e.type === "keydown")
	{
		//select all Control A
		if (e.keyCode === 65 && e.ctrlKey)
		{
			this.selectAllNodes();
			block_default = true;
		}

		//delete or backspace
		if (e.keyCode === 46 || e.keyCode === 8)
		{
			this.deleteSelectedNodes();
			block_default = true;
		}

		//collapse
		//...

		//TODO
		if (this.selected_nodes)
			for (var i in this.selected_nodes)
				if (this.selected_nodes[i].onKeyDown)
					this.selected_nodes[i].onKeyDown(e);
	}
	else if ( e.type === "keyup" )
	{
		if (this.selected_nodes)
			for (var i in this.selected_nodes)
				if (this.selected_nodes[i].onKeyUp)
					this.selected_nodes[i].onKeyUp(e);
	}

	this.graph.sendActionToCanvas("setDirty",[true,true]);

	if (block_default)
	{
		e.preventDefault();
		return false;
	}
}

LGraphCanvas.prototype.processDrop = function(e)
{
	e.preventDefault();
	this.adjustMouseEvent(e);
	moi.ui.alert("Drop event detected");
	var pos = [e.canvasX,e.canvasY];
	var node = this.graph.getNodeOnPos(pos[0],pos[1]);
	if (!node) return;
	if (!node.onDropFile) return;
//	var file = e.dataTransfer.files[0];
//	var filename = file.name;
}

LGraphCanvas.prototype.processNodeSelected = function(n)
{
	if (n.selected) return;
	n.selected = true;
	if (n.onSelected) n.onSelected();
	this.selected_nodes[ n.id ] = n;
	
	this.addNodeInfo(n);
	this.dirty_canvas = true;
}
	
LGraphCanvas.prototype.processNodeDeselected = function(n)
{
	if (!n.selected) return;
	n.selected = false;
	if (n.onDeselected) n.onDeselected();
	delete this.selected_nodes[n.id];
	
	this.removeNodeInfo(n);
	this.dirty_canvas = true;
}

LGraphCanvas.prototype.addNodeInfo = function(n)
{
//	console.log(n.type+" "+n.title+" "+n.isChanged); // DEBUG
	if (!this.infopanel) return;
	var ref_window = this.getCanvasWindow();

	this.infopanel_nodes[n.id]={};
	this.infopanel_nodes[n.id].editable = {};
	
	var nodeinfo = ref_window.document.createElement("div");
	nodeinfo.className  = "node-info";
	nodeinfo.innerHTML = "";
	this.addInfoLine(n.id, nodeinfo, "Title", n.title, 1, false );
	if (this.show_info) this.addInfoLine(n.id, nodeinfo, "ID:"+n.id, n.type, 0, false );

	for ( var i in n.properties ) this.addInfoLine(n.id, nodeinfo, i, n.properties[i], 2, false );
	
	this.infopanel_list.appendChild(nodeinfo);
	this.infopanel_nodes[n.id]["main_element"] = nodeinfo;
}

LGraphCanvas.prototype.removeNodeInfo = function(n)
{
	if (!this.infopanel || !this.infopanel_nodes[n.id]) return;
	this.infopanel_list.removeChild(this.infopanel_nodes[n.id]["main_element"]);
	delete this.infopanel_nodes[n.id];
}

LGraphCanvas.prototype.refreshNodeInfo = function(id)
{
	var n = this.graph.getNodeById( id );
	if (!this.infopanel || !this.infopanel_nodes[n.id]) return;
	if (!this.infopanel_nodes[n.id]["main_element"]) return;
	var ref_window = this.getCanvasWindow();
	var nodeinfo = ref_window.document.createElement("div");
	nodeinfo.className  = "node-info";
	nodeinfo.innerHTML = "";
	this.addInfoLine(n.id, nodeinfo, "Title", n.title, 1, false );
	if (this.show_info) this.addInfoLine(n.id, nodeinfo, "ID:"+n.id, n.type, 0, false );
	for ( var i in n.properties ) this.addInfoLine(n.id, nodeinfo, i, n.properties[i], 2, false );
		
	this.infopanel_list.replaceChild(nodeinfo, this.infopanel_nodes[n.id]["main_element"]);
	this.infopanel_nodes[n.id]["main_element"] = nodeinfo;
}

LGraphCanvas.prototype.addInfoLine = function(nodeid, parentdiv, title, value, type, mini)
{
	var graph = this.graph;
	var vtype = typeof (value);
	if ( value.constructor === Array ) { vtype = 'numarray'; if (value.length > 0) if ( typeof (value[0]) === 'string' ) vtype = 'list'; }
	if ( vtype !== 'string' && vtype !== 'number' && vtype !== 'numarray' && vtype !== 'list') return;
	var ref_window = this.getCanvasWindow(), content, element;
	element = ref_window.document.createElement("div");
	element.data = title;
	element.className  = "node-infoline";
	if ( mini ) element.className  = "node-miniline";
	
	content = ref_window.document.createElement("strong");
	var pTitle = title.toString();
	if ( pTitle.charAt(0) === "_" ) pTitle = pTitle.slice(1);
	pTitle = pTitle.toString().charAt(0).toUpperCase()+pTitle.toString().slice(1);
	content.innerHTML= lang.getTranslation(pTitle.replace('_', ' '));
	element.appendChild(content);
	
	if ( type === 1 ) // title
	{
		content = ref_window.document.createElement("input");
		content.type = "text";
		content.value = lang.getTranslation(value);
		content.onchange = function()
		{
			var node = graph._nodes_by_id[nodeid];
			if (this.value === "") { this.value = node.title; return }
			node.title = this.value;
			if  (node.onTitleChange) node.onTitleChange();
			node.computeSize();
			graph.setDirtyCanvas(true, true);
		}
		this.infopanel_nodes[nodeid]["editable"][title] = content;
	}
	else if ( type === 2 ) // properties
	{
		if ( vtype === 'list')
		{
			content = ref_window.document.createElement("select");
			var selected = 'undefined';
			for ( var i in value )
			{
				var v = value[i].toString();
				if ( selected === 'undefined' ) { selected = v }
				else
				{
					var option = ref_window.document.createElement("option");
					if ( v == selected ) { option.selected="selected" }
					option.value = v;
					option.innerHTML = lang.getTranslation(v, "#");
					content.appendChild(option);
				}
			}
			content.onchange = function()
			{
				var node = graph._nodes_by_id[nodeid];
				node.properties[title][0] =  this.value;
				if  (node.onPropertyChange) node.onPropertyChange( title, this.value );
				graph.setDirtyCanvas(true, true);
				graph.setisChangedFlag(nodeid);
			}
		}
		else if ( vtype === 'string')
		{
			if (title[0] === "_") { content = ref_window.document.createElement("textarea"); content.rows = 6; } else { content = ref_window.document.createElement("input") }
			content.type = "text";
			content.value = value;
			content.onchange = function()
			{
				var node = graph._nodes_by_id[nodeid];
				if (node["properties"][title] === this.value) return;
				if (this.value === "") { this.value = node["properties"][title]; return; }
				node["properties"][title] = this.value;
				if  (node.onPropertyChange) node.onPropertyChange( title, this.value );
				graph.setDirtyCanvas(true, true);
				graph.setisChangedFlag(nodeid);
			}
			if (title[0] === "_") { content.onmouseout = function() { this.blur(); this.onchange() }}
			this.infopanel_nodes[nodeid]["editable"][title] = content;
		}
		else
		{
			content = ref_window.document.createElement("input");
			content.type = "text";
			content.value = value;

			content.onchange = function()
			{
				var node = graph._nodes_by_id[nodeid];
				var valuetype = "other";
				if ( typeof (node["properties"][title]) === "number" ) valuetype = "number";
				if ( node["properties"][title].constructor === Array ) valuetype = "numarray";
				if ( valuetype === "number" || valuetype === "numarray")
				{
					if (this.value === "") { this.value = node["properties"][title]; return }
					var fncOK, fnc, fnca = this.value.replace(' ', '').split(","), newvalue=[], nv = 0, fncError = false;
					var fnconvert = function (fn) { if (Math.hasOwnProperty(fn)) { return "Math."+fn } else if (Math.hasOwnProperty(fn.toUpperCase())) { return "Math."+fn.toUpperCase() } else { fncOK = false } };
					for (var v in fnca )
					{
						fnc = fnca[v];
						if ( fnc === "" ) { continue }
						fnc = fnc.replace(/\[/g, "(pi/180*(");
						fnc = fnc.replace(/\]/g, "))");
						fnc = fnc.replace(/(?:[a-z$_][a-z0-9$_]*)|(?:[;={}"'!&<>^\\?:])/ig,fnconvert);
						try { newvalue[nv] = eval(fnc) } catch (e) { fncError = true; break; }
						if ( newvalue[nv] === 'Infinity' || newvalue[nv] === '-Infinity' || typeof ( newvalue[nv] ) !=='number' || isNaN( newvalue[nv] )) { fncError = true; break; }
						nv++;
					}
					if ( fncError || fnca.length === 0 ) { this.value = node["properties"][title] }
					else
					{
						if ( valuetype === "number" ) { newvalue = newvalue[0] }
						node["properties"][title] = newvalue;
						this.value = newvalue;
					}
				} else { node["properties"][title] = this.value; moi.ui.alert("call Max"); }
		
				if (node.onPropertyChange) node.onPropertyChange( title, this.value );
				graph.setDirtyCanvas(true, true);
				graph.setisChangedFlag(nodeid);
			}
			this.infopanel_nodes[nodeid]["editable"][title] = content;
		}
	}
	else
	{
		content = ref_window.document.createElement("span");
		content.innerHTML = value;
	}
	element.appendChild(content);
	parentdiv.appendChild(element);
}

LGraphCanvas.prototype.processNodeDblClicked = function(n)
{
	if (this.onSwitchNodePanel) this.onSwitchNodePanel(n);
	if (this.onNodeDblClicked) this.onNodeDblClicked(n);
	this.setDirty(true);
}

LGraphCanvas.prototype.selectNode = function(node)
{
	this.deselectAllNodes();
	if (!node) return;
	if (!node.selected && node.onSelected) node.onSelected();
	
	node.selected = true;
	this.selected_nodes[ node.id ] = node;
	this.setDirty(true);
}

LGraphCanvas.prototype.onSwitchNodePanel = function()
{
	var ref_window = this.getCanvasWindow();
	if (!ref_window) return;
	this.infopanel_visible = !this.infopanel_visible;
	ref_window.document.body.querySelector(".node-panel").style.display = (this.infopanel_visible)?"block":"none";
	ref_window.document.body.querySelector("#properties_button").style.opacity = (this.infopanel_visible)?"0.8":"0.2";
}

LGraphCanvas.prototype.selectAllNodesInRectangle = function(x1, y1, x2, y2)
{
	for(var i in this.graph._nodes)
	{
		var n = this.graph._nodes[i];
		if (n.isNodeInsideRectangle(x1, y1, x2, y2))
		{
			if (!n.selected && n.onSelected) n.onSelected();
			if (!n.selected) this.addNodeInfo(n);
			n.selected = true;
			this.selected_nodes[this.graph._nodes[i].id] = n;
		}
	}
	this.setDirty(true);
}

LGraphCanvas.prototype.selectAllNodes = function()
{
	for(var i in this.graph._nodes)
	{
		var n = this.graph._nodes[i];
		if (!n.selected && n.onSelected) n.onSelected();
		if (!n.selected) this.addNodeInfo(n);
		n.selected = true;
		this.selected_nodes[this.graph._nodes[i].id] = n;
	}
	this.setDirty(true);
}

LGraphCanvas.prototype.deselectAllNodes = function()
{
	for(var i in this.selected_nodes)
	{
		var n = this.selected_nodes[i];
		if (n.onDeselected) n.onDeselected();
		n.selected = false;
		this.removeNodeInfo(n);
	}
	this.selected_nodes = {};
	this.setDirty(true);
}

LGraphCanvas.prototype.deleteSelectedNodes = function()
{
	for(var i in this.selected_nodes)
	{
		var m = this.selected_nodes[i];
		this.removeNodeInfo(m);
		this.graph.remove(m);
	}
	this.selected_nodes = {};
	this.setDirty(true);
}

LGraphCanvas.prototype.centerOnNode = function(node)
{
	this.offset[0] = -node.pos[0] - node.size[0] * 0.5 + (this.canvas.width * 0.5 / this.scale);
	this.offset[1] = -node.pos[1] - node.size[1] * 0.5 + (this.canvas.height * 0.5 / this.scale);
	this.setDirty(true,true);
}

LGraphCanvas.prototype.adjustMouseEvent = function(e)
{
	var b = this.canvas.getBoundingClientRect();
	e.localX = (e.pageX - b.left) * this.pixelRatio;
	e.localY = (e.pageY - b.top) * this.pixelRatio;

	e.canvasX = e.localX / this.scale - this.offset[0];
	e.canvasY = e.localY / this.scale - this.offset[1];
}

LGraphCanvas.prototype.setZoom = function(value, zooming_center)
{
	if (!zooming_center) zooming_center = [this.canvas.width * 0.5,this.canvas.height * 0.5];
	var center = this.convertOffsetToCanvas( zooming_center );
	this.scale = value;

	if (this.scale > this.max_zoom) this.scale = this.max_zoom;
	else if (this.scale < this.min_zoom) this.scale = this.min_zoom;
	
	var new_center = this.convertOffsetToCanvas( zooming_center );
	var delta_offset = [new_center[0] - center[0], new_center[1] - center[1]];

	this.offset[0] += delta_offset[0];
	this.offset[1] += delta_offset[1];

	this.editor_zoomalpha = this.scale/this.uiRatio/this.pixelRatio*2.2-1;

	if (this.editor_zoomalpha>1) this.editor_zoomalpha=1;
	if (this.editor_zoomalpha<0) this.editor_zoomalpha=0;

	this.editor_zoomalpha *= this.editor_alpha;
	this.editor_zoomalpha_title = Math.pow(this.editor_zoomalpha,1/4);

	this.dirty_canvas = true;
	this.dirty_bgcanvas = true;
}

LGraphCanvas.prototype.convertOffsetToCanvas = function(pos)
{
	return [pos[0] / this.scale - this.offset[0], pos[1] / this.scale - this.offset[1]];
}

LGraphCanvas.prototype.convertCanvasToOffset = function(pos)
{
	return [(pos[0] + this.offset[0]) * this.scale, (pos[1] + this.offset[1]) * this.scale ];
}

LGraphCanvas.prototype.convertEventToCanvas = function(e)
{
	var rect = this.canvas.getClientRects()[0];
	return this.convertOffsetToCanvas([e.pageX*this.pixelRatio - rect.left,e.pageY*this.pixelRatio - rect.top]);
}

LGraphCanvas.prototype.bringToFront = function(n)
{
	var i = this.graph._nodes.indexOf(n);
	if (i === -1) return;
	
	this.graph._nodes.splice(i,1);
	this.graph._nodes.push(n);
}

LGraphCanvas.prototype.sendToBack = function(n)
{
	var i = this.graph._nodes.indexOf(n);
	if (i === -1) return;
	
	this.graph._nodes.splice(i,1);
	this.graph._nodes.unshift(n);
}
	
/* Interaction */

/* LGraphCanvas render */

LGraphCanvas.prototype.computeVisibleNodes = function()
{
	var visible_nodes = [];
	for (var i in this.graph._nodes)
	{
		var n = this.graph._nodes[i];
		if (!overlapBounding(this.visible_area, n.getBounding() )) continue; //out of the visible area
		visible_nodes.push(n);
	}
	return visible_nodes;
}

LGraphCanvas.prototype.draw = function(force_canvas, force_bgcanvas)
{
	//fps counting
	var now = LiteGraph.getTime();
	this.render_time = (now - this.last_draw_time)*0.001;
	this.last_draw_time = now;

	if (this.graph)
	{
		var start = [-this.offset[0], -this.offset[1] ];
		var end = [start[0] + this.canvas.width / this.scale, start[1] + this.canvas.height / this.scale];
		this.visible_area = [start[0],start[1],end[0],end[1]];
	}

	if (this.dirty_bgcanvas || force_bgcanvas) this.drawBackCanvas();
	if (this.dirty_canvas || force_canvas) this.drawFrontCanvas();
	this.fps = this.render_time ? (1.0 / this.render_time) : 0;
	this.frame += 1;
}

LGraphCanvas.prototype.drawFrontCanvas = function()
{
	if (!this.ctx) this.ctx = this.bgcanvas.getContext("2d");
	var ctx = this.ctx;
	if (!ctx) return; //maybe is using webgl...
	if (ctx.start2D) ctx.start2D();
	var canvas = this.canvas;

	//reset in case of error
	ctx.restore();
	ctx.setTransform(1, 0, 0, 1, 0, 0);

	//clip dirty area if there is one, otherwise work in full canvas
	if (this.dirty_area)
	{
		ctx.save();
		ctx.beginPath();
		ctx.rect(this.dirty_area[0],this.dirty_area[1],this.dirty_area[2],this.dirty_area[3]);
		ctx.clip();
	}

	//clear
	//canvas.width = canvas.width;
	if (this.clear_background) ctx.clearRect(0,0,canvas.width, canvas.height);

	//draw bg canvas
	if (this.bgcanvas == this.canvas) this.drawBackCanvas();
		else ctx.drawImage(this.bgcanvas,0,0);

	//rendering
	if (this.onRender) this.onRender(canvas, ctx);

	//info widget
	if (this.show_info) this.renderInfo(ctx);

	if (this.graph)
	{
		//apply transformations
		ctx.save();
		ctx.scale(this.scale,this.scale);
		ctx.translate(this.offset[0],this.offset[1]);

		//draw nodes
		var drawn_nodes = 0;
		var visible_nodes = this.computeVisibleNodes();
		this.visible_nodes = visible_nodes;

		for (var i in visible_nodes)
		{
			var node = visible_nodes[i];

			//transform coords system
			ctx.save();
			ctx.translate( node.pos[0], node.pos[1] );

			//Draw
			this.drawNode(node, ctx );
			drawn_nodes += 1;

			//Restore
			ctx.restore();
		}

		if ( this.selection_mode )
		{
			ctx.strokeStyle = LiteGraph.NODE_SELECTION;
			ctx.fillStyle = LiteGraph.NODE_SELECTION;
			ctx.globalAlpha = 0.1;
			ctx.beginPath();
			ctx.rect(this.selection.startX+0.5,this.selection.startY+0.5,this.selection.endX-this.selection.startX,this.selection.endY-this.selection.startY);
			ctx.fill();
			ctx.globalAlpha = 1;
			ctx.lineWidth = 1;
			ctx.strokeRect(this.selection.startX+0.5,this.selection.startY+0.5,this.selection.endX-this.selection.startX,this.selection.endY-this.selection.startY);
		}
		
		//connections ontop?
		if (this.graph.config.links_ontop) this.drawConnections(ctx);

		//current connection
		if (this.connecting_pos != null)
		{
			ctx.lineWidth = this.connections_width;
			var link_color = this.connecting_output.type === 'node' ? "#F85" : "#CCC";
			var link_color = LGraphCanvas.link_type_colors[this.connecting_output.type];
			this.renderLink(ctx, this.connecting_pos, [this.canvas_mouse[0],this.canvas_mouse[1]], link_color );

			ctx.beginPath();
			ctx.arc( this.connecting_pos[0], this.connecting_pos[1],4,0,Math.PI*2);
			/*
			if ( this.connecting_output.round)
				ctx.arc( this.connecting_pos[0], this.connecting_pos[1],4,0,Math.PI*2);
			else
				ctx.rect( this.connecting_pos[0], this.connecting_pos[1],12,6);
			*/
			ctx.fill();

		//	ctx.fillStyle = LiteGraph.link_type_colors.connect;
			ctx.fillStyle = LiteGraph.link_type_colors[this.connecting_output.type];
			if (this._highlight_input)
			{
				ctx.beginPath();
				ctx.arc( this._highlight_input[0], this._highlight_input[1],7,0,Math.PI*2);
				ctx.fill();
			}
		}
		ctx.restore();
	}

	if (this.dirty_area) ctx.restore();
	if (ctx.finish2D) ctx.finish2D();//this is a function I use in webgl renderer
		
	// updating infopanel
	if (this.infopanel_nodes) for (var n in this.infopanel_nodes) for ( var p in this.infopanel_nodes[n]["editable"] ) if (p !== 'Title' ) this.infopanel_nodes[n]["editable"][p].value = this.graph.getNodeById(n).properties[p];
	this.dirty_canvas = false;
}

LGraphCanvas.prototype.renderInfo = function( ctx, x, y )
{
	x = x || 0;
	y = y || 0;

	ctx.save();
	ctx.translate( x, y );

	var dpir = this.pixelRatio * this.uiRatio;

	ctx.font = 12*dpir+"px Arial";
	ctx.fillStyle = LiteGraph.NODE_INFO;
	if (this.graph)
	{
		ctx.fillText( "Total: " + this.graph.elapsed_time.toFixed(0)+" ms",5,dpir*15*1 );
		ctx.fillText( "FPS:" + this.fps.toFixed(0),5,dpir*15*2 );
		ctx.fillText( "F: " + this.frame,5,dpir*15*3 );
		ctx.fillText( this.graph.blocked?"Graph blocked":"",5,dpir*15*4 );
		ctx.fillText( this.graph.filename,5,this.bgcanvas.height-3*dpir );
	}
	else ctx.fillText( "No graph selected",5,13*1 );
	ctx.restore();
}

LGraphCanvas.prototype.drawBackCanvas = function()
{
	var canvas = this.bgcanvas;
	if (!this.bgctx) this.bgctx = this.bgcanvas.getContext("2d");
	var ctx = this.bgctx;
	if (ctx.start) ctx.start();

	//clear
	if (this.clear_background) ctx.clearRect(0,0,canvas.width, canvas.height);

	//reset in case of error
	ctx.restore();
	ctx.setTransform(1, 0, 0, 1, 0, 0);

	if (this.graph)
	{
		//apply transformations
		ctx.save();
		ctx.scale(this.scale,this.scale);
		ctx.translate(this.offset[0],this.offset[1]);

		//render BG
		if (this.background_image && this.editor_zoomalpha > 0)
		{
			ctx.globalAlpha = this.editor_zoomalpha/2;
			ctx.webkitImageSmoothingEnabled = ctx.mozImageSmoothingEnabled = ctx.imageSmoothingEnabled = false;
			if (!this._bg_img || this._bg_img.name != this.background_image)
			{
				this._bg_img = new Image();
				this._bg_img.name = this.background_image;
				this._bg_img.src = this.background_image;
				var that = this;
				this._bg_img.onload = function() { that.draw(true,true); }
			}

			var pattern = null;
			if (this._bg_img != this._pattern_img && this._bg_img.width > 0)
			{
				pattern = ctx.createPattern( this._bg_img, 'repeat' );
				this._pattern_img = this._bg_img;
				this._pattern = pattern;
			}
			else pattern = this._pattern;
			if (pattern)
			{
				ctx.fillStyle = pattern;
				ctx.fillRect(this.visible_area[0],this.visible_area[1],this.visible_area[2]-this.visible_area[0],this.visible_area[3]-this.visible_area[1]);
				ctx.fillStyle = "transparent";
			}

			ctx.globalAlpha = 1.0;
			ctx.webkitImageSmoothingEnabled = ctx.mozImageSmoothingEnabled = ctx.imageSmoothingEnabled = true;
		}

		if (this.onBackgroundRender) this.onBackgroundRender(canvas, ctx);

		//bg
		ctx.strokeStyle = LiteGraph.NODE_VIEWPORT_BORDER; // viewport border
		ctx.lineWidth = this.pixelRatio/this.scale;
		ctx.strokeRect(0,0,canvas.width/this.pixelRatio/this.uiRatio,canvas.height/this.pixelRatio/this.uiRatio);

		if (this.render_connections_shadows)
		{
			ctx.shadowColor = "#000";
			ctx.shadowOffsetX = 0;
			ctx.shadowOffsetY = 0;
			ctx.shadowBlur = 6;
		}
		else ctx.shadowColor = "rgba(0,0,0,0)";

		//draw connections
		this.drawConnections(ctx);

		ctx.shadowColor = "rgba(0,0,0,0)";

		//restore state
		ctx.restore();
	}

	if (ctx.finish) ctx.finish();

	this.dirty_bgcanvas = false;
	this.dirty_canvas = true; //to force to repaint the front canvas with the bgcanvas
}

/* Renders the LGraphNode on the canvas */
LGraphCanvas.prototype.drawNode = function(node, ctx )
{
	var glow = false;
	var color = node.color || LiteGraph.NODE_DEFAULT_COLOR;
	var render_title = true;
	if (node.flags.skip_title_render) render_title = false;
	if (node.mouseOver) render_title = true;
	
	//shadow and glow
	if (node.mouseOver) glow = true;
	
	if (this.render_shadows)
	{
		ctx.shadowColor = "rgba(0,0,0,0.5)";
		if (node.selected)
		{
			ctx.shadowOffsetX = this.scale * LiteGraph.NODE_SHADOW_OFFSET_SELECTED;
			ctx.shadowOffsetY = this.scale * LiteGraph.NODE_SHADOW_OFFSET_SELECTED;
			ctx.shadowBlur = this.scale * LiteGraph.NODE_SHADOW_BLUR_SELECTED;
		}
		else
		{
			ctx.shadowOffsetX = this.scale * LiteGraph.NODE_SHADOW_OFFSET;
			ctx.shadowOffsetY = this.scale * LiteGraph.NODE_SHADOW_OFFSET;
			ctx.shadowBlur = this.scale * LiteGraph.NODE_SHADOW_BLUR;
		}
	} else ctx.shadowColor = "transparent";
	
	ctx.globalAlpha = this.editor_alpha;

	//clip if required (mask)
	var size = [];
	size.push(node.size[0]);
	size.push(node.size[1]);
	size.push(node.size[2]);
	if (node.flags.collapsed)
	{
		size[0] = size[2];
		size[1] = 0;
	}

	//Start clipping
	if (node.flags.clip_area)
	{
		ctx.save();
		ctx.beginPath();
		ctx.rect(0,0,size[0], size[1]);
		ctx.clip();
	}

	//draw shape
	this.drawNodeShape(node, ctx, size, color, node.bgcolor, !render_title, node.selected, node.flags.collapsed);
	ctx.shadowColor = "transparent";

	//connection slots
	ctx.textAlign = "left";
	ctx.font = this.inner_text_font;

	//render inputs and outputs
	if (!node.flags.collapsed)
	{
		//input connection slots
		if (node.inputs)
			for(var i = 0; i < node.inputs.length; i++)
			{
				var slot = node.inputs[i];
				var pos = node.getConnectionPos(true,i);
				var transparent = false, coloreddot = false, coloredtext = this.io_info;
				pos[0] -= node.pos[0];
				pos[1] -= node.pos[1];

				if ( this.connecting_node !== null ) { transparent = true }
				if ( this.connecting_node !== null && this.connecting_output.type && slot.type )
					if ( this.connecting_output.type.toLowerCase() === slot.type.toLowerCase() )
						{ transparent = false; coloredtext = true; coloreddot = true }
				if ( slot.link !== null ) { coloredtext = true; coloreddot = true }

				ctx.fillStyle = ( slot.link !== null || (this.connecting_node && !transparent)) ? LGraphCanvas.link_type_colors[slot.type] : color;
				ctx.globalAlpha = ( transparent )?this.editor_zoomalpha*0.1:this.editor_zoomalpha;

				//render name
				if (this.editor_zoomalpha>0)
				{
					ctx.fillStyle = ( coloredtext )?LGraphCanvas.link_type_colors[slot.type]:color;
					var text = (slot.label === null || slot.label === undefined ) ? lang.getTranslation(slot.name) : lang.getTranslation(slot.label);
					if (transparent) { ctx.strokeText(text,pos[0] + 10,pos[1] + 5) }
					else { ctx.fillText(text,pos[0] + 10,pos[1] + 5) }
				}

				//render dot
				ctx.globalAlpha = ( transparent )?this.editor_alpha*0.1:1;
				ctx.beginPath();
				ctx.fillStyle = ( coloreddot ) ? LGraphCanvas.link_type_colors[slot.type] : color;
				ctx.arc(pos[0],pos[1],4,0,Math.PI*2);
				ctx.fill();
			}

		ctx.globalAlpha = this.editor_alpha;

		//output connection slots

		ctx.textAlign = "right";
		if (node.outputs)
			for(var i = 0; i < node.outputs.length; i++)
			{
				var slot = node.outputs[i];
				var pos = node.getConnectionPos(false,i);
				var transparent = false, coloreddot = false, coloredtext = this.io_info;
				pos[0] -= node.pos[0];
				pos[1] -= node.pos[1];

				if ( this.connecting_node !== null )
				{
					if ( node.id === this.connecting_node.id && this.connecting_slot === i)
						{ transparent = false; coloredtext = true; coloreddot = true } else { transparent = true }
				} else if (slot.links !== null && slot.links.length > 0 ) { coloredtext = true; coloreddot = true;  }

				ctx.globalAlpha = ( transparent )?this.editor_zoomalpha*0.1:this.editor_zoomalpha;

				//render output name
				if (this.editor_zoomalpha>0)
				{
					ctx.fillStyle = ( coloredtext )?LGraphCanvas.link_type_colors[slot.type]:color;
					var text = (slot.label === null || slot.label === undefined ) ? lang.getTranslation(slot.name) : lang.getTranslation(slot.label);
					if (transparent) { ctx.strokeText(text,pos[0] - 10,pos[1] + 5);}
					else { ctx.fillText(text,pos[0] - 10,pos[1] + 5); }
				}
				
				//render dot
				ctx.globalAlpha = ( transparent )?this.editor_alpha*0.1:1;
				ctx.beginPath();
				ctx.fillStyle = ( coloreddot ) ? LGraphCanvas.link_type_colors[slot.type] : color;
				ctx.arc(pos[0],pos[1],4,0,Math.PI*2);
				ctx.fill();
			}

		ctx.textAlign = "left";
		ctx.globalAlpha = 1;

		if (node.onDrawForeground) node.onDrawForeground(ctx);
	} // !collapsed

	if (node.flags.clip_area) ctx.restore();
	ctx.globalAlpha = 1.0;
}

/* Renders the node shape */
LGraphCanvas.prototype.drawNodeShape = function(node, ctx, size, fgcolor, bgcolor, no_title, selected, collapsed )
{
	//bg rect
	ctx.strokeStyle = fgcolor || LiteGraph.NODE_DEFAULT_COLOR;
	ctx.fillStyle = bgcolor || LiteGraph.NODE_DEFAULT_BGCOLOR;

	// gradient test
	// var grad = ctx.createLinearGradient(0,0,0,node.size[1]);
	// grad.addColorStop(0, fgcolor || LiteGraph.NODE_DEFAULT_COLOR);
	// grad.addColorStop(0.8, bgcolor || LiteGraph.NODE_DEFAULT_BGCOLOR);
	// grad.addColorStop(1, bgcolor || LiteGraph.NODE_DEFAULT_BGCOLOR);
	// ctx.fillStyle = grad;

	var title_height = LiteGraph.NODE_TITLE_HEIGHT;

	ctx.beginPath();
	ctx.shadowColor = LiteGraph.NODE_DEFAULT_SHADOW;
	
	ctx.roundRect(0,no_title ? 0 : -title_height,size[0], no_title ? size[1] : size[1] + title_height, 5);
	ctx.fill();
	ctx.shadowColor = "transparent";
	
	if (selected)
	{
		ctx.fillStyle = LiteGraph.NODE_SELECTION;
		ctx.roundRect(-1,no_title ? -1 : -title_height -1, size[0]+2, no_title ? (size[1]+2) : (size[1] + title_height+2), 6);
		ctx.fill();
		ctx.fillStyle = bgcolor || LiteGraph.NODE_DEFAULT_BGCOLOR;
	}
	
	ctx.beginPath();
	ctx.roundRect(0,no_title ? 0 : -title_height,size[0], no_title ? size[1] : size[1] + title_height, 5);
	ctx.fill();

	ctx.shadowColor = "transparent";

	//image
	if (node.bgImage && node.bgImage.width) ctx.drawImage( node.bgImage, (size[0] - node.bgImage.width) * 0.5 , (size[1] - node.bgImage.height) * 0.5);
	if (node.bgImageUrl && !node.bgImage) node.bgImage = node.loadImage(node.bgImageUrl);
	if (node.onDrawBackground) node.onDrawBackground(ctx);

	//title bg
	if (!no_title)
	{
		ctx.fillStyle = fgcolor || LiteGraph.NODE_DEFAULT_COLOR;
		var old_alpha = ctx.globalAlpha;
		ctx.globalAlpha = 0.5 * old_alpha;

		if (collapsed) ctx.roundRect(0,-title_height,size[0], title_height,5,5);
			else ctx.roundRect(0,-title_height,size[0], title_height,5,0);
		ctx.fill()
		ctx.globalAlpha = old_alpha;

		if (node.icon && LiteGraph.EXT_ENGINE) { ctx.drawImage(node.icon,1,-title_height+1,title_height-2,title_height-2) }
		else
		{
			ctx.fillStyle = node.boxcolor || LiteGraph.NODE_DEFAULT_BOXCOLOR;
			if ( node.missed ) ctx.fillStyle = LiteGraph.scheme_colors.node_error_box;
			ctx.beginPath();
			ctx.roundRect(3,-title_height + 3,title_height - 6,title_height - 6, 3);
			ctx.fill();
		}

		//title text
		ctx.font = this.title_text_font;
		var title = node.getTitle();
		title = lang.getTranslation(title);
		if (title && this.editor_zoomalpha_title > 0)
		{
			ctx.globalAlpha = this.editor_zoomalpha_title;
			ctx.fillStyle = node.title_color || LiteGraph.NODE_TITLE_COLOR;
			if ( node.missed ) ctx.fillStyle = LiteGraph.scheme_colors.node_error_title;
			ctx.fillText( title, title_height, 5-title_height/2 );
		}
	}

	ctx.globalAlpha = 1;
	if ( this.show_info )	// node elapsed_time
	{
		ctx.font = this.inner_text_font;
		ctx.fillStyle = LiteGraph.NODE_INFO;
		if (node.elapsed_time >20 ) ctx.fillStyle = "#B66";
		if (node.elapsed_time >50 ) ctx.fillStyle = "#F33";
		ctx.fillText( node.elapsed_time.toFixed(0)+" ms",size[0]+5, -4);
	}
}

LGraphCanvas.prototype.drawConnections = function(ctx)
{
	//draw connections
	ctx.lineWidth = this.connections_width;

	//for every node
	for (var n in this.graph._nodes)
	{
		var node = this.graph._nodes[n];
		//for every input (we render just inputs because it is easier as every slot can only have one input)
		if (node.inputs && node.inputs.length)
			for(var i in node.inputs)
			{
				var input = node.inputs[i];
				if (!input || input.link == null) continue;
				var link_id = input.link;
				var link = this.graph.links[ link_id ];
				if (!link) continue;

				var start_node = this.graph.getNodeById( link.origin_id );
				if (start_node == null) continue;
				var start_node_slot = link.origin_slot;
				var start_node_slotpos = null;

				if (start_node_slot == -1) start_node_slotpos = [start_node.pos[0] + 10, start_node.pos[1] + 10];
					else start_node_slotpos = start_node.getConnectionPos(false, start_node_slot);

				var color = LGraphCanvas.link_type_colors[node.inputs[i].type];
				if (color == null) color = "#999";
				this.renderLink(ctx, start_node_slotpos, node.getConnectionPos(true,i), color );
			}
	}
}

LGraphCanvas.prototype.renderLink = function(ctx,a,b,color)
{
	if (!this.highquality_render)
	{
		ctx.beginPath();
		ctx.moveTo(a[0],a[1]);
		ctx.lineTo(b[0],b[1]);
		ctx.stroke();
		return;
	}

	var dist = distance(a,b);
	if (this.render_connections_border && this.scale > 0.6*this.uiRatio*this.pixelRatio) ctx.lineWidth = this.connections_width + 2;
	ctx.beginPath();
	
	if (this.render_curved_connections) //splines
	{
		ctx.moveTo(a[0],a[1]);
		ctx.bezierCurveTo(a[0] + dist*0.25, a[1], b[0] - dist*0.25 , b[1], b[0] ,b[1] );
	}
	else //lines
	{
		ctx.moveTo(a[0]+10,a[1]);
		ctx.lineTo(((a[0]+10) + (b[0]-10))*0.5,a[1]);
		ctx.lineTo(((a[0]+10) + (b[0]-10))*0.5,b[1]);
		ctx.lineTo(b[0]-10,b[1]);
	}

	if (this.render_connections_border && this.scale > 0.6*this.uiRatio*this.pixelRatio)
	{
		ctx.strokeStyle = LiteGraph.link_type_colors.border; // link border
		ctx.stroke();
	}

	ctx.lineWidth = this.connections_width;
	ctx.fillStyle = ctx.strokeStyle = color;
	ctx.stroke();

	//render arrow
	if ( this.render_connection_arrows && this.scale > 0.6*this.uiRatio*this.pixelRatio )
	{
		//get two points in the bezier curve
		var pos = this.computeConnectionPoint(a,b,0.5);
		var pos2 = this.computeConnectionPoint(a,b,0.51);
		var angle = 0;
		if ( this.render_curved_connections ) angle = -Math.atan2( pos2[0] - pos[0], pos2[1] - pos[1]);
			else angle = b[1] > a[1] ? 0 : Math.PI;

		ctx.save();
		ctx.translate(pos[0],pos[1]);
		ctx.rotate(angle);
		ctx.beginPath();
		ctx.moveTo(-5,-5);
		ctx.lineTo(0,+5);
		ctx.lineTo(+5,-5);
		ctx.fill();

		if (this.render_connections_border && this.scale > 0.6)
		{
			var halfline = this.connections_width/2;
			ctx.strokeStyle = LiteGraph.link_type_colors.border; // link border
			ctx.lineWidth = 1;
			ctx.beginPath();
			
			ctx.moveTo(-halfline-0.5, -5);
			ctx.lineTo(-5, -5);
			ctx.lineTo(-halfline-0.7, 4.5-halfline*2);
			ctx.stroke();
			ctx.beginPath();
			ctx.moveTo(halfline+0.5, -5);
			ctx.lineTo(5, -5);
			ctx.lineTo(halfline+0.7, 4.5-halfline*2);
			ctx.stroke();
		}

		ctx.restore();
	}
}

LGraphCanvas.prototype.computeConnectionPoint = function(a,b,t)
{
	var dist = distance(a,b);
	var p0 = a;
	var p1 = [ a[0] + dist*0.25, a[1] ];
	var p2 = [ b[0] - dist*0.25, b[1] ];
	var p3 = b;

	var c1 = (1-t)*(1-t)*(1-t);
	var c2 = 3*((1-t)*(1-t))*t;
	var c3 = 3*(1-t)*(t*t);
	var c4 = t*t*t;

	var x = c1*p0[0] + c2*p1[0] + c3*p2[0] + c4*p3[0];
	var y = c1*p0[1] + c2*p1[1] + c3*p2[1] + c4*p3[1];
	return [x,y];
}

LGraphCanvas.prototype.resize = function(width, height)
{
	if (!width && !height)
	{
		var parent = this.canvas.parentNode;
		width = parent.offsetWidth;
		height = parent.offsetHeight;
	}

	this.canvas.width = width*this.pixelRatio;
	this.canvas.height = height*this.pixelRatio;
	this.bgcanvas.width = width*this.pixelRatio;
	this.bgcanvas.height = height*this.pixelRatio;
	this.canvas.style.width = width+"px";
	this.canvas.style.height = height+"px";
	this.bgcanvas.style.width = width+"px";
	this.bgcanvas.style.height = height+"px";
	this.draw(true,true);
}

LGraphCanvas.prototype.onNodeSelectionChange = function(node)
{
	//disabled
	//if (this.node_in_panel) this.showNodePanel(node);
}

LGraphCanvas.prototype.touchHandler = function(event)
{
    var touches = event.changedTouches, first = touches[0], type = "";
	switch(event.type)
    {
        case "touchstart":	type = "mousedown";	break;
        case "touchmove":	type = "mousemove";	break;
        case "touchend":	type = "mouseup";	break;
        default: return;
    }

	var window = this.getCanvasWindow();
	var document = window.document;
    
	var simulatedEvent = document.createEvent("MouseEvent");
	simulatedEvent.initMouseEvent(type, true, true, window, 1, first.screenX, first.screenY, first.clientX, first.clientY, false, false, false, false, 0/*left*/, null);
	first.target.dispatchEvent(simulatedEvent);
	event.preventDefault();
}

LGraphCanvas.prototype.trackpadgestureHandler = function(e)
{
	if (!this.graph || !this.allow_dragcanvas || this.selection_mode) return;
	e.preventDefault();
	this.adjustMouseEvent(e);

	if ( e.gestureType === "Scroll" )
	{
		var n = this.graph.getNodeOnPos(e.canvasX, e.canvasY, this.visible_nodes);
		if (e.altKey)
		{
			if (this.node_over && this.node_over.onMouseWheel)
			{
				e.wheelDeltaX = (Math.abs(e.deltaX) > Math.abs(e.deltaY))?e.deltaX:-e.deltaY;
				e.wheelDeltaY = e.wheelDeltaX;
				this.node_over.onMouseWheel(e);
			}
		}
		else
		{
			this.offset[0] += e.deltaX/this.scale;
			this.offset[1] += e.deltaY/this.scale;
			if (n) { if (!n.mouseOver) { n.mouseOver = true; this.node_over = n; if (n.onMouseEnter) n.onMouseEnter(e); } }
				else { if (this.node_over) { if (this.node_over.onMouseLeave) { this.node_over.onMouseLeave(e) } this.node_over.mouseOver = false;	this.node_over = null; }}
		}
	}
//	else if ( e.gestureType === "Rotate" ) { e.wheelDeltaY = -e.angle*10+0.0001; for(var i in this.selected_nodes) if (this.selected_nodes[i].onMouseWheel) { this.selected_nodes[i].onMouseWheel(e) }}
	else if ( e.gestureType === "Zoom" ) { this.setZoom( this.scale*(1+e.scaleFactor), [ e.localX, e.localY ] ) }
	else if ( e.gestureType === "SmartZoom" ) { this.setZoom( this.uiRatio * this.pixelRatio, [ e.localX, e.localY ] ) }
	
	this.dirty_canvas = true;
	this.dirty_bgcanvas = true;

	return false;
}

/* CONTEXT MENU ********************/

LGraphCanvas.onMenuAdd = function(node, e, prev_menu, canvas, first_event )
{
	var window = canvas.getCanvasWindow();

	var values = LiteGraph.getNodeTypesCategories();
	var entries = [];
	for(var i in values)
	{
		if ( values[i] && ( values[i] !== "Macros" ) ) entries.push({ value: values[i], content: lang.getTranslation(values[i]) , is_menu: true });
		if ( values[i] === "Widget" ) entries.push(null);
	}
	if (entries[entries.length-1] === null) entries.pop();

	var menu = LiteGraph.createContextualMenu(entries, {event: e, callback: inner_clicked, from: prev_menu}, window);

	function inner_clicked(v, e)
	{
		var category = v.value;
		var node_types = LiteGraph.getNodeTypesInCategory(category);
		var values = [];
		for(var i in node_types)
			values.push( { content: lang.getTranslation(node_types[i].title), value: node_types[i].type, icon: node_types[i].iconsrc });

		LiteGraph.createContextualMenu(values, {event: e, callback: inner_create, from: menu}, window);
		return false;
	}

	function inner_create(v, e)
	{
		var node = LiteGraph.createNode( v.value );
		if (node)
		{
			node.pos = canvas.convertEventToCanvas(first_event);
			canvas.graph.add( node );
		}
	}

	return false;
}

LGraphCanvas.onMacroAdd = function(node, e, prev_menu, canvas, first_event)
{
	var window = canvas.getCanvasWindow();
	var that = this;
	var i;
	var values = ["Create","Import"];
	var entries = {};
	for(i=0; i<values.length; i++) { if ( values[i] ) entries[i] = { value: ">"+values[i], content: lang.getTranslation(values[i]), is_menu: false }; }

	var dir = (moi.filesystem.getAppDataDir)?moi.filesystem.getAppDataDir:moi.filesystem.getProcessDir;
	var path = dir()+document.URL.split(/moi:\/\/appdata\/(.*\/).*/g)[1].replace(/\//g,"\\")+"macros\\";

	if ( moi.filesystem.dirExists(path) )
	{
		var files = getFiles(path);
		if ( files.length > 0 ) entries[i++] = null;
		for ( var f in files ) { entries[i++] = { value: path+files[f]+'.nod', content: files[f], is_menu: false }; }
	}
	var menu = LiteGraph.createContextualMenu(entries, {event: e, callback: inner_clicked, from: prev_menu}, window);

	function getFolders(dir)
	{
		var output = [];
		return output;
	}

	function getFiles(path)
	{
		var output = [], f;
		var files = moi.filesystem.getFiles(path, "*.nod");
		for (f=0; f<files.length; f++) { output.push(files.item(f).match(/[^\\]*(?=\.[^.]+($|\?))/)[0]); }
		output = output.sort();
		return output;
	}

	function import_macro(loadFilePath)
	{
		var title, data = '', file = moi.filesystem.openFileStream( loadFilePath, 'r' );
		while ( !file.AtEOF ) data += file.readLine();
		file.close();
		node = LiteGraph.createNode( "Macros/Container" );
		if ( !node ) return;
		data = JSON.parse(data);
		if (data.macroTitle) { title = data.macroTitle; delete data.macroTitle; }
		node.subgraph.configure( data, false, true);
		node.subgraph.filename = loadFilePath;
		if ( title ) { node.title = title; }
		else
		{
			var name = moi.filesystem.getFileNameFromPath(loadFilePath);
			node.title = name.split(".").slice(0,-1).join(".");
		}
		node.computeSize();
		node.pos = canvas.convertEventToCanvas(first_event);
		canvas.graph.add( node );
		node.graph.setisChangedFlag(node.id);
	}

	function inner_clicked(v, e)
	{
		var node;
		if ( !v.is_menu && v.value === ">Create")
		{
			node = LiteGraph.createNode( "Macros/Container" );
			if ( node ) { node.pos = canvas.convertEventToCanvas(first_event); canvas.graph.add( node ); }
		}
		else if ( !v.is_menu && v.value === ">Import")
		{
			var loadFilePath = moi.filesystem.getOpenFileName(  lang.getTranslation('Import'), lang.getTranslation('MoI Nodeeditor macro')+' (*.nod)|*.nod' );
			if ( !loadFilePath ) return;
			import_macro(loadFilePath);
		}
		else
		{
			if ( v.is_menu ) { return }
				else { import_macro(v.value) }
		}
	}
	return false;
}

LGraphCanvas.onMacroAddOld = function(node, e, prev_menu, canvas, first_event)
{
	var node = LiteGraph.createNode( "Macros/Container" );
	if ( node )
	{
		node.pos = canvas.convertEventToCanvas(first_event);
		canvas.graph.add( node );
	}
}

LGraphCanvas.onMacroInputAdd = function(node, e, prev_menu, canvas, first_event)
{
	var node = LiteGraph.createNode( "Macros/Input" );
	if ( node )
	{
		node.pos = canvas.convertEventToCanvas(first_event);
		canvas.graph.add( node );
	}
}

LGraphCanvas.onMacroOutputAdd = function(node, e, prev_menu, canvas, first_event)
{
	var node = LiteGraph.createNode( "Macros/Output" );
	if ( node )
	{
		node.pos = canvas.convertEventToCanvas(first_event);
		canvas.graph.add( node );
	}
}

LGraphCanvas.onMenuNodePaste = function(node, e, prev_menu, canvas, first_event)
{
	canvas.graph.pasteNodes( LiteGraph.getClipboard(), canvas.convertEventToCanvas(first_event));
}

LGraphCanvas.onMenuCollapseAll = function()
{
}


LGraphCanvas.onMenuNodeEdit = function()
{
}

LGraphCanvas.onMenuNodeInputs = function(node, e, prev_menu)
{
	if (!node) return;

	var options = node.optional_inputs;
	if ( node.onGetInputs ) options = node.onGetInputs();
	if ( options ) if ( options.length > 0 )
	{
		var entries = [];
		for (var i in options)
		{
			var entry = options[i];
			var label = entry[0];
			if (entry[2] && entry[2].label)
				label = entry[2].label;
			entries.push({content: label, value: entry});
		}
		var menu = LiteGraph.createContextualMenu(entries, {event: e, callback: inner_clicked, from: prev_menu});
	}

	function inner_clicked(v)
	{
		if (!node) return;
		node.addInput( v.value[0], v.value[1], v.value[2]);
		node.setDirtyCanvas(true); // 2016
	}

	return false;
}

LGraphCanvas.onMenuNodeOutputs = function(node, e, prev_menu)
{
	if (!node) return;

	var options = node.optional_outputs;
	if (node.onGetOutputs)
		options = node.onGetOutputs();
	if (options)
	{
		var entries = [];
		for (var i in options)
		{
			var entry = options[i];
			if (node.findOutputSlot(entry[0]) != -1)
				continue; //skip the ones already on
			var label = entry[0];
			if (entry[2] && entry[2].label)
				label = entry[2].label;
			entries.push({content: label, value: entry});
		}
		if (entries.length)
			var menu = LiteGraph.createContextualMenu(entries, {event: e, callback: inner_clicked, from: prev_menu});
	}

	function inner_clicked(v)
	{
		if (!node)
			return;

		var value = v.value[1];

		if (value && (value.constructor === Object || value.constructor === Array)) //submenu
		{
			var entries = [];
			for(var i in value)
				entries.push({content: i, value: value[i]});
			LiteGraph.createContextualMenu(entries, {event: e, callback: inner_clicked, from: prev_menu});
			return false;
		}
		else
			node.addOutput(v.value[0], v.value[1], v.value[2]);
	}

	return false;
}

LGraphCanvas.onMenuNodeCollapse = function(node)
{
	node.flags.collapsed = !node.flags.collapsed;
	node.setDirtyCanvas(true,true);
}

LGraphCanvas.onMenuNodePin = function(node)
{
	node.pin();
}

LGraphCanvas.onMenuNodeColors = function(node, e, prev_menu)
{
	var values = [];
	for(var i in LGraphCanvas.node_colors)
	{
		var color = LGraphCanvas.node_colors[i];
		var value = {value:i, content:"<span style='display: block; color:"+color.color+"; background-color:"+color.bgcolor+"'>"+lang.getTranslation(i)+"</span>"};
		values.push(value);
	}
	LiteGraph.createContextualMenu(values, {event: e, callback: inner_clicked, from: prev_menu});

	function inner_clicked(v)
	{
		if (!node) return;
		var color = LGraphCanvas.node_colors[v.value];
		if (color)
		{
			node.color = color.color;
			node.bgcolor = ( color.bgcolor === LiteGraph.NODE_DEFAULT_BGCOLOR && node.type.indexOf("/Container") > 0 )?LiteGraph.NODE_MACRO_COLOR:color.bgcolor;
			node.setDirtyCanvas(true);
		}
	}

	return false;
}

LGraphCanvas.onMenuNodeRemove = function(node, e, menu, that)
{
	// if (node.removable == false) return;
	node.graph.removeNodes(node.id, that.selected_nodes);
	node.setDirtyCanvas(true,true);
}

LGraphCanvas.onMenuNodeClone = function(node)
{
	if (node.clonable == false) return;
	var newnode = node.clone();
	if (!newnode) return;
	newnode.pos = [node.pos[0]-20,node.pos[1]+20];
	node.graph.add(newnode);
	node.setDirtyCanvas(true,true);
}

LGraphCanvas.onMenuNodeCopy = function(node, e, menu, that)
{
	LiteGraph.setClipboard(node.graph.copyNodes(node.id, that.selected_nodes, node.pos, [0, -40]));
}

LGraphCanvas.onMenuNodeCut = function(node, e, menu, that)
{
	LiteGraph.setClipboard(node.graph.copyNodes(node.id, that.selected_nodes, node.pos, [0, -40]));
	node.graph.removeNodes(node.id, that.selected_nodes);
	node.setDirtyCanvas(true,true);
}

LGraphCanvas.node_colors = {
	"Default": { color:LiteGraph.NODE_DEFAULT_COLOR, bgcolor:LiteGraph.NODE_DEFAULT_BGCOLOR },
	"Red": { color:"#F89", bgcolor:"#934" },
	"Green": { color:"#6C6", bgcolor:"#363" },
	"Blue": { color:"#6CF", bgcolor:"#369" },
};

LGraphCanvas.prototype.getCanvasMenuOptions = function()
{
	var options = null;
	if ( this.getMenuOptions ) options = this.getMenuOptions();
	else
	{
		options = [{content:lang.getTranslation("Node"), is_menu: true, callback: LGraphCanvas.onMenuAdd }];
		if ( LiteGraph.macrosActivated )
		{
		 	options = options.concat([{content:lang.getTranslation("Macro"), is_menu: true, callback: LGraphCanvas.onMacroAdd }]);
			if (this._graph_stack && this._graph_stack.length > 0)
			{
				var m = [
					null,
					{content:lang.getTranslation("Input"), callback: LGraphCanvas.onMacroInputAdd },
					{content:lang.getTranslation("Output"), callback: LGraphCanvas.onMacroOutputAdd },
					{content:lang.getTranslation("Close"), callback: this.bindFunction(this.closeSubgraph, this) }
				];
				options = options.concat(m);
			}
		}
		if ( LiteGraph.getClipboard() )
		options = options.concat([null, {content:lang.getTranslation("Paste"), is_menu: false, callback: LGraphCanvas.onMenuNodePaste }]);
	}

	if (this.getExtraMenuOptions)
	{
		var extra = this.getExtraMenuOptions(this);
		if (extra)
		{
			extra.push(null);
			options = extra.concat( options );
		}
	}

	return options;
}

LGraphCanvas.prototype.getNodeMenuOptions = function(node, event)
{
	var options = null;

	if (node.getMenuOptions) options = node.getMenuOptions(this);
	else options = [
			{content:lang.getTranslation("Inputs"), is_menu: true, disabled:true, callback: LGraphCanvas.onMenuNodeInputs },
			{content:lang.getTranslation("Outputs"), is_menu: true, disabled:true, callback: LGraphCanvas.onMenuNodeOutputs },
//			null,
//			{content:lang.getTranslation("Collapse"), callback: LGraphCanvas.onMenuNodeCollapse },
			{content:lang.getTranslation("Colors"), is_menu: true, callback: LGraphCanvas.onMenuNodeColors },
			null
		];
//	options.push({content:lang.getTranslation("Clone"), disabled:(node.clonable === false), callback: LGraphCanvas.onMenuNodeClone });
	if ( event.altKey) options.push({content:lang.getTranslation("Cut"), disabled:false, callback: LGraphCanvas.onMenuNodeCut });
		else options.push({content:lang.getTranslation("Copy"), disabled:false, callback: LGraphCanvas.onMenuNodeCopy });

	if ( node.removable !== false ) options.push(null,{content:lang.getTranslation("Remove"), callback: LGraphCanvas.onMenuNodeRemove });

	if (node.onGetInputs)
	{
		var inputs = node.onGetInputs();
		if (inputs && inputs.length) options[0].disabled = false;
	}

	if (node.onGetOutputs)
	{
		var outputs = node.onGetOutputs();
		if (outputs && outputs.length) options[1].disabled = false;
	}

	if (node.getExtraMenuOptions)
	{
		var extra = node.getExtraMenuOptions(this);
		if (extra) { extra.push(null); options = extra.concat( options ); }
	}
	return options;
}

LGraphCanvas.prototype.processContextualMenu = function(node, event)
{
	var that = this;
	var win = this.getCanvasWindow();

	var menu_info = null;

	//check if mouse is in input
	var slot = null;
	if (node) slot = node.getSlotInPosition( event.canvasX, event.canvasY );

	if (slot)
	{
		var slottitle = "";
		if ( slot.input ) slottitle = slot.input.name;
		if ( slot.output ) slottitle = slot.output.name;
		menu_info = slot.locked ? [ slottitle+" (locked)" ] : { "Remove Slot": slot };
	}
	else menu_info = node ? this.getNodeMenuOptions(node, event) : this.getCanvasMenuOptions();

	//show menu
	if (!menu_info) return;

	var menu = LiteGraph.createContextualMenu( menu_info, {event: event, callback: inner_option_clicked}, win);

	function inner_option_clicked(v,e)
	{
		if (!v) return;
		if (v == slot)
		{
			if (v.input) node.removeInput( slot.slot, slot.input.name );
			else if (v.output) node.removeOutput( slot.slot, slot.output.name );
			return;
		}
		if (v.callback) return v.callback(node, e, menu, that, event );
	}
}


//API *************************************************
//function roundRect(ctx, x, y, width, height, radius, radius_low) {
CanvasRenderingContext2D.prototype.roundRect = function (x, y, width, height, radius, radius_low)
{
	if ( radius === undefined ) radius = 5;
	if ( radius_low === undefined ) radius_low  = radius;
	
	this.beginPath();
	this.moveTo(x + radius, y);
	this.lineTo(x + width - radius, y);
	this.quadraticCurveTo(x + width, y, x + width, y + radius);
	
	this.lineTo(x + width, y + height - radius_low);
	this.quadraticCurveTo(x + width, y + height, x + width - radius_low, y + height);
	this.lineTo(x + radius_low, y + height);
	this.quadraticCurveTo(x, y + height, x, y + height - radius_low);
	this.lineTo(x, y + radius);
	this.quadraticCurveTo(x, y, x + radius, y);
}

function compareObjects(a,b)
{
	for(var i in a) if (a[i] != b[i]) return false;
	return true;
}

function distance(a,b) { return Math.sqrt( (b[0] - a[0]) * (b[0] - a[0]) + (b[1] - a[1]) * (b[1] - a[1]) ); }

function colorToString(c) { return "rgba(" + Math.round(c[0] * 255).toFixed() + "," + Math.round(c[1] * 255).toFixed() + "," + Math.round(c[2] * 255).toFixed() + "," + (c.length == 4 ? c[3].toFixed(2) : "1.0") + ")"; }

function isInsideRectangle(x,y, left, top, width, height) { if ( left < x && (left + width) > x && top < y && (top + height) > y ) { return true } else { return false } }

//[minx,miny,maxx,maxy]
function growBounding(bounding, x, y)
{
	if (x < bounding[0]) bounding[0] = x;
	else if (x > bounding[2]) bounding[2] = x;

	if (y < bounding[1]) bounding[1] = y;
	else if (y > bounding[3]) bounding[3] = y;
}

//point inside boundin box
function isInsideBounding(p,bb) { if (p[0] < bb[0][0] || p[1] < bb[0][1] || p[0] > bb[1][0] || p[1] > bb[1][1]) { return false } else { return true } }

//boundings overlap, format: [start,end]
function overlapBounding(a,b) { if ( a[0] > b[2] || a[1] > b[3] || a[2] < b[0] || a[3] < b[1] ) { return false } else { return true }}

//Convert a hex value to its decimal value - the inputted hex must be in the
//	format of a hex triplet - the kind we use for HTML colours. The function
//	will return an array with three values.
function hex2num(hex) {
	if (hex.charAt(0) == "#") hex = hex.slice(1); //Remove the '#' char - if there is one.
	hex = hex.toUpperCase();
	var hex_alphabets = "0123456789ABCDEF";
	var value = new Array(3);
	var k = 0;
	var int1,int2;
	for(var i=0;i<6;i+=2)
	{
		int1 = hex_alphabets.indexOf(hex.charAt(i));
		int2 = hex_alphabets.indexOf(hex.charAt(i+1));
		value[k] = (int1 * 16) + int2;
		k++;
	}
	return(value);
}
//Give a array with three values as the argument and the function will return
//	the corresponding hex triplet.
function num2hex(triplet) {
	var hex_alphabets = "0123456789ABCDEF";
	var hex = "#";
	var int1,int2;
	for(var i=0;i<3;i++)
	{
		int1 = triplet[i] / 16;
		int2 = triplet[i] % 16;
		hex += hex_alphabets.charAt(int1) + hex_alphabets.charAt(int2); 
	}
	return(hex);
}

/* LiteGraph GUI elements *************************************/
LiteGraph.createContextualMenu = function( values, options, ref_window)
{
	options = options || {};
	this.options = options;

	//allows to create graph canvas in separate window
	ref_window = ref_window || window;

	if ( !options.from ) {LiteGraph.closeAllContextualMenus() }
	else { var menus = document.querySelectorAll(".graphcontextualmenu"); for (var key in menus) if (menus[key].previousSibling == options.from) menus[key].closeMenu();} //closing submenus

	var root = ref_window.document.createElement("div");
	root.className = "graphcontextualmenu graphmenubar-panel";
	this.root = root;
	var style = root.style;

	style.minWidth = "0.8in";
	style.minHeight = "0.2in";
	style.borderRadius = "0.07in";
	style.position = "fixed";
	style.top = "1in";
	style.left = "1in";
	style.color = this.MENU_TEXT;
	style.padding = "0.03in";
	style.border = "1px solid "+this.MENU_BORDER;
	style.borderBottom = "1px solid " + this.MENU_BORDER_SHADOW;
	style.borderRight = style.borderBottom;
	style.boxShadow = "0.08in 0.08in 0.2in -0.0in "+this.MENU_BORDER_SHADOW;
	style.backgroundColor = this.MENU_BACKGROUND;

	//title
	if (options.title)
	{
		var element = document.createElement("div");
		element.className = "graphcontextualmenu-title";
		element.innerHTML = options.title;
		root.appendChild(element);
	}
	
	//avoid a context menu in a context menu
	root.addEventListener("contextmenu", function(e) { e.preventDefault(); return false; });
	root.addEventListener("mousewheel", function(e) { e.preventDefault(); return false; });

	for(var i in values)
	{
		var item = values[i];
		var icon = "";
		var element = ref_window.document.createElement("div");
		element.className = "graphmenu-entry";

		if (item == null)
		{
			element.className = "graphmenu-entry separator";
			element.style.backgroundColor = this.MENU_BORDER_SHADOW;
			element.style.borderBottom = "1px solid " + this.MENU_BORDER;
			root.appendChild(element);
			continue;
		}

		if ( item.is_menu ) element.className += " submenu";

		if ( item.disabled ) element.className += " disabled";

		element.style.cursor = "pointer";
		element.data = item;
		if ( typeof(item) == "string" )
			element.innerHTML = (values.constructor == Array) ? values[i] : i;
		else
		{
			element.innerHTML = item.content ? item.content : i;
			icon = (item.icon)?"<img class='graphmenuicon' src='"+item.icon+"'>":"<div class='hiddengraphmenuicon'></div>";
		}
		
		element.innerHTML = "<div class='graphmenutext'>"+icon+"</div>" + "<div class='graphmenutext'>"+element.innerHTML+"</div>";
		// element.innerHTML = "<img class='graphmenuicon' src='"+icon+"'>" + "<div class='graphmenutext'>"+element.innerHTML+"</div>";
		element.addEventListener("click", on_click );
		root.appendChild(element);
	}

	root.addEventListener("mouseover", function() { this.mouse_inside = true });

	root.addEventListener("mouseout", function(e) {
		var aux = e.relatedTarget || e.toElement;
		if ( aux == null ) return;
		while ( aux != this && aux != ref_window.document )
			aux = aux.parentNode;

		if ( aux == this ) return;
		this.mouse_inside = false;
		if ( !this.block_close )
			this.closeMenu();
	});

	//insert before checking position
	ref_window.document.body.appendChild(root);

	var root_rect = root.getClientRects()[0];

	//link menus
	if ( options.from )
	{
		options.from.block_close = true;
	}
	var left = options.left || 0;
	var top = options.top || 0;
	
	if ( options.event )
	{
		left = (options.event.pageX - 10);
		top = (options.event.pageY - 5);
		if (options.left) left = options.left;
        	var rect = ref_window.document.body.getClientRects()[0];
        
		if ( options.from )
		{
			var parent_rect = options.from.getClientRects()[0];
			left = parent_rect.left + parent_rect.width-30;
		}
		
		if ( left > (rect.width - root_rect.width - 10) ) left = (rect.width - root_rect.width - 10);
		if ( top > (rect.height - root_rect.height - 10) ) top = (rect.height - root_rect.height - 10);
	}
	
	root.style.left = left + "px";
	root.style.top = top  + "px";

	function on_click(e)
	{
		var close = true;
		if ( options.callback )
		{
			var ret = options.callback.call(root, this.data, e );
			if ( ret !== undefined ) close = ret;
		}

		if ( close ) LiteGraph.closeAllContextualMenus();
		//root.closeMenu();
	}

	root.closeMenu = function()
	{
		if (options.from)
		{
			options.from.block_close = false;
			if (!options.from.mouse_inside) options.from.closeMenu();
		}
		if (this.parentNode) ref_window.document.body.removeChild(this);
	};
	return root;
}

LiteGraph.closeAllContextualMenus = function()
{
	var elements = document.querySelectorAll(".graphcontextualmenu");
	if (!elements.length) return;

	var result = [];
	for(var i = 0; i < elements.length; i++) result.push(elements[i]);

	for(var i in result) if (result[i].parentNode) result[i].parentNode.removeChild( result[i] );
}

LiteGraph.extendClass = function ( target, origin )
{
	for(var i in origin) //copy class properties
	{
		if (target.hasOwnProperty(i)) continue;
		target[i] = origin[i];
	}

	if (origin.prototype) //copy prototype properties
		for(var i in origin.prototype) //only enumerables
		{
			if (!origin.prototype.hasOwnProperty(i))	continue;
			if (target.prototype.hasOwnProperty(i)) continue; //avoid overwritting existing ones
			//copy getters
			if (origin.prototype.__lookupGetter__(i)) target.prototype.__defineGetter__(i, origin.prototype.__lookupGetter__(i));
				else target.prototype[i] = origin.prototype[i];
			//and setters
			if (origin.prototype.__lookupSetter__(i)) target.prototype.__defineSetter__(i, origin.prototype.__lookupSetter__(i));
		}
}

LiteGraph.scaleCssFont = function(fontString, scale)
{
	var p=-1, i, stAr = fontString.split(" ");
	for (i=0; i<stAr.length; i++) if (stAr[i].indexOf("in")>0) { p=i }
	if ( p<0 || scale === 0 ) return fontString;
	i = stAr[p].replace("in", "") * 1.0;
	if ( i > 0 ) stAr[p] = i/scale+"in";
	return stAr.join(" ");
}

LiteGraph.JSONprettify = function (obj, options)
{
	var get = function (options, name, defaultValue) { return (name in options ? options[name] : defaultValue) }
	options = options || {};
	var indent = get(options, 'indent', '  ');
	var maxLength = (indent === '' ? Infinity : get(options, 'maxLength', 100));
	var prettify = function (string)
	{
		var stringOrChar = /("(?:[^"]|\\.)*")|[:,]/g
		return string.replace(stringOrChar, function (match, string) { return string ? match : match + ' ' });
	}
	var stringify = function (obj, cIndent, reserved)
	{
		if (obj && typeof obj.toJSON === 'function') obj = obj.toJSON();
		var string = JSON.stringify(obj);
		if (string === undefined) { return string }

		var length = maxLength - cIndent.length - reserved;
		if (string.length <= length)
		{
			var prettified = prettify(string);
	  		if (prettified.length <= length) return prettified;
		}

		if (typeof obj === 'object' && obj !== null)
		{
			var nextIndent = cIndent + indent;
			var items = [];
			var delimiters;
			var isSimpleArray = true;
			var comma = function (array, index) { return (index === array.length - 1 ? 0 : 1) }

			if (Array.isArray(obj))
			{
				for (var index = 0; index < obj.length; index++) if ( typeof obj[index] !== 'number' && typeof obj[index] !== 'string') { isSimpleArray = false; break; }
				if ( isSimpleArray ) return string;
				for (var index = 0; index < obj.length; index++) items.push(stringify(obj[index], nextIndent, comma(obj, index)) || 'null');
				delimiters = '[]';
			}
	  		else
			{
				Object.keys(obj).forEach(function (key, index, array)
				{
					var keyPart = JSON.stringify(key) + ': ';
					var value = stringify(obj[key], nextIndent, keyPart.length + comma(array, index));
		  			if (value !== undefined) items.push(keyPart + value);
				});
				delimiters = '{}';
			}
			if (items.length > 0) { return [ delimiters[0], indent + items.join(',\n' + nextIndent), delimiters[1]].join('\n' + cIndent) }
		}
		return string;
	}
	return stringify(obj, '', 0);
}

var console = { log: function(st){moi.log(st+"\n");}, json: function(st){moi.log(JSON.stringify(st)+"\n");}, error: function(st){moi.log("ERROR!!! "+st+"\n");} };