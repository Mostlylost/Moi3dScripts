//	Nodeedit for Moment of inspiration 1.0, Max Smirnov Copyright (C) 2018
//  Initialization lib

function getDisplayInfo()
{
	var info = {};
	var div = document.createElement("div"); div.style.width="1in";
	var b = document.getElementsByTagName("body")[0]; b.appendChild(div);
	var dpi = document.defaultView.getComputedStyle(div, null).getPropertyValue('width'); b.removeChild(div);
	if (typeof dpi === "string") { dpi = dpi.replace(/[^0-9.]/g, "")*1.0 }
	info.uiRatio = dpi/96;
	info.pixelRatio = window.devicePixelRatio || 1;
	return info;
}

function updateWindowSize()
{
	editor.graphcanvas.resize(document.body.clientWidth, document.body.clientHeight-document.body.querySelector(".header").clientHeight-2.0);
}

function loadDefaultNodes()
{
	var node_output = LiteGraph.createNode("Basic/Output");
	node_output.pos = [800,100];
	graph.add(node_output);
}

function close()
{
	moi.command.setOption('nodeEditorData', JSON.stringify(graph.serialize()), false);
	graph.sendEventToAllNodes("onClear");
}

lang.detect();
LiteGraph.node_images_path = "nodes/imgs/";
var displayInfo = getDisplayInfo();
var editor = new LiteGraph.Editor("main", displayInfo.uiRatio, displayInfo.pixelRatio);
window.graph = editor.graph;
window.addEventListener("resize", updateWindowSize);
window.addEventListener("mousewheel", function() { this.scrollBy(0,-10) }, false);
var nodeEditorData="{}", loadDefaults = false;
try { nodeEditorData =  moi.command.getOption('nodeEditorData', false); } catch (e) { loadDefaults = true }
if (NeParameters.isnew) { loadDefaults = true; }
if (loadDefaults) { loadDefaultNodes() } else { graph.configure( JSON.parse(nodeEditorData), false) }
updateWindowSize();
document.body.onunload=close;