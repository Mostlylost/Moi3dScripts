//	Nodeedit for Moment of inspiration 1.0, Max Smirnov Copyright (C) 2018
//  Editor lib

function Editor(container_id, uiRatio, pixelRatio, options)
{
	//fill container
	var html = "<div class='header'><div class='tools tools-left'></div><div class='tools tools-right'></div></div>";
	html += "<div class='content'><div class='editor-area'><canvas class='graphcanvas' width='1000' height='500' tabindex=0></canvas></div>";
	html += "<div class='node-panel' style='display: block'><div class='node-panel-list'></div></div></div>";

	var root = document.createElement("div");
	this.root = root;
	root.className = "litegraph-editor";
	root.innerHTML = html;

	var canvas = root.querySelector(".graphcanvas");
	//create graph
	var graph = this.graph = new LGraph(options);
	this.uiRatio = uiRatio || 1;
	this.pixelRatio = pixelRatio || 1;

	var graphcanvas = this.graphcanvas = new LGraphCanvas(canvas, graph, this.uiRatio, this.pixelRatio);
	graphcanvas.background_image = this.generateBackground();

	this.images = this.generateIcons();
	
	graph.onAfterExecute = function () { graphcanvas.draw(true) };
	this.graphcanvas.infopanel = root.querySelector(".node-panel");
	this.graphcanvas.infopanel_list = root.querySelector(".node-panel-list");
	this.graphcanvas.infopanel_visible = (this.graphcanvas.infopanel.style.display === "block");

	//add stuff
	this.onNB = this.bindFunction(this.onNewButton, this);

	this.addToolsLongpressButton("newsession_button", lang.getTranslation("New"), this.images.iconnew, this.onNB, ".tools-left", 700);
	this.addToolsButton("back_button", lang.getTranslation("Back"), this.images.iconback, this.bindFunction(this.onBackButton, this), ".tools-left", { display: "none" });
	this.addToolsButton("loadsession_button", lang.getTranslation("Load"), this.images.iconload, this.bindFunction(this.onLoadButton, this), ".tools-left");
	this.addToolsButton("savesession_button", lang.getTranslation("Save"), this.images.iconsave, this.bindFunction(this.onSaveButton, this), ".tools-left");
	this.addToolsButton("applyobjects_button", lang.getTranslation("Apply"), this.images.iconapply, this.bindFunction(this.onApplyButton, this), ".tools-left");

	this.addToolsButton("playnode_button", lang.getTranslation("Run"), this.images.iconplay, this.bindFunction(this.onPlayButton, this), ".tools-right");
	this.addToolsButton("playstepnode_button", lang.getTranslation("Step"), this.images.iconplaystep, this.bindFunction(this.onPlayStepButton, this), ".tools-right");
	this.addToolsButton("properties_button", "", this.images.iconinfo, this.bindFunction(this.onPropertiesButton, this), ".tools-right");

	this.mousewheel_callback = this.bindFunction(this.processMouseWheel, this);
	this.info_mousewheel_callback = this.bindFunction(this.processMouseWheelInfo, this);

	this.panel = this.root.querySelector(".node-panel");

	this.root.querySelector(".header").addEventListener("mousewheel", this.mousewheel_callback, false);
	this.panel.addEventListener("mousewheel", this.info_mousewheel_callback, false);


	//append to DOM
	var parent = document.getElementById(container_id);
	parent.style.backgroundColor = scheme.getColor('editor_background');
	document.body.style.backgroundColor = parent.style.backgroundColor;

	if (parent) parent.appendChild(root);
	parent.querySelector(".header").style.backgroundColor = scheme.getColor('editor_menu_background');

	// graphcanvas.resize();
	graphcanvas.draw(true, true);
}

Editor.prototype.bindFunction = function (func, context)
{
	return function () { return func.apply(context, arguments);	};
}

Editor.prototype.addToolsButton = function (id, name, icon, callback, container, style)
{
	if (!container) container = ".tools";
	var button = this.createButton(name, icon);
	button.id = id;
	button.addEventListener("click", callback, true);
	
	if ( style ) for ( var s in style ) button.style[s] = style[s];
	this.root.querySelector(container).appendChild(button);
	return button;
}

Editor.prototype.addToolsLongpressButton = function (id, name, icon, callback, container, timeout, style )
{
	if (!container) container = ".tools";
	var button = this.createButton(name, icon);
	button.id = id;
	button.addEventListener("mousedown", function(e){ if (e && e.altKey) { callback(true) } else { this.pressTimer = window.setTimeout(callback, timeout)}}, true);
	button.addEventListener("mouseup", function(){ window.clearTimeout(this.pressTimer)});
	
	if ( style ) for ( var s in style ) button.style[s] = style[s];
	this.root.querySelector(container).appendChild(button);
	return button;
}

Editor.prototype.createPanel = function (title)
{
	var root = document.createElement("div");
	root.className = "dialog";
	root.innerHTML = "<div class='dialog-header'><span class='dialog-title'>" + title + "</span></div><div class='dialog-content'></div><div class='dialog-footer'></div>";
	root.header = root.querySelector(".dialog-header");
	root.content = root.querySelector(".dialog-content");
	root.footer = root.querySelector(".dialog-footer");
	return root;
}

Editor.prototype.createButton = function (name, icon)
{
	var button = document.createElement("button");
	button.style.color = scheme.getColor('editor_menu_buttons');
//	button.style.backgroundColor = scheme.getColor('editor_menu_buttons_bg');
	if (icon && icon.url && icon.size) button.innerHTML = "<img style='height:"+icon.size+"px; width:"+icon.size+"px;' src='" + icon.url + "'/> ";
	button.innerHTML = button.innerHTML + "<span>"+name+"</span>";
	return button;
}

Editor.prototype.onNewButton = function (newWindow)
{
	if (newWindow)
	{
		NeParameters.id = Math.floor(Math.random()*1e8);
		NeParameters.isnew = true;
		moi.ui.createDialog( newWindowUrl(NeParameters), 'resizeable,defaultWidth:680,defaultHeight:420', moi.ui.mainWindow );
		return;
	}
	if ( graph.status !== LGraph.STATUS_STOPPED ) this.onPlayButton();
	this.graphcanvas.deselectAllNodes();
	this.graph.sendEventToAllNodes("onClear");
	this.graph.configure( "{}", false);
	loadDefaultNodes();
}

Editor.prototype.onBackButton = function ()
{
	this.graphcanvas.closeSubgraph();
}

Editor.prototype.onLoadButton = function ()
{
	var loadFilePath = moi.filesystem.getOpenFileName(  lang.getTranslation('Open'),  lang.getTranslation('MoI Nodeeditor files')+' (*.nod)|*.nod' );
	if ( !loadFilePath ) return false;
	if ( graph.status !== LGraph.STATUS_STOPPED ) this.onPlayButton();
	this.graphcanvas.deselectAllNodes();
	while ( this.graphcanvas.graph._is_subgraph ) this.graphcanvas.closeSubgraph();
	var data = '', file = moi.filesystem.openFileStream( loadFilePath, 'r' );
	while ( !file.AtEOF ) data += file.readLine();
	file.close();
	this.graph.sendEventToAllNodes("onClear");
	this.graph.configure( JSON.parse(data), false, true);
	this.graph.filename = loadFilePath;
}

Editor.prototype.onSaveButton = function ()
{
	if (this.graph.blocked) return;
	var saveFilePath = moi.filesystem.getSaveFileName( lang.getTranslation('Save as')+' ..',  lang.getTranslation('MoI Nodeeditor files')+' (*.nod)|*.nod' );
	if ( !saveFilePath ) return false;
	if ( this.graph.status !== LGraph.STATUS_STOPPED ) this.onPlayButton();
	var file = moi.filesystem.openFileStream( saveFilePath, 'w' );
	file.writeLine(LiteGraph.JSONprettify(this.graph.serialize(), {"indent":"	", 'maxLength':150}));
	file.close();
	this.graph.filename = saveFilePath;
	this.graph.setDirtyCanvas(true,true);
}

Editor.prototype.onPlayButton = function ()
{
	if (this.graph.blocked) return;
	if (this.graph.status === LGraph.STATUS_STOPPED) { this.Play() } else { this.Stop() }
}

Editor.prototype.Play = function ()
{
	var button = this.root.querySelector("#playnode_button");
	button.innerHTML = "<img style='height:"+this.images.iconstop.size+"px; width:"+this.images.iconstop.size+"px;' src='" + this.images.iconstop.url + "'/> <span>"+lang.getTranslation("Stop")+"</span>";
	this.graph.start((moi.majorVersionNumber>3)?5:20);
}

Editor.prototype.Stop = function ()
{
	var button = this.root.querySelector("#playnode_button");
	button.innerHTML = "<img style='height:"+this.images.iconplay.size+"px; width:"+this.images.iconplay.size+"px;' src='" + this.images.iconplay.url + "'/> <span>"+lang.getTranslation("Run")+"</span>";
	this.graph.stop();
}

Editor.prototype.onPlayStepButton = function ()
{
	if (this.graph.blocked) return;
	this.graph.runStep();
	this.graphcanvas.draw(true, true);
}

Editor.prototype.onApplyButton = function ()
{
	if (this.graph.blocked) return;
	this.graph.runStep();
	this.graphcanvas.draw(true, true);
	this.graph.sendEventToAllNodes("onApply");
}

Editor.prototype.onPropertiesButton = function (e)
{
	if (e.altKey) { this.graphcanvas.io_info = !this.graphcanvas.io_info; this.graphcanvas.dirty_canvas = true; return }
	this.graphcanvas.onSwitchNodePanel();
}

Editor.prototype.processMouseWheel = function (e)
{
	e.preventDefault();
	return false;
}

Editor.prototype.processMouseWheelInfo = function (e)
{
	var delta = e.wheelDeltaY/120*25;
	if (delta>25) delta=25;
	if (delta<-25) delta=-25;
	this.panel.scrollTop -= delta;
	e.preventDefault();
	return false;
}

Editor.prototype.generateBackground = function()
{
	var bgvcanvas = document.createElement("canvas");
//	var bgsize = 100 * ( this.uiRatio || 1);
	var bgsize = 100;
	var bgstep = bgsize / 10;
	bgvcanvas.height = bgvcanvas.width  = bgsize;

	var bgvctx = bgvcanvas.getContext("2d");
	bgvctx.fillStyle = scheme.getColor('editor_background');
	bgvctx.rect(0, 0, bgsize, bgsize); bgvctx.fill();

	bgvctx.strokeStyle = scheme.getColor('editor_grid');
	for ( var i=0; i<10; i++ )
	{
		bgvctx.beginPath();		bgvctx.moveTo(0.5, i*bgstep+0.5);	bgvctx.lineTo(bgsize+0.5, i*bgstep+0.5);	bgvctx.stroke();
		bgvctx.beginPath();		bgvctx.moveTo(i*bgstep+0.5,0.5);	bgvctx.lineTo(i*bgstep+0.5,bgsize+0.5);		bgvctx.stroke();
	}

//	bgvctx.beginPath();		bgvctx.moveTo(1.5, 1.5);	bgvctx.lineTo(bgsize+0.5, 1.5);		bgvctx.stroke();
//	bgvctx.beginPath();		bgvctx.moveTo(1.5, 1.5);	bgvctx.lineTo(1.5, bgsize+0.5);		bgvctx.stroke();
	var bgr = bgvcanvas.toDataURL("image/png",0);
	return bgr
}
Editor.prototype.generateIcons = function()
{
	var output = {};
	var uiRatio = this.uiRatio || 1;
	var pixelRatio = this.pixelRatio || 1;
	var uipxRatio = uiRatio * pixelRatio;
	var iconsize = 32 * uiRatio;
	
	var icanvas = document.createElement("canvas");
	var ctx = icanvas.getContext("2d");
	icanvas.height = icanvas.width  = iconsize * pixelRatio;

	ctx.globalAlpha = 1.0;
	ctx.fillStyle = scheme.getColor('editor_menu_buttons');

	var drawCircle = function(ctx, scale, cx, cy, r, dflag) { ctx.globalCompositeOperation = (dflag)?'source-over':'destination-out'; ctx.beginPath(); ctx.arc(cx*scale, cy*scale, r*scale, 0, 2 * Math.PI, false); ctx.fill(); }
	var drawPoly = function(ctx, scale, pts, dflag) { var i; for (i=0; i<pts.length; i++) {pts[i] *= scale} ctx.globalCompositeOperation = (dflag)?'source-over':'destination-out'; ctx.beginPath(); ctx.moveTo(pts[0],pts[1]); for (i=2; i<pts.length; i+=2) ctx.lineTo(pts[i],pts[i+1]); ctx.closePath(); ctx.fill(); }
	var getIcon = function(icanvas, ctx) { var o = {url:icanvas.toDataURL("image/png",0)}; ctx.clearRect(0,0,(icanvas.width)-1,(icanvas.height)-1); return o }

	drawCircle(ctx, uipxRatio, 16, 16, 13, true); drawCircle(ctx, uipxRatio, 16, 16, 10, false);
	output.iconnew = getIcon(icanvas, ctx);

	drawCircle(ctx, uipxRatio, 16, 16, 13, true); drawPoly(ctx, uipxRatio, [20,24,20,17,24,17,16,6,8,17,12,17,12,24], false);
	output.iconload = getIcon(icanvas, ctx);

	drawCircle(ctx, uipxRatio, 16, 16, 13, true); drawPoly(ctx, uipxRatio, [20,8,20,15,24,15,16,26,8,15,12,15,12,8], false);
	output.iconsave = getIcon(icanvas, ctx);

	drawCircle(ctx, uipxRatio, 16, 16, 13, true); drawPoly(ctx, uipxRatio, [8,20,15,20,15,24,26,16,15,8,15,12,8,12], false);
	output.iconapply = getIcon(icanvas, ctx);

	drawCircle(ctx, uipxRatio, 16, 16, 13, true); drawPoly(ctx, uipxRatio, [24,20,17,20,17,24,6,16,17,8,17,12,24,12], false);
	output.iconback = getIcon(icanvas, ctx);

	drawPoly(ctx, uipxRatio, [10,8,24,16,10,24], true);
	output.iconplay = getIcon(icanvas, ctx);

	drawPoly(ctx, uipxRatio, [10,8,24,16,10,24], true); drawPoly(ctx, uipxRatio, [4,8,7,8,7,24,4,24], true);
	output.iconplaystep = getIcon(icanvas, ctx);

	drawPoly(ctx, uipxRatio, [10,10,22,10,22,22,10,22], true);
	output.iconstop = getIcon(icanvas, ctx);

	drawCircle(ctx, uipxRatio, 16, 16, 13, true); drawCircle(ctx, uipxRatio, 16, 10, 2, false); drawPoly(ctx, uipxRatio, [14,14,18,14,18,25,14,25], false);
	output.iconinfo = getIcon(icanvas, ctx);

	for (var i in output) output[i].size = iconsize;

	return output;
}

LiteGraph.Editor = Editor;