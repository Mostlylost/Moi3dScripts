// CVolume v.1.2 - Dinos, Max Smirnov. 2015
function CVolume()
{
	moi.ui.commandUI.progressinfo.innerHTML='�������� �������';
	var objectpicker = moi.ui.createObjectPicker();
	while ( true )
	{
		if (!objectpicker.waitForEvent()) return; 
		if (objectpicker.done()) break;
	}
	var objects = objectpicker.objects.getSolids();
	var	param = moi.command.getCommandLineParams(),
		angle = (param !=='')?param*1:3;
		
	if ( objects.length === 0 ) return;
	moi.ui.beginUIUpdate();
	moi.ui.showUI( 'InputContainer' );
	moi.ui.endUIUpdate();
	moi.ui.commandUI.preinit();
	moi.ui.commandUI.progressinfo.innerHTML='�������� ����� ...';
	var data = moi.ui.commandUI.processObjects(objects, angle);
	moi.ui.commandUI.postinit(objects, data);
	moi.ui.commandUI.progressinfo.innerHTML="&nbsp;";
	while ( true )
	{
		moi.ui.commandDialog.waitForEvent();
		var e  = moi.ui.commandDialog.event;
		if ( e == 'cancel' ) { moi.ui.commandUI.updateCom('cancel'); moi.ui.commandUI.scaleF.cancel(); return; }
		if ( e == 'done' ) { if (moi.ui.commandUI.origVolume !== moi.ui.commandUI.lsVolume) moi.ui.commandUI.scaleF.commit(); moi.ui.commandUI.updateCom('done');  return; }
		if ( e == 'densityBox' ) { moi.ui.commandUI.Database.options[moi.ui.commandUI.Database.options.length-1].selected = true;  moi.ui.commandUI.updateMass(); }
		if ( e == 'massBox' ) { moi.ui.commandUI.scaleObjects('mass'); }
		if ( e == 'volumeBox' ) { moi.ui.commandUI.scaleObjects('volume'); }
		if ( e == 'surfaceBox' ) { moi.ui.commandUI.scaleObjects('surface'); }
		if ( e == 'comCheckbox' ) { moi.ui.commandUI.updateCom(); }
	}
}
CVolume();
